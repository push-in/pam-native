package dev.pam.nativeapp.render

import android.content.Context
import android.graphics.Color
import android.graphics.Rect
import android.view.MotionEvent
import android.view.ContextThemeWrapper
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ScrollView
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

internal class PamScrollContainer @JvmOverloads constructor(
    context: Context,
    initialHorizontal: Boolean = false,
    initialPersistentScrollbar: Boolean = false,
    initialIndicatorStyle: ScrollIndicatorStyle = ScrollIndicatorStyle.AUTO,
) : FrameLayout(context) {
    private var horizontal = initialHorizontal
    private var scrollEnabled = true
    private var showsIndicator = false
    private var fillViewport = true
    private var nestedScrollEnabled = true
    private var configuredOverScrollMode = OVER_SCROLL_IF_CONTENT_SCROLLS
    private var fadingEdgeLengthPx = 0
    private var persistentScrollbar = initialPersistentScrollbar
    private var indicatorStyle = initialIndicatorStyle
    private var pagingEnabled = false
    private var snapIntervalPx = 0
    private var decelerationRate = NORMAL_DECELERATION_RATE
    private var keyboardDismissMode = KEYBOARD_DISMISS_NONE
    private var requestedOffsetX = 0
    private var requestedOffsetY = 0
    private var hasRequestedOffsetX = false
    private var hasRequestedOffsetY = false
    private var offsetScheduled = false
    private var previousPrimaryMaxOffset = 0
    private var primaryMaxOffsetBeforeLastLayout = 0
    private var anchorToEnd = false
    private var initialEndAnchorApplied = false
    private var maintainVisibleContentPosition = false
    private var autoScrollToEndThresholdPx = 24
    private var scrollTargetTestId = ""
    private var scrollTargetOffsetPx = -1
    private var scrollTargetAlignment = SCROLL_TARGET_START
    private var keyboardAvoidanceInsetPx = 0
    private var keyboardBaseContentExtentPx = 0
    private val applyOffsetRunnable = Runnable {
        offsetScheduled = false
        applyRequestedOffset()
    }
    private var viewportChanged: ((Float, Float) -> Unit)? = null
    private val content = FrameLayout(context).apply {
        clipChildren = false
        clipToPadding = false
        setBackgroundColor(Color.TRANSPARENT)
    }
    private var activeScroll: ViewGroup = if (horizontal) createHorizontalScroll() else createVerticalScroll()

    init {
        clipChildren = true
        clipToPadding = true
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_AUTO
        activeScroll.setBackgroundColor(Color.TRANSPARENT)
        activeScroll.addView(content, contentLayout())
        addView(activeScroll, matchParentLayout())
        applyConfiguration()
    }

    fun insert(child: View) {
        content.addView(child)
        requestOffsetApplication()
    }

    fun setHorizontal(value: Boolean) {
        if (horizontal == value) return
        horizontal = value
        replaceActiveScroll()
    }

    fun setIndicatorStyle(value: Int) {
        val next = ScrollIndicatorStyle.fromWire(value)
        if (indicatorStyle == next) return
        indicatorStyle = next
        replaceActiveScroll()
    }

    private fun replaceActiveScroll() {
        val previous = activeScroll
        val previousX = scrollXOf(previous)
        val previousY = scrollYOf(previous)
        val focused = content.findFocus()
        previous.setOnScrollChangeListener(null as View.OnScrollChangeListener?)
        previous.removeView(content)
        removeView(previous)
        activeScroll = if (horizontal) createHorizontalScroll() else createVerticalScroll()
        activeScroll.setBackgroundColor(Color.TRANSPARENT)
        activeScroll.addView(content, contentLayout())
        // Attaching a fading viewport schedules the platform's fade callback.
        // Disabling fading later does not cancel that already queued callback.
        // Configure before attachment so persistent indicators never enqueue it.
        applyConfiguration()
        addView(activeScroll, matchParentLayout())
        if (!hasRequestedOffsetX) requestedOffsetX = previousX
        if (!hasRequestedOffsetY) requestedOffsetY = previousY
        applyRequestedOffset()
        focused?.requestFocus()
        // Theme changes must not jump back to the beginning. Let the new
        // platform viewport measure before restoring uncontrolled offsets.
        restoreOffsetPixels(previousX, previousY)
    }

    fun isHorizontal(): Boolean = horizontal

    fun setScrollEnabled(value: Boolean) {
        scrollEnabled = value
        activeScroll.isEnabled = value
        if (!value) {
            (activeScroll as? ScrollView)?.fling(0)
            (activeScroll as? HorizontalScrollView)?.fling(0)
        }
        configurable().scrollingEnabled = value
    }

    fun setShowsScrollIndicator(value: Boolean) {
        showsIndicator = value
        activeScroll.isHorizontalScrollBarEnabled = value && horizontal
        activeScroll.isVerticalScrollBarEnabled = value && !horizontal
        // The framework flags can change without invalidating the hardware
        // display list: Canvas.draw sees them while the window stays stale.
        activeScroll.invalidate()
    }

    fun setFillViewport(value: Boolean) {
        fillViewport = value
        when (val scroll = activeScroll) {
            is ScrollView -> scroll.isFillViewport = value
            is HorizontalScrollView -> scroll.isFillViewport = value
        }
    }

    fun setNestedScrollEnabled(value: Boolean) {
        nestedScrollEnabled = value
        activeScroll.isNestedScrollingEnabled = value
    }

    fun setOverScrollModeValue(value: Int) {
        configuredOverScrollMode = when (value) {
            OVER_SCROLL_ALWAYS_VALUE -> OVER_SCROLL_ALWAYS
            OVER_SCROLL_NEVER_VALUE -> OVER_SCROLL_NEVER
            else -> OVER_SCROLL_IF_CONTENT_SCROLLS
        }
        activeScroll.overScrollMode = configuredOverScrollMode
    }

    fun setFadingEdgeLength(value: Float) {
        fadingEdgeLengthPx = dp(value.coerceAtLeast(0f))
        applyFadingEdge()
    }

    fun setPersistentScrollbar(value: Boolean) {
        if (persistentScrollbar == value) return
        persistentScrollbar = value
        // A fresh viewport drops any fade callback queued by the old one.
        // Content, focus and scroll offsets are retained by replacement.
        replaceActiveScroll()
    }

    fun setPagingEnabled(value: Boolean) {
        pagingEnabled = value
        configurable().pagingEnabled = value
    }

    fun setSnapInterval(value: Float) {
        snapIntervalPx = dp(value.coerceAtLeast(0f))
        configurable().snapIntervalPx = snapIntervalPx
    }

    fun setDecelerationRate(value: Float) {
        decelerationRate = value.coerceIn(0f, 1f)
        configurable().decelerationRate = decelerationRate
    }

    fun setKeyboardDismissMode(value: Int) {
        keyboardDismissMode = value.coerceIn(
            KEYBOARD_DISMISS_NONE,
            KEYBOARD_DISMISS_INTERACTIVE,
        )
        configurable().dismissKeyboardOnDrag =
            keyboardDismissMode != KEYBOARD_DISMISS_NONE
    }

    fun setContentOffsetX(value: Float) {
        requestedOffsetX = dp(value.coerceAtLeast(0f))
        hasRequestedOffsetX = true
        requestOffsetApplication()
    }

    fun setContentOffsetY(value: Float) {
        requestedOffsetY = dp(value.coerceAtLeast(0f))
        hasRequestedOffsetY = true
        requestOffsetApplication()
    }

    fun setAnchorToEnd(value: Boolean) {
        if (anchorToEnd == value) return
        anchorToEnd = value
        if (value) {
            initialEndAnchorApplied = false
            requestOffsetApplication()
        }
    }

    fun setMaintainVisibleContentPosition(value: Boolean) {
        maintainVisibleContentPosition = value
    }

    fun setAutoScrollToEndThreshold(value: Float) {
        autoScrollToEndThresholdPx = dp(value.coerceAtLeast(0f))
    }

    fun setScrollTargetTestId(value: String) {
        scrollTargetTestId = value
    }

    fun setScrollTargetOffset(value: Float) {
        scrollTargetOffsetPx = if (value < 0f) -1 else dp(value)
    }

    fun setScrollTargetAlignment(value: Int) {
        scrollTargetAlignment = value.coerceIn(SCROLL_TARGET_START, SCROLL_TARGET_END)
    }

    fun requestScroll() {
        requestScrollAfterLayout(retry = true)
    }

    private fun requestScrollAfterLayout(retry: Boolean) {
        activeScroll.post {
            if (!isAttachedToWindow) return@post
            if (scrollTargetTestId.isNotEmpty()) {
                val target = findDescendantByTestId(content, scrollTargetTestId)
                    ?: return@post
                val rect = Rect(0, 0, target.width, target.height)
                content.offsetDescendantRectToMyCoords(target, rect)
                val targetStart = if (horizontal) rect.left else rect.top
                val targetExtent = if (horizontal) rect.width() else rect.height()
                val viewportExtent = if (horizontal) activeScroll.width else activeScroll.height
                scrollToPrimary(
                    alignedTargetOffset(
                        targetStart,
                        targetExtent,
                        viewportExtent,
                        scrollTargetAlignment,
                    ),
                )
                if (retry) {
                    activeScroll.postOnAnimation {
                        requestScrollAfterLayout(retry = false)
                    }
                }
                return@post
            }
            if (scrollTargetOffsetPx >= 0) {
                scrollToPrimary(scrollTargetOffsetPx)
            } else {
                scrollToPrimary(primaryMaxOffset())
            }
            if (retry) {
                activeScroll.postOnAnimation {
                    requestScrollAfterLayout(retry = false)
                }
            }
        }
    }

    fun setKeyboardAvoidanceInset(value: Int) {
        val inset = value.coerceAtLeast(0)
        if (keyboardAvoidanceInsetPx == inset) return
        val wasNearEnd =
            primaryMaxOffset() - primaryCurrentOffset() <= autoScrollToEndThresholdPx
        if (keyboardAvoidanceInsetPx == 0 && inset > 0) {
            keyboardBaseContentExtentPx = if (horizontal) content.width else content.height
        }
        keyboardAvoidanceInsetPx = inset
        if (horizontal) {
            content.setPadding(0, 0, inset, 0)
            content.minimumWidth = if (inset > 0) {
                keyboardBaseContentExtentPx + inset
            } else {
                0
            }
        } else {
            content.setPadding(0, 0, 0, inset)
            content.minimumHeight = if (inset > 0) {
                keyboardBaseContentExtentPx + inset
            } else {
                0
            }
        }
        if (inset == 0) keyboardBaseContentExtentPx = 0
        content.requestLayout()
        if (anchorToEnd && wasNearEnd) {
            activeScroll.post {
                if (isAttachedToWindow && keyboardAvoidanceInsetPx == inset) {
                    scrollToPrimary(primaryMaxOffset())
                }
            }
        }
    }

    fun keyboardAvoidanceInsetPixels(): Int = keyboardAvoidanceInsetPx

    fun ensureKeyboardTargetVisible(target: View) {
        if (keyboardAvoidanceInsetPx <= 0) return
        ensureTargetVisible(target, keyboardAvoidanceInsetPx, retry = true)
    }

    fun ensureViewportTargetVisible(target: View) {
        ensureTargetVisible(target, obscuredInsetPx = 0, retry = true)
    }

    private fun ensureTargetVisible(
        target: View,
        obscuredInsetPx: Int,
        retry: Boolean,
    ) {
        if (horizontal) return
        activeScroll.post {
            if (
                !isAttachedToWindow ||
                !target.isAttachedToWindow ||
                !isDescendantOfContent(target)
            ) {
                return@post
            }
            val rect = Rect(0, 0, target.width, target.height)
            content.offsetDescendantRectToMyCoords(target, rect)
            val current = primaryCurrentOffset()
            val viewportExtent = (activeScroll.height - obscuredInsetPx)
                .coerceAtLeast(0)
            val clearance = minOf(
                dp(KEYBOARD_TARGET_CLEARANCE_DP),
                ((viewportExtent - rect.height()).coerceAtLeast(0) / 2),
            )
            val visibleEnd = current +
                viewportExtent
            val next = when {
                rect.bottom + clearance > visibleEnd ->
                    current + rect.bottom + clearance - visibleEnd
                rect.top - clearance < current -> rect.top - clearance
                else -> current
            }
            val boundedNext = next.coerceIn(0, primaryMaxOffset())
            if (boundedNext != current) scrollToPrimary(boundedNext)
            // Keyboard insets and orientation-driven PHP layout can settle on
            // the next frame. Recheck once so the focused editor cannot be
            // left outside a newly reduced viewport after rotation.
            if (retry) {
                activeScroll.postOnAnimation {
                    ensureTargetVisible(target, obscuredInsetPx, retry = false)
                }
            }
        }
    }

    fun setOnViewportChanged(listener: ((Float, Float) -> Unit)?) {
        viewportChanged = listener
    }

    fun primaryOffset(x: Float, y: Float): Float = if (horizontal) x else y

    /** Pixels left before the end of the content along the scroll axis. */
    fun remainingPrimaryPixels(): Int = primaryMaxOffset() - primaryCurrentOffset()

    fun primaryViewportPixels(): Int = if (horizontal) activeScroll.width else activeScroll.height

    fun snapshotOffsetPixels(): Pair<Int, Int> =
        scrollXOf(activeScroll) to scrollYOf(activeScroll)

    fun restoreOffsetPixels(x: Int, y: Int) {
        if (hasRequestedOffsetX || hasRequestedOffsetY) return
        val targetOffset = if (horizontal) x else y
        val targetWasAtPreviousEnd =
            abs(targetOffset - previousPrimaryMaxOffset) <= autoScrollToEndThresholdPx ||
                abs(targetOffset - primaryMaxOffsetBeforeLastLayout) <=
                autoScrollToEndThresholdPx
        if (
            anchorToEnd &&
            targetWasAtPreviousEnd &&
            (primaryMaxOffset() - primaryCurrentOffset())
                .coerceAtLeast(0) <= autoScrollToEndThresholdPx
        ) {
            return
        }
        activeScroll.post {
            if (
                isAttachedToWindow
                && !hasRequestedOffsetX
                && !hasRequestedOffsetY
            ) {
                activeScroll.scrollTo(
                    x.coerceAtLeast(0),
                    y.coerceAtLeast(0),
                )
            }
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        applyRequestedOffset()
    }

    override fun onLayout(
        changed: Boolean,
        left: Int,
        top: Int,
        right: Int,
        bottom: Int,
    ) {
        val previousMax = previousPrimaryMaxOffset
        val previousOffset = primaryOffset(
            scrollXOf(activeScroll).toFloat(),
            scrollYOf(activeScroll).toFloat(),
        ).roundToInt()
        val distanceFromEnd = (previousMax - previousOffset).coerceAtLeast(0)
        super.onLayout(changed, left, top, right, bottom)
        val newMax = primaryMaxOffset()
        primaryMaxOffsetBeforeLastLayout = previousMax
        previousPrimaryMaxOffset = newMax
        when {
            anchorToEnd && !initialEndAnchorApplied -> {
                initialEndAnchorApplied = true
                scrollToPrimary(newMax)
                scheduleRequestedOffset()
            }
            anchorToEnd &&
                newMax != previousMax &&
                distanceFromEnd <= autoScrollToEndThresholdPx -> scrollToPrimary(newMax)
            maintainVisibleContentPosition && newMax > previousMax ->
                scrollToPrimary(previousOffset + newMax - previousMax)
            distanceFromEnd <= 2 && (hasRequestedOffsetX || hasRequestedOffsetY) ->
                requestOffsetApplication()
        }
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(applyOffsetRunnable)
        offsetScheduled = false
        super.onDetachedFromWindow()
    }

    private fun createVerticalScroll(): ViewGroup =
        PamVerticalScrollView(indicatorContext(), ::dismissKeyboard).apply {
            setOnScrollChangeListener { _, scrollX, scrollY, _, _ ->
                dispatchViewport(scrollX, scrollY)
            }
        }

    private fun createHorizontalScroll(): ViewGroup =
        PamHorizontalScrollView(indicatorContext(), ::dismissKeyboard).apply {
            setOnScrollChangeListener { _, scrollX, scrollY, _, _ ->
                dispatchViewport(scrollX, scrollY)
            }
        }

    private fun indicatorContext(): Context =
        if (indicatorStyle == ScrollIndicatorStyle.AUTO) context
        else ContextThemeWrapper(context, indicatorStyle.themeResource)

    private fun applyConfiguration() {
        activeScroll.clipChildren = true
        activeScroll.clipToPadding = true
        activeScroll.isEnabled = scrollEnabled
        setShowsScrollIndicator(showsIndicator)
        setFillViewport(fillViewport)
        setNestedScrollEnabled(nestedScrollEnabled)
        activeScroll.overScrollMode = configuredOverScrollMode
        activeScroll.isScrollbarFadingEnabled = !persistentScrollbar
        applyFadingEdge()
        configurable().apply {
            scrollingEnabled = scrollEnabled
            pagingEnabled = this@PamScrollContainer.pagingEnabled
            snapIntervalPx = this@PamScrollContainer.snapIntervalPx
            decelerationRate = this@PamScrollContainer.decelerationRate
            dismissKeyboardOnDrag =
                keyboardDismissMode != KEYBOARD_DISMISS_NONE
        }
    }

    private fun applyFadingEdge() {
        val enabled = fadingEdgeLengthPx > 0
        activeScroll.isHorizontalFadingEdgeEnabled = enabled && horizontal
        activeScroll.isVerticalFadingEdgeEnabled = enabled && !horizontal
        if (enabled) activeScroll.setFadingEdgeLength(fadingEdgeLengthPx)
    }

    private fun applyRequestedOffset() {
        if (!isLaidOut || activeScroll.childCount == 0) {
            scheduleRequestedOffset()
            return
        }
        val x = if (hasRequestedOffsetX) requestedOffsetX else scrollXOf(activeScroll)
        val y = if (hasRequestedOffsetY) requestedOffsetY else scrollYOf(activeScroll)
        activeScroll.scrollTo(x, y)
    }

    private fun requestOffsetApplication() {
        applyRequestedOffset()
        scheduleRequestedOffset()
    }

    private fun scheduleRequestedOffset() {
        if (!isAttachedToWindow || offsetScheduled) return
        offsetScheduled = true
        post(applyOffsetRunnable)
    }

    private fun dispatchViewport(scrollX: Int, scrollY: Int) {
        val density = resources.displayMetrics.density
        viewportChanged?.invoke(scrollX / density, scrollY / density)
    }

    private fun dismissKeyboard() {
        val focused = rootView.findFocus() ?: return
        (context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(focused.windowToken, 0)
        focused.clearFocus()
    }

    private fun isDescendantOfContent(target: View): Boolean {
        var current: View? = target
        while (current != null) {
            if (current === content) return true
            current = current.parent as? View
        }
        return false
    }

    private fun configurable(): ConfigurableScroll =
        activeScroll as ConfigurableScroll

    private fun matchParentLayout(): LayoutParams =
        LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT,
        )

    private fun contentLayout(): ViewGroup.LayoutParams =
        ViewGroup.LayoutParams(
            if (horizontal) {
                ViewGroup.LayoutParams.WRAP_CONTENT
            } else {
                ViewGroup.LayoutParams.MATCH_PARENT
            },
            if (horizontal) {
                ViewGroup.LayoutParams.MATCH_PARENT
            } else {
                ViewGroup.LayoutParams.WRAP_CONTENT
            },
        )

    private fun scrollXOf(view: View): Int = view.scrollX.coerceAtLeast(0)
    private fun scrollYOf(view: View): Int = view.scrollY.coerceAtLeast(0)

    private fun primaryMaxOffset(): Int =
        if (horizontal) {
            (content.width - activeScroll.width).coerceAtLeast(0)
        } else {
            (content.height - activeScroll.height).coerceAtLeast(0)
        }

    private fun primaryCurrentOffset(): Int =
        if (horizontal) scrollXOf(activeScroll) else scrollYOf(activeScroll)

    private fun scrollToPrimary(offset: Int) {
        val bounded = offset.coerceIn(0, primaryMaxOffset())
        if (bounded == primaryCurrentOffset()) return
        if (horizontal) {
            activeScroll.scrollTo(bounded, scrollYOf(activeScroll))
        } else {
            activeScroll.scrollTo(scrollXOf(activeScroll), bounded)
        }
    }

    private fun findDescendantByTestId(root: View, testId: String): View? {
        if (root.transitionName == testId) return root
        if (root !is ViewGroup) return null
        for (index in 0 until root.childCount) {
            findDescendantByTestId(root.getChildAt(index), testId)?.let {
                return it
            }
        }
        return null
    }

    private fun dp(value: Float): Int =
        (value * resources.displayMetrics.density + 0.5f).toInt()

    private interface ConfigurableScroll {
        var scrollingEnabled: Boolean
        var pagingEnabled: Boolean
        var snapIntervalPx: Int
        var decelerationRate: Float
        var dismissKeyboardOnDrag: Boolean
    }

    private class PamVerticalScrollView(
        context: Context,
        private val dismissKeyboard: () -> Unit,
    ) : ScrollView(context), ConfigurableScroll {
        override var scrollingEnabled = true
        override var pagingEnabled = false
        override var snapIntervalPx = 0
        override var decelerationRate = NORMAL_DECELERATION_RATE
        override var dismissKeyboardOnDrag = false
        private var flingStarted = false
        private var gestureStartScroll = 0
        private var gestureActive = false
        private var nestedGestureList: PamRecyclerList? = null
        private var nestedGestureDownY = 0f
        private val touch = ScrollTouchTracker(context)

        override fun onInterceptTouchEvent(event: MotionEvent): Boolean {
            if (!scrollingEnabled) return false
            if (event.actionMasked == MotionEvent.ACTION_DOWN) {
                nestedGestureList = overflowingListAt(event)
                nestedGestureDownY = event.y
            }
            if (event.actionMasked == MotionEvent.ACTION_MOVE) {
                nestedGestureList?.let { list ->
                    val direction = if (event.y - nestedGestureDownY < 0f) 1 else -1
                    if (list.canScrollInDirection(direction)) return false
                    nestedGestureList = null
                }
            }
            val intercepted = super.onInterceptTouchEvent(event)
            if (nestedGestureList != null) {
                if (
                    event.actionMasked == MotionEvent.ACTION_UP ||
                    event.actionMasked == MotionEvent.ACTION_CANCEL
                ) {
                    nestedGestureList = null
                }
                return false
            }
            if (
                intercepted &&
                event.actionMasked == MotionEvent.ACTION_MOVE &&
                dismissKeyboardOnDrag
            ) {
                dismissKeyboard()
            }
            return intercepted
        }

        private fun overflowingListAt(event: MotionEvent): PamRecyclerList? {
            val screenX = event.rawX.toInt()
            val screenY = event.rawY.toInt()
            fun visit(view: View): PamRecyclerList? {
                val rect = Rect()
                if (!view.getGlobalVisibleRect(rect) || !rect.contains(screenX, screenY)) {
                    return null
                }
                if (view is PamRecyclerList && view.hasScrollableContent()) return view
                if (view !is ViewGroup) return null
                for (index in view.childCount - 1 downTo 0) {
                    visit(view.getChildAt(index))?.let { return it }
                }
                return null
            }
            return getChildAt(0)?.let(::visit)
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            if (!scrollingEnabled) return false
            if (event.actionMasked == MotionEvent.ACTION_DOWN) {
                flingStarted = false
                gestureStartScroll = scrollY
                gestureActive = true
            }
            touch.observe(event)
            val handled = super.onTouchEvent(event)
            if (handled && event.actionMasked == MotionEvent.ACTION_UP) {
                if (!touch.moved) performClick()
                if (!flingStarted) post(::snapToNearest)
            }
            touch.finish(event)
            if (
                event.actionMasked == MotionEvent.ACTION_UP ||
                event.actionMasked == MotionEvent.ACTION_CANCEL
            ) {
                gestureActive = false
            }
            return handled
        }

        override fun performClick(): Boolean = super.performClick()

        override fun fling(velocityY: Int) {
            flingStarted = true
            val velocity = adjustedVelocity(velocityY, decelerationRate)
            if (snapExtent() > 0) {
                val start = if (gestureActive) gestureStartScroll else scrollY
                snapOnePage(start, scrollY, velocity, snapExtent(), maxScroll()) {
                    smoothScrollTo(0, it)
                }
            } else {
                super.fling(velocity)
            }
        }

        private fun snapToNearest() {
            val extent = snapExtent()
            if (extent > 0) {
                smoothScrollTo(
                    0,
                    pamOnePageTarget(gestureStartScroll, scrollY, 0, extent, maxScroll()),
                )
            }
        }

        private fun snapExtent(): Int =
            when {
                snapIntervalPx > 0 -> snapIntervalPx
                pagingEnabled -> height - paddingTop - paddingBottom
                else -> 0
            }.coerceAtLeast(0)

        private fun maxScroll(): Int =
            max(
                0,
                (getChildAt(0)?.height ?: 0) -
                    height +
                    paddingTop +
                    paddingBottom,
            )
    }

    private class PamHorizontalScrollView(
        context: Context,
        private val dismissKeyboard: () -> Unit,
    ) : HorizontalScrollView(context), ConfigurableScroll {
        override var scrollingEnabled = true
        override var pagingEnabled = false
        override var snapIntervalPx = 0
        override var decelerationRate = NORMAL_DECELERATION_RATE
        override var dismissKeyboardOnDrag = false
        private var flingStarted = false
        private var gestureStartScroll = 0
        private var gestureActive = false
        private val touch = ScrollTouchTracker(context)

        override fun onInterceptTouchEvent(event: MotionEvent): Boolean {
            if (!scrollingEnabled) return false
            val intercepted = super.onInterceptTouchEvent(event)
            if (
                intercepted &&
                event.actionMasked == MotionEvent.ACTION_MOVE &&
                dismissKeyboardOnDrag
            ) {
                dismissKeyboard()
            }
            return intercepted
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            if (!scrollingEnabled) return false
            if (event.actionMasked == MotionEvent.ACTION_DOWN) {
                flingStarted = false
                gestureStartScroll = scrollX
                gestureActive = true
            }
            touch.observe(event)
            val handled = super.onTouchEvent(event)
            if (handled && event.actionMasked == MotionEvent.ACTION_UP) {
                if (!touch.moved) performClick()
                if (!flingStarted) post(::snapToNearest)
            }
            touch.finish(event)
            if (
                event.actionMasked == MotionEvent.ACTION_UP ||
                event.actionMasked == MotionEvent.ACTION_CANCEL
            ) {
                gestureActive = false
            }
            return handled
        }

        override fun performClick(): Boolean = super.performClick()

        override fun fling(velocityX: Int) {
            flingStarted = true
            val velocity = adjustedVelocity(velocityX, decelerationRate)
            if (snapExtent() > 0) {
                val start = if (gestureActive) gestureStartScroll else scrollX
                snapOnePage(start, scrollX, velocity, snapExtent(), maxScroll()) {
                    smoothScrollTo(it, 0)
                }
            } else {
                super.fling(velocity)
            }
        }

        private fun snapToNearest() {
            val extent = snapExtent()
            if (extent > 0) {
                smoothScrollTo(
                    pamOnePageTarget(gestureStartScroll, scrollX, 0, extent, maxScroll()),
                    0,
                )
            }
        }

        private fun snapExtent(): Int =
            when {
                snapIntervalPx > 0 -> snapIntervalPx
                pagingEnabled -> width - paddingLeft - paddingRight
                else -> 0
            }.coerceAtLeast(0)

        private fun maxScroll(): Int =
            max(
                0,
                (getChildAt(0)?.width ?: 0) -
                    width +
                    paddingLeft +
                    paddingRight,
            )
    }

    private class ScrollTouchTracker(context: Context) {
        private val slop = ViewConfiguration.get(context).scaledTouchSlop
        private var downX = 0f
        private var downY = 0f
        var moved = false
            private set

        fun observe(event: MotionEvent) {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.x
                    downY = event.y
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    if (
                        abs(event.x - downX) > slop ||
                        abs(event.y - downY) > slop
                    ) {
                        moved = true
                    }
                }
            }
        }

        fun finish(event: MotionEvent) {
            if (
                event.actionMasked == MotionEvent.ACTION_UP ||
                event.actionMasked == MotionEvent.ACTION_CANCEL
            ) {
                moved = false
            }
        }
    }

    private companion object {
        const val SCROLL_TARGET_START = 1
        const val SCROLL_TARGET_CENTER = 2
        const val SCROLL_TARGET_END = 3
        const val OVER_SCROLL_ALWAYS_VALUE = 2
        const val OVER_SCROLL_NEVER_VALUE = 3
        const val KEYBOARD_DISMISS_NONE = 1
        const val KEYBOARD_DISMISS_INTERACTIVE = 3
        const val NORMAL_DECELERATION_RATE = 0.985f
        // Material supporting text (helper/error/counter) occupies 20dp with a
        // 4dp top gap. Keeping this full strip visible prevents focused fields
        // from touching the IME and hiding their validation state.
        const val KEYBOARD_TARGET_CLEARANCE_DP = 24f

        fun alignedTargetOffset(
            targetStart: Int,
            targetExtent: Int,
            viewportExtent: Int,
            alignment: Int,
        ): Int {
            val available = (viewportExtent - targetExtent).coerceAtLeast(0)
            val adjustment = when (alignment) {
                SCROLL_TARGET_CENTER -> available / 2
                SCROLL_TARGET_END -> available
                else -> 0
            }
            return (targetStart - adjustment).coerceAtLeast(0)
        }

        fun adjustedVelocity(velocity: Int, rate: Float): Int =
            (velocity * (rate / NORMAL_DECELERATION_RATE)).roundToInt()

        fun nearestSnap(position: Int, extent: Int): Int =
            (position.toFloat() / extent).roundToInt() * extent

        fun snapOnePage(
            startPosition: Int,
            position: Int,
            velocity: Int,
            extent: Int,
            maxScroll: Int,
            scroll: (Int) -> Unit,
        ) {
            scroll(pamOnePageTarget(startPosition, position, velocity, extent, maxScroll))
        }
    }
}

internal fun pamOnePageTarget(
    startPosition: Int,
    position: Int,
    velocity: Int,
    extent: Int,
    maxScroll: Int,
): Int {
    if (extent <= 0) return position.coerceIn(0, maxScroll)
    val startPage = (startPosition.toFloat() / extent).roundToInt()
    val displacement = position - startPage * extent
    val direction = when {
        velocity > 350 -> 1
        velocity < -350 -> -1
        displacement > extent * 0.18f -> 1
        displacement < -extent * 0.18f -> -1
        else -> 0
    }
    return ((startPage + direction) * extent).coerceIn(0, maxScroll)
}

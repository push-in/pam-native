package dev.pam.nativeapp

import android.content.Context
import android.hardware.display.DisplayManager
import android.os.Handler
import android.os.Looper
import android.os.Trace
import android.util.Log
import android.view.Choreographer
import dev.pam.nativeapp.modules.ModuleCompletion
import dev.pam.nativeapp.modules.NativeModuleRegistry
import dev.pam.nativeapp.protocol.BatchDecoder
import dev.pam.nativeapp.protocol.Mutation
import dev.pam.nativeapp.protocol.WireMap
import dev.pam.nativeapp.protocol.WireValue
import dev.pam.nativeapp.render.PamRenderer
import java.io.File
import java.nio.ByteBuffer
import java.util.ArrayDeque
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean

class PamRuntime(
    private val context: Context,
    private val renderer: PamRenderer,
    private val reportError: (String) -> Unit,
    private val onFrameCommitted: (RuntimeFrameMetrics) -> Unit = {},
    private val onDiagnostic: (RuntimeDiagnostic) -> Unit = {},
) : AutoCloseable {
    private val main = Handler(Looper.getMainLooper())
    private val choreographer = Choreographer.getInstance()
    private val modules = NativeModuleRegistry(context)
    private val closed = AtomicBoolean()
    private val handleLock = Any()
    private val ownedBatchHandles = ConcurrentHashMap.newKeySet<Long>()
    private val pendingBatches = ArrayDeque<PendingBatch>()
    private val pendingImmediateEvents = ArrayDeque<PendingEvent>()
    private val pendingEvents = LinkedHashMap<EventIdentity, ByteArray>()
    private val hotReloadLatency = HotReloadLatency()
    private var frameScheduled = false
    private var readyForEvents = false
    private val frameCallback = Choreographer.FrameCallback {
        frameScheduled = false
        flushEvents()
        flushBatches()
    }

    @Volatile
    private var handle = 0L

    init {
        renderer.onNativeChildVisibility = { owner, child, visible ->
            synchronized(handleLock) {
                if (!closed.get() && handle != 0L) {
                    nativeSetChildVisibility(handle, owner, child, visible)
                }
            }
        }
    }

    fun start(
        entry: File,
        widthDp: Float,
        heightDp: Float,
        textScale: Float,
        darkAppearance: Boolean,
    ) {
        synchronized(handleLock) {
            check(!closed.get()) { "Pam Runtime is closed" }
            check(handle == 0L) { "Pam Runtime is already running" }
            val stateDirectory = File(context.filesDir, "pam/state").apply {
                check(mkdirs() || isDirectory) { "Cannot create Pam Native state directory" }
            }
            handle = nativeStart(
                entry.absolutePath,
                stateDirectory.absolutePath,
                widthDp,
                heightDp,
                textScale,
                darkAppearance,
            )
            check(handle != 0L) { "Pam Runtime failed to start" }
            val display = (context.getSystemService(Context.DISPLAY_SERVICE) as? DisplayManager)
                ?.getDisplay(android.view.Display.DEFAULT_DISPLAY)
            nativeSetRefreshRate(handle, display?.refreshRate?.toDouble() ?: 60.0)
        }
    }

    fun updateViewport(
        widthDp: Float,
        heightDp: Float,
        textScale: Float,
        darkAppearance: Boolean,
    ) {
        synchronized(handleLock) {
            val active = handle
            if (active != 0L) {
                nativeRelayout(active, widthDp, heightDp, textScale, darkAppearance)
            }
        }
    }

    fun dispatchLifecycle(kind: Int, payload: ByteArray) {
        onDiagnostic(RuntimeDiagnostic(RuntimeDiagnosticKind.LIFECYCLE, "event $kind"))
        dispatchEvent(0, kind, payload)
    }

    fun trimMemory(critical: Boolean) {
        renderer.trimMemory(critical)
    }

    fun onHostPause() {
        renderer.onHostPause()
    }

    fun onHostResume() {
        renderer.onHostResume()
    }

    fun dispatchEvent(nodeId: Long, kind: Int, payload: ByteArray = ByteArray(0)) {
        if (payload.size > MAX_PAYLOAD_BYTES) return
        if (kind >= 42) {
            onDiagnostic(RuntimeDiagnostic(RuntimeDiagnosticKind.EVENT, "node $nodeId · event $kind"))
        }
        if (kind in COALESCED_EVENTS) {
            val enqueue = {
                if (!closed.get()) {
                    pendingEvents[EventIdentity(nodeId, kind)] = payload.copyOf()
                    scheduleFrame()
                }
            }
            if (Looper.myLooper() == Looper.getMainLooper()) enqueue() else main.post(enqueue)
            return
        }
        dispatchEventImmediately(nodeId, kind, payload)
    }

    private fun dispatchEventImmediately(nodeId: Long, kind: Int, payload: ByteArray) {
        synchronized(handleLock) {
            val active = handle
            if (active != 0L && readyForEvents) {
                nativeDispatchEvent(active, nodeId, kind, payload)
            } else if (active != 0L) {
                if (pendingImmediateEvents.size >= MAX_PENDING_EVENTS) {
                    pendingImmediateEvents.removeFirst()
                }
                pendingImmediateEvents.addLast(PendingEvent(nodeId, kind, payload.copyOf()))
            }
        }
    }

    fun dispatchBack() {
        dispatchEvent(0, EVENT_BACK)
    }

    fun hasPresentedModal(): Boolean = renderer.hasPresentedModal()

    fun consumePresentedModalBack(): Boolean = renderer.consumePresentedModalBack()

    fun reload(
        entryPath: String,
        confirmedAtNanos: Long? = null,
        bundleBytes: Int = 0,
    ) {
        synchronized(handleLock) {
            val active = handle
            if (active != 0L) {
                if (confirmedAtNanos != null) {
                    hotReloadLatency.begin(confirmedAtNanos, bundleBytes)
                }
                readyForEvents = false
                modules.prepareReload()
                nativeReload(active, entryPath)
            }
        }
    }

    fun stats(): RuntimeStats {
        val values = synchronized(handleLock) {
            val active = handle
            if (active == 0L) LongArray(19) else nativeStats(active)
        }
        return RuntimeStats(
            commits = values.getOrElse(0) { 0 },
            nodes = values.getOrElse(1) { 0 },
            created = values.getOrElse(2) { 0 },
            removed = values.getOrElse(3) { 0 },
            updated = values.getOrElse(4) { 0 },
            retainedBytes = values.getOrElse(5) { 0 },
            fullCommits = values.getOrElse(6) { 0 },
            patchCommits = values.getOrElse(7) { 0 },
            inputBytes = values.getOrElse(8) { 0 },
            outputBytes = values.getOrElse(9) { 0 },
            decodeP95Micros = values.getOrElse(10) { 0 },
            reconcileP95Micros = values.getOrElse(11) { 0 },
            layoutP95Micros = values.getOrElse(12) { 0 },
            encodeP95Micros = values.getOrElse(13) { 0 },
            coalescedCommands = values.getOrElse(14) { 0 },
            bufferReuses = values.getOrElse(15) { 0 },
            reusedBufferBytes = values.getOrElse(16) { 0 },
            measuredFrames = values.getOrElse(17) { 0 },
            deadlineMisses = values.getOrElse(18) { 0 },
        )
    }

    override fun close() {
        if (!closed.compareAndSet(false, true)) return
        renderer.onNativeChildVisibility = null
        synchronized(handleLock) {
            val active = handle
            handle = 0L
            if (active != 0L) {
                nativeStop(active)
            }
        }
        main.removeCallbacksAndMessages(null)
        choreographer.removeFrameCallback(frameCallback)
        frameScheduled = false
        while (pendingBatches.isNotEmpty()) {
            releaseBatch(pendingBatches.removeFirst().handle)
        }
        pendingEvents.clear()
        pendingImmediateEvents.clear()
        ownedBatchHandles.toList().forEach(::releaseBatch)
        modules.close()
        renderer.close()
    }

    @Suppress("unused")
    private fun onNativeBatch(batch: ByteBuffer, batchHandle: Long): Boolean {
        if (batchHandle == 0L || closed.get() || !ownedBatchHandles.add(batchHandle)) return false
        val decodeStarted = System.nanoTime()
        Trace.beginSection("PamNative.decode")
        val mutations = try {
            runCatching {
                BatchDecoder.decode(batch.asReadOnlyBuffer())
            }.getOrElse { error ->
                ownedBatchHandles.remove(batchHandle)
                onNativeError(error.message ?: "Cannot decode native batch")
                return false
            }
        } finally {
            Trace.endSection()
        }
        val decodeNanos = System.nanoTime() - decodeStarted
        main.post {
            if (closed.get()) {
                releaseBatch(batchHandle)
                return@post
            }
            pendingBatches.addLast(
                PendingBatch(
                    mutations = mutations,
                    handle = batchHandle,
                    decodeNanos = decodeNanos,
                ),
            )
            markReadyForEvents()
            scheduleFrame()
        }
        return true
    }

    @Suppress("unused")
    private fun onNativeCall(
        requestId: Long,
        module: String,
        method: String,
        payload: ByteArray,
    ) {
        val started = System.nanoTime()
        modules.invoke(
            module = module,
            method = method,
            payload = payload,
            completion = ModuleCompletion { status, result ->
                onDiagnostic(
                    moduleDiagnostic(
                        module,
                        method,
                        payload,
                        result,
                        status == dev.pam.nativeapp.modules.ModuleResultStatus.FAILURE,
                        System.nanoTime() - started,
                    ),
                )
                synchronized(handleLock) {
                    val active = handle
                    if (active != 0L) {
                        nativeDispatchModuleResult(active, requestId, status.value, result)
                    }
                }
            },
        )
    }

    private fun moduleDiagnostic(
        module: String,
        method: String,
        requestPayload: ByteArray,
        responsePayload: ByteArray,
        transportFailed: Boolean,
        durationNanos: Long,
    ): RuntimeDiagnostic {
        val fallback = RuntimeDiagnostic(
            RuntimeDiagnosticKind.MODULE_CALL,
            "$module.$method",
            durationNanos,
            transportFailed,
        )
        if (module != "http" || method != "request") return fallback

        return runCatching {
            val request = WireMap.decode(requestPayload)
            val methodName = (request["method"] as? WireValue.Text)?.value ?: return fallback
            val methodCode = RuntimeHttpMethod.valueOf(methodName).value
            val requestBytes = (request["body"] as? WireValue.Text)
                ?.value
                ?.toByteArray(Charsets.UTF_8)
                ?.size
                ?: 0
            val response = if (transportFailed) emptyMap() else WireMap.decode(responsePayload)
            val statusCode = (response["statusCode"] as? WireValue.Integer)?.value?.toInt()
            val responseBytes = (response["body"] as? WireValue.Text)
                ?.value
                ?.toByteArray(Charsets.UTF_8)
                ?.size
                ?: 0
            RuntimeDiagnostic(
                kind = RuntimeDiagnosticKind.NETWORK,
                label = "HTTP $methodName",
                durationNanos = durationNanos,
                failed = transportFailed || (statusCode != null && statusCode >= 400),
                methodCode = methodCode,
                statusCode = statusCode,
                requestBytes = requestBytes,
                responseBytes = responseBytes,
            )
        }.getOrElse { fallback }
    }

    @Suppress("unused")
    private fun onNativeCallTyped(
        requestId: Long,
        operation: Int,
        payload: ByteArray,
    ) {
        val started = System.nanoTime()
        modules.invoke(
            operationValue = operation,
            payload = payload,
            completion = ModuleCompletion { status, result ->
                onDiagnostic(
                    RuntimeDiagnostic(
                        RuntimeDiagnosticKind.MODULE_CALL,
                        "system.operation.$operation",
                        System.nanoTime() - started,
                        status == dev.pam.nativeapp.modules.ModuleResultStatus.FAILURE,
                    ),
                )
                synchronized(handleLock) {
                    val active = handle
                    if (active != 0L) {
                        nativeDispatchModuleResult(active, requestId, status.value, result)
                    }
                }
            },
        )
    }

    @Suppress("unused")
    private fun onNativeError(message: String) {
        completeHotReload(failed = true)
        onDiagnostic(RuntimeDiagnostic(RuntimeDiagnosticKind.ERROR, message.take(120), failed = true))
        main.post {
            if (!closed.get()) {
                reportError(message)
            }
        }
    }

    private external fun nativeStart(
        entry: String,
        stateDirectory: String,
        widthDp: Float,
        heightDp: Float,
        textScale: Float,
        darkAppearance: Boolean,
    ): Long
    private external fun nativeRelayout(
        handle: Long,
        widthDp: Float,
        heightDp: Float,
        textScale: Float,
        darkAppearance: Boolean,
    )
    private external fun nativeSetChildVisibility(handle: Long, owner: Long, child: Long, visible: Boolean)

    private external fun nativeSetRefreshRate(handle: Long, refreshRateHz: Double)

    private external fun nativeDispatchEvent(
        handle: Long,
        nodeId: Long,
        eventKind: Int,
        payload: ByteArray,
    )

    private external fun nativeDispatchModuleResult(
        handle: Long,
        requestId: Long,
        status: Int,
        payload: ByteArray,
    )

    private external fun nativeReload(handle: Long, entry: String)
    private external fun nativeStats(handle: Long): LongArray
    private external fun nativeReleaseBatch(batchHandle: Long)
    private external fun nativeStop(handle: Long)

    private fun scheduleFrame() {
        if (
            frameScheduled ||
            pendingBatches.isEmpty() && (pendingEvents.isEmpty() || !readyForEvents)
        ) return
        frameScheduled = true
        choreographer.postFrameCallback(frameCallback)
    }

    private fun flushEvents() {
        if (pendingEvents.isEmpty()) return
        if (closed.get()) {
            pendingEvents.clear()
            return
        }
        if (!readyForEvents) return
        val current = pendingEvents.toMap()
        pendingEvents.clear()
        synchronized(handleLock) {
            val active = handle
            if (active == 0L) return
            current.forEach { (identity, payload) ->
                nativeDispatchEvent(active, identity.nodeId, identity.kind, payload)
            }
        }
    }

    private fun markReadyForEvents() {
        synchronized(handleLock) {
            if (readyForEvents) return
            readyForEvents = true
            val active = handle
            if (active == 0L) return
            while (pendingImmediateEvents.isNotEmpty()) {
                val event = pendingImmediateEvents.removeFirst()
                nativeDispatchEvent(active, event.nodeId, event.kind, event.payload)
            }
        }
    }

    private fun flushBatches() {
        if (closed.get()) {
            while (pendingBatches.isNotEmpty()) {
                releaseBatch(pendingBatches.removeFirst().handle)
            }
            return
        }

        if (pendingBatches.isEmpty()) {
            scheduleFrame()
            return
        }
        val current = ArrayList<PendingBatch>(pendingBatches.size)
        while (pendingBatches.isNotEmpty()) {
            current += pendingBatches.removeFirst()
        }
        if (renderer.isLayoutInProgress()) {
            current.asReversed().forEach(pendingBatches::addFirst)
            scheduleFrame()
            return
        }
        val started = System.nanoTime()
        var committed = false
        Trace.beginSection("PamNative.mount")
        try {
            runCatching {
                renderer.commit(current.map(PendingBatch::mutations))
            }.onSuccess {
                committed = true
            }.onFailure {
                reportError(it.message ?: "Cannot render native batch")
            }
        } finally {
            Trace.endSection()
        }
        current.forEach { batch -> releaseBatch(batch.handle) }
        val runtimeStats = stats()
        val metrics = RuntimeFrameMetrics(
            batches = current.size,
            decodeNanos = current.sumOf(PendingBatch::decodeNanos),
            mountNanos = System.nanoTime() - started,
            stats = runtimeStats,
        )
        if (BuildConfig.DEBUG || BuildConfig.BUILD_TYPE == "benchmark") {
            Log.d(
                PERFORMANCE_LOG_TAG,
                "batches=${metrics.batches} decodeNs=${metrics.decodeNanos} " +
                    "mountNs=${metrics.mountNanos} " +
                    "full=${runtimeStats.fullCommits} patch=${runtimeStats.patchCommits} " +
                    "inBytes=${runtimeStats.inputBytes} outBytes=${runtimeStats.outputBytes} " +
                    "buffers=${ownedBatchHandles.size}",
            )
        }
        if (committed) {
            completeHotReload(failed = false)
            onFrameCommitted(metrics)
        }
        scheduleFrame()
    }

    private fun releaseBatch(batchHandle: Long) {
        if (ownedBatchHandles.remove(batchHandle)) {
            nativeReleaseBatch(batchHandle)
        }
    }

    private fun completeHotReload(failed: Boolean) {
        val timing = hotReloadLatency.complete(System.nanoTime(), failed) ?: return
        onDiagnostic(
            RuntimeDiagnostic(
                kind = RuntimeDiagnosticKind.HOT_RELOAD,
                label = if (failed) "confirmed version to failure" else "confirmed version to first frame",
                durationNanos = timing.durationNanos,
                failed = timing.failed,
                requestBytes = timing.bundleBytes,
            )
        )
    }

    companion object {
        private const val EVENT_BACK = 3
        private const val MAX_PAYLOAD_BYTES = 1024 * 1024
        private const val MAX_PENDING_EVENTS = 256
        private const val PERFORMANCE_LOG_TAG = "PamNativePerf"
        private val COALESCED_EVENTS = setOf(
            9, // scroll
            17, // dimensions
            20, // image progress
            25, // input selection
            26, // input content size
            30, // pointer move
        )

        init {
            System.loadLibrary("pam_native_android")
        }
    }
}

private data class EventIdentity(
    val nodeId: Long,
    val kind: Int,
)

private data class PendingEvent(
    val nodeId: Long,
    val kind: Int,
    val payload: ByteArray,
)

data class RuntimeStats(
    val commits: Long,
    val nodes: Long,
    val created: Long,
    val removed: Long,
    val updated: Long,
    val retainedBytes: Long,
    val fullCommits: Long,
    val patchCommits: Long,
    val inputBytes: Long,
    val outputBytes: Long,
    val decodeP95Micros: Long = 0,
    val reconcileP95Micros: Long = 0,
    val layoutP95Micros: Long = 0,
    val encodeP95Micros: Long = 0,
    val coalescedCommands: Long = 0,
    val bufferReuses: Long = 0,
    val reusedBufferBytes: Long = 0,
    val measuredFrames: Long = 0,
    val deadlineMisses: Long = 0,
)

data class RuntimeFrameMetrics(
    val batches: Int,
    val decodeNanos: Long,
    val mountNanos: Long,
    val stats: RuntimeStats,
)

private data class PendingBatch(
    val mutations: List<Mutation>,
    val handle: Long,
    val decodeNanos: Long,
)

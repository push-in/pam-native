package dev.pam.nativeapp.render

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Typeface
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import dev.pam.nativeapp.protocol.PackedSectionList
import dev.pam.nativeapp.protocol.PackedStringList
import java.util.Collections
import java.util.IdentityHashMap
import kotlin.math.abs
import kotlin.math.max

internal class PamRecyclerList(context: Context) : RecyclerView(context) {
    private var rowHeight = 48f
    private var horizontal = false
    private var columns = 1
    private var inverted = false
    private var prefetchItems = 5
    private var adaptivePrefetchItems = prefetchItems
    private var lastScrollNanos = 0L
    private var initialIndex = 0
    private var initialPositionApplied = false
    private var scrollEnabled = true
    private var showsScrollIndicator = true
    private var removeClippedSubviews = true
    private var rowTextColor = context.themeColor(
        android.R.attr.textColorPrimary,
        Color.BLACK,
    )
    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop
    private var touchDownX = 0f
    private var touchDownY = 0f
    private var touchMoved = false
    private var viewportChanged: ((Float, Int, Int, Int) -> Unit)? = null
    private var richIds: List<Long> = emptyList()
    private var richExtents: Map<Long, Int> = emptyMap()
    private val accessibilityModes = IdentityHashMap<View, Int>()

    init {
        itemAnimator = null
        // PamScrollContainer coordinates ownership explicitly so a bounded
        // list and its page never consume the same drag simultaneously.
        isNestedScrollingEnabled = false
        clipChildren = true
        clipToPadding = false
        setHasFixedSize(true)
        updateLayoutManager()
        addOnScrollListener(object : OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                updateAdaptivePrefetch(if (horizontal) dx else dy)
                updateAccessibilityVisibility()
                dispatchViewport()
            }
        })
    }

    override fun onChildAttachedToWindow(child: View) {
        accessibilityModes.putIfAbsent(child, child.importantForAccessibility)
        super.onChildAttachedToWindow(child)
        updateAccessibilityVisibility()
    }

    override fun onChildDetachedFromWindow(child: View) {
        accessibilityModes.remove(child)?.let { child.importantForAccessibility = it }
        super.onChildDetachedFromWindow(child)
    }

    override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
        super.onLayout(changed, left, top, right, bottom)
        updateAccessibilityVisibility()
    }

    /**
     * RecyclerView deliberately lays out prefetched rows beyond its clipped
     * viewport. Android's accessibility snapshot can otherwise intersect a
     * descendant with the clip and publish an inverted rectangle. Keep those
     * rows mounted for performance, but hide only fully offscreen rows.
     * Partially visible rows must remain reachable, including rows taller than
     * the viewport. Restore the original mode before a holder is recycled.
     */
    private fun updateAccessibilityVisibility() {
        val viewportLeft = paddingLeft
        val viewportTop = paddingTop
        val viewportRight = width - paddingRight
        val viewportBottom = height - paddingBottom
        for (index in 0 until childCount) {
            val child = getChildAt(index)
            val original = accessibilityModes[child] ?: child.importantForAccessibility.also {
                accessibilityModes[child] = it
            }
            val intersectsViewport = child.right > viewportLeft &&
                child.bottom > viewportTop &&
                child.left < viewportRight &&
                child.top < viewportBottom
            val desired = if (intersectsViewport) {
                original
            } else {
                View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
            }
            if (child.importantForAccessibility != desired) {
                child.importantForAccessibility = desired
            }
        }
    }

    fun setItems(items: PackedStringList?) {
        adapter = items?.let { PackedStringRecyclerAdapter(context, it) }
        configureAdapter()
        applyInitialPosition()
    }

    fun setSections(sections: PackedSectionList?) {
        adapter = sections?.let { PackedSectionRecyclerAdapter(context, it) }
        configureAdapter()
        updateHeaderSpans()
        applyInitialPosition()
    }

    fun setRichItems(
        ids: List<Long>,
        extents: Map<Long, Float>,
        mount: (Long, FrameLayout) -> Unit,
        unmount: (Long, FrameLayout) -> Unit,
    ) {
        val pixelExtents = extents.mapValues { (_, value) -> dp(value.coerceAtLeast(1f)) }
        richIds = ids
        richExtents = pixelExtents
        val current = adapter as? RichRecyclerAdapter
        if (current == null) {
            adapter = RichRecyclerAdapter(
                context,
                ids,
                pixelExtents,
                mount,
                unmount,
            )
        } else {
            current.submit(ids, pixelExtents)
        }
        configureAdapter()
        updateHeaderSpans()
        applyInitialPosition()
    }

    fun scrollToLogicalOffset(value: Float) {
        val targetPx = dp(value.coerceAtLeast(0f))
        if (richIds.isEmpty()) {
            scrollBy(
                if (horizontal) targetPx - computeHorizontalScrollOffset() else 0,
                if (horizontal) 0 else targetPx - computeVerticalScrollOffset(),
            )
            return
        }
        val position = virtualScrollPosition(
            richIds.map { richExtents[it] ?: dp(rowHeight) },
            targetPx,
        )
        (layoutManager as? LinearLayoutManager)?.scrollToPositionWithOffset(
            position.index,
            -position.offset,
        )
        dispatchViewport()
    }

    fun setRowHeight(value: Float) {
        rowHeight = value.coerceAtLeast(1f)
        configureAdapter()
        updatePrefetch()
    }

    fun setHorizontal(value: Boolean) {
        if (horizontal == value) return
        horizontal = value
        if (value) columns = 1
        updateLayoutManager()
    }

    fun setColumns(value: Int) {
        val next = if (horizontal) 1 else value.coerceAtLeast(1)
        if (columns == next) return
        columns = next
        updateLayoutManager()
    }

    fun setInverted(value: Boolean) {
        if (inverted == value) return
        inverted = value
        updateLayoutManager()
    }

    fun setPrefetchItems(value: Int) {
        prefetchItems = value.coerceIn(1, MAX_PREFETCH_ITEMS)
        adaptivePrefetchItems = prefetchItems
        updatePrefetch()
    }

    fun setInitialIndex(value: Int) {
        val next = value.coerceAtLeast(0)
        if (initialIndex == next && initialPositionApplied) return
        initialIndex = next
        initialPositionApplied = false
        applyInitialPosition()
    }

    fun setRemoveClippedSubviews(value: Boolean) {
        removeClippedSubviews = value
        updatePrefetch()
    }

    fun setScrollEnabled(value: Boolean) {
        scrollEnabled = value
        isEnabled = value
        if (!value) stopScroll()
    }

    fun setShowsScrollIndicator(value: Boolean) {
        showsScrollIndicator = value
        isVerticalScrollBarEnabled = value && !horizontal
        isHorizontalScrollBarEnabled = value && horizontal
    }

    fun setTextColor(value: Int) {
        if (rowTextColor == value) return
        rowTextColor = value
        configureAdapter()
    }

    fun setOnViewportChanged(listener: ((Float, Int, Int, Int) -> Unit)?) {
        viewportChanged = listener
    }

    fun trimMemory(critical: Boolean) {
        if (!critical) return
        stopScroll()
        recycledViewPool.clear()
        setItemViewCacheSize(0)
        adaptivePrefetchItems = 0
        lastScrollNanos = 0L
        (layoutManager as? PrefetchLayoutManager)?.apply {
            prefetchCount = 0
            extraLayoutSpace = 0
        }
    }

    override fun dispatchTouchEvent(event: MotionEvent): Boolean {
        if (event.actionMasked == MotionEvent.ACTION_DOWN && scrollEnabled) {
            // Run before RecyclerView dispatches DOWN to a row child. Waiting
            // for onInterceptTouchEvent is too late when the row itself owns
            // the first phase of the gesture inside a platform ScrollView.
            parent?.requestDisallowInterceptTouchEvent(canConsumeScrollGesture())
        }
        return super.dispatchTouchEvent(event)
    }

    private fun canConsumeScrollGesture(): Boolean {
        val count = adapter?.itemCount ?: 0
        if (count <= 0) return false
        val hasOverflow = if (horizontal) {
            count.toLong() * dp(rowHeight) > width
        } else if (richIds.isNotEmpty()) {
            richIds.sumOf { richExtents[it]?.toLong() ?: dp(rowHeight).toLong() } > height
        } else {
            val rows = (count + columns.coerceAtLeast(1) - 1) /
                columns.coerceAtLeast(1)
            rows.toLong() * dp(rowHeight) > height
        }
        return hasOverflow || if (horizontal) {
            canScrollHorizontally(-1) || canScrollHorizontally(1)
        } else {
            canScrollVertically(-1) || canScrollVertically(1)
        }
    }

    internal fun hasScrollableContent(): Boolean = canConsumeScrollGesture()

    internal fun canScrollInDirection(direction: Int): Boolean {
        val manager = layoutManager as? LinearLayoutManager ?: return false
        val count = adapter?.itemCount ?: 0
        if (count <= 0) return false
        if (direction > 0) {
            val last = manager.findLastVisibleItemPosition()
            val view = manager.findViewByPosition(last)
            val edge = if (horizontal) {
                (view?.left ?: 0) + (view?.width?.takeIf { it > 0 } ?: dp(rowHeight))
            } else {
                (view?.top ?: 0) + (view?.height?.takeIf { it > 0 } ?: dp(rowHeight))
            }
            val viewport = if (horizontal) width - paddingRight else height - paddingBottom
            return last < count - 1 || edge > viewport
        }
        val first = manager.findFirstVisibleItemPosition()
        val view = manager.findViewByPosition(first)
        val edge = if (horizontal) view?.left ?: 0 else view?.top ?: 0
        val viewport = if (horizontal) paddingLeft else paddingTop
        return first > 0 || edge < viewport
    }

    override fun onInterceptTouchEvent(event: MotionEvent): Boolean {
        if (!scrollEnabled) return false
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                touchDownX = event.x
                touchDownY = event.y
                // PamScrollContainer intentionally uses the platform
                // ScrollView for native parity. It is not a
                // NestedScrollingParent, so an overflowing RecyclerView must
                // retain the gesture until it reaches its own boundary.
                // Otherwise the page steals every vertical drag and rows
                // beyond the list viewport become unreachable.
                parent?.requestDisallowInterceptTouchEvent(
                    canConsumeScrollGesture(),
                )
            }
            MotionEvent.ACTION_MOVE -> {
                val delta = if (horizontal) {
                    event.x - touchDownX
                } else {
                    event.y - touchDownY
                }
                val direction = if (delta < 0f) 1 else -1
                val canScroll = canScrollInDirection(direction)
                if (abs(delta) > touchSlop && !canScroll) {
                    parent?.requestDisallowInterceptTouchEvent(false)
                    return false
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                parent?.requestDisallowInterceptTouchEvent(false)
        }
        return super.onInterceptTouchEvent(event)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (!scrollEnabled) return false
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                touchDownX = event.x
                touchDownY = event.y
                touchMoved = false
            }
            MotionEvent.ACTION_MOVE -> {
                if (
                    abs(event.x - touchDownX) > touchSlop ||
                    abs(event.y - touchDownY) > touchSlop
                ) {
                    touchMoved = true
                }
            }
        }
        val handled = super.onTouchEvent(event)
        if (handled && event.actionMasked == MotionEvent.ACTION_UP && !touchMoved) {
            performClick()
        }
        if (
            event.actionMasked == MotionEvent.ACTION_UP ||
            event.actionMasked == MotionEvent.ACTION_CANCEL
        ) {
            touchMoved = false
        }
        return handled
    }

    override fun performClick(): Boolean = super.performClick()

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        repairEmptyRichHolders()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == VISIBLE) repairEmptyRichHolders()
    }

    override fun onVisibilityAggregated(isVisible: Boolean) {
        super.onVisibilityAggregated(isVisible)
        if (isVisible) repairEmptyRichHolders()
    }

    override fun draw(canvas: Canvas) {
        val checkpoint = canvas.save()
        canvas.clipRect(0f, 0f, width.toFloat(), height.toFloat())
        super.draw(canvas)
        canvas.restoreToCount(checkpoint)
    }

    private fun updateLayoutManager() {
        val previous = layoutManager as? LinearLayoutManager
        val position = previous?.findFirstVisibleItemPosition()?.coerceAtLeast(0) ?: 0
        val previousHorizontal = previous?.orientation == HORIZONTAL
        val offset = previous
            ?.findViewByPosition(position)
            ?.let {
                if (previousHorizontal) {
                    it.left - paddingLeft
                } else {
                    it.top - paddingTop
                }
            }
            ?: 0
        val orientation = if (horizontal) HORIZONTAL else VERTICAL
        layoutManager = if (columns > 1 && !horizontal) {
            PamGridLayoutManager(
                context,
                columns,
                orientation,
                inverted,
            )
        } else {
            PamLinearLayoutManager(
                context,
                orientation,
                inverted,
            )
        }
        (layoutManager as LinearLayoutManager).stackFromEnd = inverted
        configureAdapter()
        updateHeaderSpans()
        updatePrefetch()
        if ((adapter?.itemCount ?: 0) > 0) {
            (layoutManager as LinearLayoutManager).scrollToPositionWithOffset(position, offset)
        }
        setShowsScrollIndicator(showsScrollIndicator)
    }

    private fun updatePrefetch() {
        val extent = dp(rowHeight)
        (layoutManager as? PrefetchLayoutManager)?.apply {
            prefetchCount = adaptivePrefetchItems
            extraLayoutSpace = extent * adaptivePrefetchItems
        }
        val requestedCache = adaptivePrefetchItems * max(1, columns)
        val cache = if (removeClippedSubviews) {
            requestedCache
        } else {
            max(requestedCache, (adapter?.itemCount ?: 0).coerceAtMost(64))
        }
        setItemViewCacheSize(cache.coerceAtMost(64))
        val recycled = (adaptivePrefetchItems * max(1, columns) * 2).coerceAtMost(96)
        recycledViewPool.setMaxRecycledViews(PackedRowAdapter.TYPE_ITEM, recycled)
        recycledViewPool.setMaxRecycledViews(PackedRowAdapter.TYPE_HEADER, adaptivePrefetchItems)
    }

    private fun updateAdaptivePrefetch(deltaPixels: Int) {
        if (deltaPixels == 0) return
        val now = System.nanoTime()
        val elapsed = now - lastScrollNanos
        lastScrollNanos = now
        if (elapsed <= 0L || elapsed > 250_000_000L) {
            if (adaptivePrefetchItems == 0) {
                adaptivePrefetchItems = prefetchItems
                updatePrefetch()
            }
            return
        }
        val rowsPerSecond = abs(deltaPixels).toDouble() / dp(rowHeight) * 1_000_000_000.0 / elapsed
        val next = (prefetchItems + (rowsPerSecond * 0.15).toInt())
            .coerceIn(prefetchItems, MAX_PREFETCH_ITEMS)
        if (next == adaptivePrefetchItems) return
        adaptivePrefetchItems = next
        updatePrefetch()
    }

    private fun configureAdapter() {
        (adapter as? PackedRowAdapter)?.configure(
            extent = dp(rowHeight),
            horizontal = horizontal,
            textColor = rowTextColor,
        )
        (adapter as? RichRecyclerAdapter)?.configure(
            extent = dp(rowHeight),
            horizontal = horizontal,
        )
    }

    private fun updateHeaderSpans() {
        val grid = layoutManager as? GridLayoutManager ?: return
        val rows = adapter as? PackedRowAdapter ?: return
        grid.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int =
                if (rows.isHeader(position)) grid.spanCount else 1
        }
    }

    private fun applyInitialPosition() {
        if (initialPositionApplied) return
        val count = adapter?.itemCount ?: 0
        if (count == 0) return
        val target = initialIndex.coerceAtMost(count - 1)
        post {
            (layoutManager as? LinearLayoutManager)
                ?.scrollToPositionWithOffset(target, 0)
            initialPositionApplied = true
        }
    }

    private fun dispatchViewport() {
        val layout = layoutManager as? LinearLayoutManager ?: return
        val first = layout.findFirstVisibleItemPosition().coerceAtLeast(0)
        val last = layout.findLastVisibleItemPosition()
        val visible = if (last >= first) last - first + 1 else 0
        val total = adapter?.itemCount ?: 0
        val offset = if (horizontal) {
            computeHorizontalScrollOffset()
        } else {
            computeVerticalScrollOffset()
        } / resources.displayMetrics.density
        viewportChanged?.invoke(offset, first, visible, total)
    }

    private fun repairEmptyRichHolders() {
        post {
            (adapter as? RichRecyclerAdapter)?.remountEmptyHolders()
        }
    }

    private fun dp(value: Float): Int =
        max(1, (value * resources.displayMetrics.density + 0.5f).toInt())

    private interface PrefetchLayoutManager {
        var prefetchCount: Int
        var extraLayoutSpace: Int
    }

    private class PamLinearLayoutManager(
        context: Context,
        orientation: Int,
        reverseLayout: Boolean,
    ) : LinearLayoutManager(context, orientation, reverseLayout), PrefetchLayoutManager {
        override var prefetchCount = 5
            set(value) {
                field = value
                initialPrefetchItemCount = value
                isItemPrefetchEnabled = value > 0
            }
        override var extraLayoutSpace = 0

        override fun calculateExtraLayoutSpace(
            state: State,
            extraLayoutSpace: IntArray,
        ) {
            super.calculateExtraLayoutSpace(state, extraLayoutSpace)
            extraLayoutSpace[0] = max(extraLayoutSpace[0], this.extraLayoutSpace)
            extraLayoutSpace[1] = max(extraLayoutSpace[1], this.extraLayoutSpace)
        }
    }

    private class PamGridLayoutManager(
        context: Context,
        spanCount: Int,
        orientation: Int,
        reverseLayout: Boolean,
    ) : GridLayoutManager(
        context,
        spanCount,
        orientation,
        reverseLayout,
    ), PrefetchLayoutManager {
        override var prefetchCount = 5
            set(value) {
                field = value
                initialPrefetchItemCount = value
                isItemPrefetchEnabled = value > 0
            }
        override var extraLayoutSpace = 0

        override fun calculateExtraLayoutSpace(
            state: State,
            extraLayoutSpace: IntArray,
        ) {
            super.calculateExtraLayoutSpace(state, extraLayoutSpace)
            extraLayoutSpace[0] = max(extraLayoutSpace[0], this.extraLayoutSpace)
            extraLayoutSpace[1] = max(extraLayoutSpace[1], this.extraLayoutSpace)
        }
    }

    private companion object {
        const val MAX_PREFETCH_ITEMS = 32
    }
}

internal data class VirtualScrollPosition(val index: Int, val offset: Int)

internal fun virtualScrollPosition(extents: List<Int>, target: Int): VirtualScrollPosition {
    if (extents.isEmpty()) return VirtualScrollPosition(0, 0)
    var remaining = target.coerceAtLeast(0)
    for ((index, extent) in extents.withIndex()) {
        val safeExtent = extent.coerceAtLeast(1)
        if (remaining < safeExtent || index == extents.lastIndex) {
            return VirtualScrollPosition(index, remaining.coerceAtMost(safeExtent - 1))
        }
        remaining -= safeExtent
    }
    return VirtualScrollPosition(extents.lastIndex, 0)
}

private class RichRecyclerAdapter(
    private val context: Context,
    ids: List<Long>,
    extents: Map<Long, Int>,
    private val mount: (Long, FrameLayout) -> Unit,
    private val unmount: (Long, FrameLayout) -> Unit,
) : RecyclerView.Adapter<RichRecyclerAdapter.RichHolder>() {
    private var ids = ids.toList()
    private var extents = extents.toMap()
    private var extent = dp(48f)
    private var horizontal = false
    private val boundHolders: MutableSet<RichHolder> = Collections.newSetFromMap(
        IdentityHashMap(),
    )
    private val emptyRemountAttempts = IdentityHashMap<RichHolder, Long>()

    init {
        setHasStableIds(true)
    }

    fun submit(next: List<Long>, nextExtents: Map<Long, Int>) {
        if (ids == next && extents == nextExtents) {
            remountEmptyHolders()
            return
        }
        val previous = ids
        val previousExtents = extents
        val replacement = next.toList()
        val replacementExtents = nextExtents.toMap()
        if (previous == replacement) {
            extents = replacementExtents
            boundHolders.forEach { holder ->
                val id = holder.boundId
                if (
                    id != RecyclerView.NO_ID &&
                    previousExtents[id] != replacementExtents[id]
                ) {
                    applyLayout(holder.container, id)
                }
            }
            return
        }
        val diff = DiffUtil.calculateDiff(
            object : DiffUtil.Callback() {
                override fun getOldListSize(): Int = previous.size

                override fun getNewListSize(): Int = replacement.size

                override fun areItemsTheSame(oldPosition: Int, newPosition: Int): Boolean =
                    previous[oldPosition] == replacement[newPosition]

                override fun areContentsTheSame(oldPosition: Int, newPosition: Int): Boolean {
                    val oldId = previous[oldPosition]
                    val newId = replacement[newPosition]
                    return previousExtents[oldId] == replacementExtents[newId]
                }

                override fun getChangePayload(oldPosition: Int, newPosition: Int): Any =
                    PAYLOAD_LAYOUT
            },
            true,
        )
        ids = replacement
        extents = replacementExtents
        diff.dispatchUpdatesTo(this)
    }

    fun remountEmptyHolders() {
        boundHolders
            .mapNotNull { holder ->
                val id = holder.boundId
                val position = ids.indexOf(id)
                position.takeIf {
                    richHolderNeedsResumeRebind(
                        id,
                        holder.container.childCount,
                        position,
                        emptyRemountAttempts[holder],
                    )
                }?.also {
                    emptyRemountAttempts[holder] = id
                }
            }
            .distinct()
            .forEach { position -> notifyItemChanged(position, PAYLOAD_LAYOUT) }
    }

    fun configure(extent: Int, horizontal: Boolean) {
        if (this.extent == extent && this.horizontal == horizontal) return
        this.extent = extent
        this.horizontal = horizontal
        notifyItemRangeChanged(0, itemCount, PAYLOAD_LAYOUT)
    }

    override fun getItemCount(): Int = ids.size

    override fun getItemId(position: Int): Long = ids[position]

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RichHolder =
        RichHolder(FrameLayout(context).apply {
            clipChildren = true
            clipToPadding = true
            importantForAccessibility = android.view.View.IMPORTANT_FOR_ACCESSIBILITY_NO
        })

    override fun onBindViewHolder(holder: RichHolder, position: Int) {
        bind(holder, ids[position])
    }

    override fun onBindViewHolder(
        holder: RichHolder,
        position: Int,
        payloads: MutableList<Any>,
    ) {
        val id = ids[position]
        if (
            payloads.size == 1 &&
            payloads[0] === PAYLOAD_LAYOUT &&
            !richHolderNeedsFullBind(holder.boundId, id, holder.container.childCount)
        ) {
            applyLayout(holder.container, id)
        } else {
            bind(holder, id)
        }
    }

    override fun onViewRecycled(holder: RichHolder) {
        boundHolders.remove(holder)
        emptyRemountAttempts.remove(holder)
        holder.boundId.takeIf { it != RecyclerView.NO_ID }?.let {
            unmount(it, holder.container)
        }
        holder.boundId = RecyclerView.NO_ID
        holder.container.removeAllViews()
        super.onViewRecycled(holder)
    }

    private fun bind(holder: RichHolder, id: Long) {
        val previous = holder.boundId
        if (previous != RecyclerView.NO_ID && previous != id) {
            emptyRemountAttempts.remove(holder)
            unmount(previous, holder.container)
            holder.container.removeAllViews()
        }
        applyLayout(holder.container, id)
        mount(id, holder.container)
        holder.boundId = id
        boundHolders += holder
        if (holder.container.childCount > 0) {
            emptyRemountAttempts.remove(holder)
        }
    }

    private fun applyLayout(container: FrameLayout, id: Long) {
        val itemExtent = extents[id] ?: extent
        val width = if (horizontal) itemExtent else ViewGroup.LayoutParams.MATCH_PARENT
        val height = if (horizontal) ViewGroup.LayoutParams.MATCH_PARENT else itemExtent
        val params = container.layoutParams as? RecyclerView.LayoutParams
        if (params == null) {
            container.layoutParams = RecyclerView.LayoutParams(width, height)
            return
        }
        if (params.width == width && params.height == height) return
        params.width = width
        params.height = height
        container.requestLayout()
    }

    private fun dp(value: Float): Int =
        (value * context.resources.displayMetrics.density + 0.5f).toInt()

    class RichHolder(val container: FrameLayout) : RecyclerView.ViewHolder(container) {
        var boundId: Long = RecyclerView.NO_ID
    }

    private companion object {
        val PAYLOAD_LAYOUT = Any()
    }
}

internal fun richHolderNeedsFullBind(boundId: Long, requestedId: Long, childCount: Int): Boolean =
    boundId != requestedId || childCount == 0

internal fun richHolderNeedsResumeRebind(
    boundId: Long,
    childCount: Int,
    position: Int,
    lastAttemptedId: Long? = null,
): Boolean = boundId != RecyclerView.NO_ID &&
    childCount == 0 &&
    position >= 0 &&
    lastAttemptedId != boundId

private abstract class PackedRowAdapter(
    private val context: Context,
) : RecyclerView.Adapter<PackedRowAdapter.RowHolder>() {
    private var extent = dp(48f)
    private var horizontal = false
    private var textColor = context.themeColor(
        android.R.attr.textColorPrimary,
        Color.BLACK,
    )
    private val headerBackground = context.themeColor(
        android.R.attr.colorAccent,
        0xFF00875A.toInt(),
    )
    private val headerForeground = context.themeColor(
        android.R.attr.colorAccent,
        0xFF006C49.toInt(),
    )

    init {
        setHasStableIds(false)
    }

    fun configure(extent: Int, horizontal: Boolean, textColor: Int) {
        this.extent = extent
        this.horizontal = horizontal
        this.textColor = textColor
        notifyItemRangeChanged(0, itemCount, PAYLOAD_LAYOUT)
    }

    open fun isHeader(position: Int): Boolean = false

    override fun getItemViewType(position: Int): Int =
        if (isHeader(position)) TYPE_HEADER else TYPE_ITEM

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowHolder =
        RowHolder(TextView(context).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20f), 0, dp(20f), 0)
            includeFontPadding = false
            setTextColor(textColor)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        })

    override fun onBindViewHolder(holder: RowHolder, position: Int) {
        bind(holder, position)
    }

    override fun onBindViewHolder(
        holder: RowHolder,
        position: Int,
        payloads: MutableList<Any>,
    ) {
        if (payloads.size == 1 && payloads[0] === PAYLOAD_LAYOUT) {
            applyLayout(holder.text)
            return
        }
        bind(holder, position)
    }

    private fun bind(holder: RowHolder, position: Int) {
        val header = isHeader(position)
        holder.text.apply {
            text = value(position)
            setTextColor(if (header) headerForeground else textColor)
            setTypeface(typeface, if (header) Typeface.BOLD else Typeface.NORMAL)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, if (header) 13f else 16f)
            letterSpacing = if (header) 0.035f else 0f
            setBackgroundColor(
                if (header) Color.argb(
                    24,
                    Color.red(headerBackground),
                    Color.green(headerBackground),
                    Color.blue(headerBackground),
                ) else Color.TRANSPARENT,
            )
            isEnabled = !header
        }
        applyLayout(holder.text)
    }

    private fun applyLayout(text: TextView) {
        val width = if (horizontal) extent else ViewGroup.LayoutParams.MATCH_PARENT
        val height = if (horizontal) ViewGroup.LayoutParams.MATCH_PARENT else extent
        val params = text.layoutParams as? RecyclerView.LayoutParams
        if (params == null) {
            text.layoutParams = RecyclerView.LayoutParams(width, height)
            return
        }
        if (params.width == width && params.height == height) return
        params.width = width
        params.height = height
        text.requestLayout()
    }

    protected abstract fun value(position: Int): String

    private fun dp(value: Float): Int =
        (value * context.resources.displayMetrics.density + 0.5f).toInt()

    class RowHolder(val text: TextView) : RecyclerView.ViewHolder(text)

    companion object {
        const val TYPE_HEADER = 0
        const val TYPE_ITEM = 1
        private val PAYLOAD_LAYOUT = Any()
    }
}

private fun Context.themeColor(attribute: Int, fallback: Int): Int {
    val value = TypedValue()
    if (!theme.resolveAttribute(attribute, value, true)) return fallback
    return when {
        value.resourceId != 0 ->
            ColorStateList.valueOf(getColor(value.resourceId)).defaultColor
        value.type in TypedValue.TYPE_FIRST_COLOR_INT..TypedValue.TYPE_LAST_COLOR_INT ->
            value.data
        else -> fallback
    }
}

private class PackedStringRecyclerAdapter(
    context: Context,
    private val items: PackedStringList,
) : PackedRowAdapter(context) {
    override fun getItemCount(): Int = items.size
    override fun value(position: Int): String = items[position]
}

private class PackedSectionRecyclerAdapter(
    context: Context,
    private val sections: PackedSectionList,
) : PackedRowAdapter(context) {
    override fun getItemCount(): Int = sections.size
    override fun value(position: Int): String = sections[position]
    override fun isHeader(position: Int): Boolean = sections.isHeader(position)
}

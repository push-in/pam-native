package dev.pam.nativeapp.modules

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import dev.pam.nativeapp.protocol.WireMap
import dev.pam.nativeapp.protocol.WireValue
import java.util.ArrayDeque
import org.json.JSONArray
import org.json.JSONObject

public object PamPushNotifications {
    private val lock = Any()
    private val events = ArrayDeque<ByteArray>()
    private var waiter: ModuleCompletion? = null
    private var preferences: SharedPreferences? = null

    @JvmStatic
    public fun attach(context: Context) {
        synchronized(lock) {
            if (preferences != null) return
            preferences = context.applicationContext.getSharedPreferences(
                PREFERENCES_NAME,
                Context.MODE_PRIVATE,
            )
            val stored = runCatching {
                JSONArray(preferences?.getString(PREFERENCES_EVENTS, "[]") ?: "[]")
            }.getOrDefault(JSONArray())
            for (index in 0 until stored.length()) {
                val encoded = stored.optString(index)
                val payload = runCatching {
                    Base64.decode(encoded, Base64.NO_WRAP)
                }.getOrNull() ?: continue
                if (payload.isNotEmpty()) events.addLast(payload)
            }
            while (events.size > MAX_QUEUED_EVENTS) events.removeFirst()
            persistLocked()
        }
    }

    @JvmStatic
    public fun reportReceived(
        id: String,
        title: String = "",
        body: String = "",
        dataJson: String = "{}",
        deepLink: String = "",
    ) {
        report(1, id, title, body, dataJson, deepLink)
    }

    /** Reports a received push that a PushRendering rule already displayed natively. */
    @JvmStatic
    public fun reportRendered(
        id: String,
        title: String = "",
        body: String = "",
        dataJson: String = "{}",
        deepLink: String = "",
    ) {
        report(1, id, title, body, dataJson, deepLink, rendered = true)
    }

    @JvmStatic
    public fun reportOpened(
        id: String,
        title: String = "",
        body: String = "",
        dataJson: String = "{}",
        deepLink: String = "",
    ) {
        report(2, id, title, body, dataJson, deepLink)
    }

    internal fun next(completion: ModuleCompletion) {
        val event = synchronized(lock) {
            require(waiter == null) { "Only one push listener can wait at a time" }
            if (events.isEmpty()) {
                waiter = completion
                null
            } else {
                events.removeFirst().also { persistLocked() }
            }
        }
        if (event != null) completion.complete(ModuleResultStatus.SUCCESS, event)
    }

    internal fun close(message: String) {
        val pending = synchronized(lock) {
            val value = waiter
            waiter = null
            value
        }
        pending?.complete(ModuleResultStatus.FAILURE, message.toByteArray())
    }

    internal fun prepareReload() {
        synchronized(lock) {
            waiter = null
        }
    }

    private fun report(
        event: Int,
        id: String,
        title: String,
        body: String,
        dataJson: String,
        deepLink: String,
        rendered: Boolean = false,
    ) {
        val payload = WireMap.encode(
            mapOf(
                "event" to WireValue.Integer(event.toLong()),
                "id" to WireValue.Text(id.take(512)),
                "title" to WireValue.Text(title.take(4_096)),
                "body" to WireValue.Text(body.take(16_384)),
                "data" to WireValue.Text(
                    runCatching { JSONObject(dataJson.take(MAX_DATA_BYTES)).toString() }
                        .getOrDefault("{}"),
                ),
                "deepLink" to WireValue.Text(deepLink.take(8_192)),
                "rendered" to WireValue.Flag(rendered),
            ),
        )
        val pending = synchronized(lock) {
            val value = waiter
            if (value == null) {
                if (events.size >= MAX_QUEUED_EVENTS) events.removeFirst()
                events.addLast(payload)
                persistLocked()
            } else {
                waiter = null
            }
            value
        }
        pending?.complete(ModuleResultStatus.SUCCESS, payload)
    }

    private fun persistLocked() {
        val storage = preferences ?: return
        val encoded = JSONArray()
        events.forEach { payload ->
            encoded.put(Base64.encodeToString(payload, Base64.NO_WRAP))
        }
        storage.edit().putString(PREFERENCES_EVENTS, encoded.toString()).apply()
    }

    private const val MAX_QUEUED_EVENTS = 64
    private const val MAX_DATA_BYTES = 256 * 1024
    private const val PREFERENCES_EVENTS = "events"
    private const val PREFERENCES_NAME = "pam-native-push"
}

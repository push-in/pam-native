<?php

declare(strict_types=1);

use Pam\Native\App;
use Pam\Native\AppState;
use Pam\Native\AccessibilityRole;
use Pam\Native\AccessibilityAction;
use Pam\Native\AccessibilityCheckedState;
use Pam\Native\AccessibilityImportance;
use Pam\Native\AccessibilityLiveRegion;
use Pam\Native\ActivityIndicatorSize;
use Pam\Native\AnimationKind;
use Pam\Native\AnimationKeyframe;
use Pam\Native\BottomSheetKeyboardBehavior;
use Pam\Native\Bridge\IdlCompiler;
use Pam\Native\AsyncStatus;
use Pam\Native\AsyncValue;
use Pam\Native\AsyncResource;
use Pam\Native\Component;
use Pam\Native\Contact;
use Pam\Native\CaptureType;
use Pam\Native\DrawingMode;
use Pam\Native\EventKind;
use Pam\Native\FileReference;
use Pam\Native\FileDownloadProgress;
use Pam\Native\FontStyle;
use Pam\Native\GestureComposition;
use Pam\Native\GestureDirection;
use Pam\Native\GestureEvent;
use Pam\Native\GestureState;
use Pam\Native\GestureType;
use Pam\Native\MediaType;
use Pam\Native\MediaAlbum;
use Pam\Native\MediaAsset;
use Pam\Native\MediaAssetPage;
use Pam\Native\MediaPickerType;
use Pam\Native\MediaCachePolicy;
use Pam\Native\MediaPriority;
use Pam\Native\NativeMenuItem;
use Pam\Native\PermissionDecision;
use Pam\Native\PermissionKind;
use Pam\Native\PermissionStatus;
use Pam\Native\PushEventType;
use Pam\Native\PushProvider;
use Pam\Native\ImageCachePolicy;
use Pam\Native\ImageErrorEvent;
use Pam\Native\ImageFit;
use Pam\Native\ImageLoadEvent;
use Pam\Native\ImageProgressEvent;
use Pam\Native\ImageResizeMethod;
use Pam\Native\InputAutoCapitalize;
use Pam\Native\InputAutofillImportance;
use Pam\Native\InputContentSizeEvent;
use Pam\Native\InputFormat;
use Pam\Native\InputKeyEvent;
use Pam\Native\InputMode;
use Pam\Native\InputSelectionEvent;
use Pam\Native\InputSubmitBehavior;
use Pam\Native\InputTextAlignVertical;
use Pam\Native\KeyboardType;
use Pam\Native\Jobs\BackgroundJobs;
use Pam\Native\IncomingShare;
use Pam\Native\Internal\Runtime;
use Pam\Native\Internal\BinaryValue;
use Pam\Native\Internal\PamPhpCompiler;
use Pam\Native\Internal\PamPhpPreloader;
use Pam\Native\Internal\PamPhpRegistry;
use Pam\Native\Internal\CssColor;
use Pam\Native\Internal\CompiledTemplateNode;
use Pam\Native\Internal\ScopedStyleCompiler;
use Pam\Native\Internal\ComponentLifecycle;
use Pam\Native\Internal\TemplateCompiler;
use Pam\Native\Internal\TemplateExpression;
use Pam\Native\Internal\TemplateRenderer;
use Pam\Native\Internal\TreeEncoder;
use Pam\Native\Internal\Wire;
use Pam\Native\Tooling\PamFormatter;
use Pam\Native\KeyboardAvoidingBehavior;
use Pam\Native\MemoryPressure;
use Pam\Native\MotionPreset;
use Pam\Native\HapticFeedback;
use Pam\Native\Http\Http;
use Pam\Native\Http\HttpResponse;
use Pam\Native\Http\OutboundTraceContext;
use Pam\Native\Database\SQLite;
use Pam\Native\NativeOperation;
use Pam\Native\Forms\FormStatus;
use Pam\Native\Forms\NativeForm;
use Pam\Native\Forms\Attributes\Email;
use Pam\Native\Forms\Attributes\Matches;
use Pam\Native\Forms\Attributes\MaxLength;
use Pam\Native\Forms\Attributes\MinLength;
use Pam\Native\Forms\Attributes\Required;
use Pam\Native\Navigation\NavigationOperation;
use Pam\Native\Navigation\NavigationAction;
use Pam\Native\Navigation\NavigationActionType;
use Pam\Native\Navigation\NavigationContainer;
use Pam\Native\Navigation\NavigationDevTools;
use Pam\Native\Navigation\NavigationEvent;
use Pam\Native\Navigation\NavigationEventType;
use Pam\Native\Navigation\NavigationGestureDirection;
use Pam\Native\Navigation\NavigationTransition;
use Pam\Native\Navigation\NavigationTraceKind;
use Pam\Native\Navigation\Navigator;
use Pam\Native\Navigation\Router;
use Pam\Native\Navigation\RouteContext;
use Pam\Native\Navigation\ScreenOptions;
use Pam\Native\Navigation\ScreenOptionsPatch;
use Pam\Native\Navigation\SharedTransitionResizeMode;
use Pam\Native\Navigation\SharedTransitionStyle;
use Pam\Native\Navigation\NavigationPresentation;
use Pam\Native\Navigation\NavigationRef;
use Pam\Native\Navigation\NavigationLifecycleAware;
use Pam\Native\Navigation\InteractsWithNavigationLifecycle;
use Pam\Native\Routing\Route;
use Pam\Native\Routing\RouteCodeGenerator;
use Pam\Native\Routing\Navigation as NamedNavigation;
use Pam\Native\Navigation\TabNavigator;
use Pam\Native\Navigation\TabPresentation;
use Pam\Native\ModalAnimationType;
use Pam\Native\ModalOrientation;
use Pam\Native\ModalPresentation;
use Pam\Native\Modules\NativeModuleResult;
use Pam\Native\Modules\NativeModules;
use Pam\Native\ModuleResultStatus;
use Pam\Native\NodeKind;
use Pam\Native\PointerEvents;
use Pam\Native\PressEvent;
use Pam\Native\ReturnKeyType;
use Pam\Native\RefreshIndicatorSize;
use Pam\Native\Renderable;
use Pam\Native\SafeAreaMode;
use Pam\Native\ScrollKeyboardDismissMode;
use Pam\Native\ScrollOverScrollMode;
use Pam\Native\ScrollIndicatorStyle;
use Pam\Native\ScrollTargetAlignment;
use Pam\Native\ServerDriven\ServerDrivenUi;
use Pam\Native\PositionType;
use Pam\Native\Plugin\PluginManager;
use Pam\Native\Plugin\PluginException;
use Pam\Native\PropKey;
use Pam\Native\Restorable;
use Pam\Native\State;
use Pam\Native\Store\Attributes\Computed as StoreComputed;
use Pam\Native\Store\ActionPolicy;
use Pam\Native\System\MediaCapture;
use Pam\Native\Store\Store;
use Pam\Native\Store\StoreChangeKind;
use Pam\Native\Store\StoreMiddleware;
use Pam\Native\Store\Stores;
use Pam\Native\Sync\MutationStatus;
use Pam\Native\Sync\OfflineMutationQueue;
use Pam\Native\StatusBarAppearance;
use Pam\Native\System\Haptics;
use Pam\Native\System\IncomingShares;
use Pam\Native\System\Caches;
use Pam\Native\System\Clipboard;
use Pam\Native\System\Contacts;
use Pam\Native\System\DeviceInfo;
use Pam\Native\System\Sensors;
use Pam\Native\System\Sms;
use Pam\Native\System\Location;
use Pam\Native\System\PushNotifications;
use Pam\Native\System\Files;
use Pam\Native\System\MediaLibrary;
use Pam\Native\LocationPosition;
use Pam\Native\System\AudioRecorder;
use Pam\Native\Storage\Storage;
use Pam\Native\AudioRecording;
use Pam\Native\SensorType;
use Pam\Native\Style;
use Pam\Native\TemplateRegistry;
use Pam\Native\TextDecoration;
use Pam\Native\TextBreakStrategy;
use Pam\Native\TextDataDetectorType;
use Pam\Native\TextEllipsizeMode;
use Pam\Native\TextHyphenationFrequency;
use Pam\Native\TextTransform;
use Pam\Native\Theme;
use Pam\Native\ThemeMode;
use Pam\Native\DesignTokens;
use Pam\Native\UserInterfaceAppearance;
use Pam\Native\View;
use Pam\Native\WindowMetrics;
use Pam\Native\UI\Button;
use Pam\Native\UI\Canvas;
use Pam\Native\UI\BottomSheet;
use Pam\Native\UI\GestureDetector;
use Pam\Native\UI\ActivityIndicator;
use Pam\Native\UI\Animated;
use Pam\Native\UI\Column;
use Pam\Native\UI\CustomView;
use Pam\Native\UI\DrawingCanvas;
use Pam\Native\UI\FlatList;
use Pam\Native\UI\Input;
use Pam\Native\UI\InteractionRegion;
use Pam\Native\UI\Image;
use Pam\Native\UI\ImageBackground;
use Pam\Native\UI\KeyboardAvoidingView;
use Pam\Native\UI\Modal;
use Pam\Native\UI\MediaPlayer;
use Pam\Native\UI\Pressable;
use Pam\Native\UI\RefreshControl;
use Pam\Native\UI\SafeAreaView;
use Pam\Native\UI\Screen;
use Pam\Native\UI\Scroll;
use Pam\Native\UI\SectionList;
use Pam\Native\UI\StatusBar;
use Pam\Native\UI\Suspense;
use Pam\Native\UI\Text;
use Pam\Native\UI\Toggle;
use Pam\Native\UI\VirtualGrid;
use Pam\Native\UI\VirtualizedList;
use Pam\Native\UI\WebView;
use Pam\Native\Worklets\Worklet;
use Pam\Native\Worklets\WorkletTarget;
use Pam\Native\Tests\Fixtures\ExamplePluginProvider;

spl_autoload_register(static function (string $class): void {
    $prefix = 'Pam\\Native\\';

    if (!str_starts_with($class, $prefix)) {
        return;
    }

    $path = __DIR__.'/../src/'.str_replace('\\', '/', substr($class, strlen($prefix))).'.php';

    if (is_file($path)) {
        require $path;
    }
});

require __DIR__.'/Fixtures/ExamplePluginProvider.php';
require __DIR__.'/Fixtures/TemplateEnumScope.php';

final class TestDiagnostics
{
    /** @var list<string> */
    public static array $messages = [];

    /** @var array{requestId: int, module: string, method: string, payload: string}|null */
    public static ?array $moduleCall = null;

    /** @var array{requestId: int, operation: int, payload: string}|null */
    public static ?array $typedCall = null;
}

final class TypedRouteTestScreen extends Component
{
    public function __construct(
        private readonly int $productId,
        private readonly bool $preview = false,
    ) {
    }

    public function render(): Renderable
    {
        return Screen::make(Text::make(
            "Product {$this->productId}".($this->preview ? ' preview' : ''),
        ));
    }
}

enum TypedRouteTestName: string
{
    case Home = 'home';
    case Product = 'product';
}

final class TemplateEnumScope
{
}

if (!function_exists('pam_native_error')) {
    function pam_native_error(string $message): void
    {
        TestDiagnostics::$messages[] = $message;
    }
}

if (!function_exists('pam_native_call')) {
    function pam_native_call(
        int $requestId,
        string $module,
        string $method,
        string $payload,
    ): void {
        TestDiagnostics::$moduleCall = [
            'requestId' => $requestId,
            'module' => $module,
            'method' => $method,
            'payload' => $payload,
        ];
    }
}

if (!function_exists('pam_native_call_typed')) {
    function pam_native_call_typed(
        int $requestId,
        int $operation,
        string $payload,
    ): void {
        TestDiagnostics::$typedCall = [
            'requestId' => $requestId,
            'operation' => $operation,
            'payload' => $payload,
        ];
    }
}

$stateDirectory = sys_get_temp_dir().'/pam-native-state-tests-'.getmypid();
putenv('PAM_NATIVE_STATE_DIR='.$stateDirectory);
if (is_file($stateDirectory.'/state.json')) {
    unlink($stateDirectory.'/state.json');
}

$assert = static function (bool $condition, string $message): void {
    if (!$condition) {
        throw new RuntimeException($message);
    }
};

$assert(
    CssColor::parse('transparent') === 0x00000000
        && CssColor::parse('#123') === 0xFF112233
        && CssColor::parse('#1234') === 0x44112233
        && CssColor::parse('#11223344') === 0x44112233
        && CssColor::parse('rgb(255 0 128 / 50%)') === 0x80FF0080
        && CssColor::parse('hsl(120deg 100% 25%)') === 0xFF008000
        && CssColor::parse('rebeccapurple') === 0xFF663399,
    'CSS colors must support transparent, modern hex, functions and named colors.',
);

$compiledCss = ScopedStyleCompiler::compile(
    <<<'CSS'
    :root {
        --font-ui: "asset://assets/fonts/SpaceGrotesk-Regular.ttf";
        --ink: #101410;
    }

    @font-face {
        font-family: "Space Grotesk";
        src: url(var(--font-ui));
        font-weight: 400;
        font-style: normal;
    }

    Text, .body-copy {
        color: var(--ink);
        font-family: var(--font-ui);
        text-decoration: underline;
    }

    .card {
        width: 100%;
        height: 50%;
        max-width: 92%;
        padding: 8px 16px 12px;
        margin: 1px 2px 3px 4px;
        border: 1.5px solid #101410;
        border-bottom: 2px solid #101410;
        border-left: 3px solid #101410;
        border-left-color: #D6ECDD;
        border-style: dashed;
        border-radius: 28px 28px 0 0;
        inset: 5px 6px 7px 8px;
        flex-wrap: wrap;
        translation-y: 28px;
    }

    .percent-position {
        left: 4%;
        top: 10%;
        right: 5%;
        bottom: 2%;
    }
    CSS,
    'ScopedStyleCompilerTest.pam.php',
);
$assert(
    $compiledCss['tags']['Text']['textColor'] === 0xFF101410
        && $compiledCss['classes']['body-copy']['fontFamily']
            === 'asset://assets/fonts/SpaceGrotesk-Regular.ttf'
        && $compiledCss['classes']['body-copy']['textDecoration'] === 'underline',
    'Scoped CSS must resolve variables in tag and class rules.',
);
$assert(
    $compiledCss['fonts']['Space Grotesk'][0] === [
        'source' => 'asset://assets/fonts/SpaceGrotesk-Regular.ttf',
        'weight' => '400',
        'style' => 'normal',
    ],
    'Scoped CSS must compile packaged @font-face aliases without a runtime registry.',
);
$assert(
    $compiledCss['classes']['card'] === [
        'widthPercent' => '100',
        'heightPercent' => '50',
        'maxWidthPercent' => '92',
        'paddingTop' => '8',
        'paddingRight' => '16',
        'paddingBottom' => '12',
        'paddingLeft' => '16',
        'marginTop' => '1',
        'marginRight' => '2',
        'marginBottom' => '3',
        'marginLeft' => '4',
        'borderWidth' => '1.5',
        'borderColor' => 0xFF101410,
        'borderBottomWidth' => '2',
        'borderLeftWidth' => '3',
        'borderColor' => 0xFFD6ECDD,
        'borderStyle' => 2,
        'borderTopLeftRadius' => '28',
        'borderTopRightRadius' => '28',
        'borderBottomRightRadius' => '0',
        'borderBottomLeftRadius' => '0',
        'top' => '5',
        'right' => '6',
        'bottom' => '7',
        'left' => '8',
        'flexWrap' => 'wrap',
        'translationY' => '28',
    ],
    'Scoped CSS must compile percentages and native box shorthands exactly.',
);
$assert(
    $compiledCss['classes']['percent-position'] === [
        'leftPercent' => '4',
        'topPercent' => '10',
        'rightPercent' => '5',
        'bottomPercent' => '2',
    ],
    'Scoped CSS must compile percentage position offsets exactly.',
);
$forwardVariableCss = ScopedStyleCompiler::compile(
    '.label { color: var(--label); } :root { --label: #334455; }',
    'ForwardVariable.pam.php',
);
$assert(
    $forwardVariableCss['classes']['label']['textColor'] === 0xFF334455,
    'Scoped CSS variables must be independent from declaration order.',
);
$modernCss = ScopedStyleCompiler::compile(
    <<<'CSS'
    :root {
        --fallback-ink: var(--missing-ink, rgb(12 34 56 / 75%));
        --space: 0.5rem;
    }

    Text { color: red; }
    .later { color: #1234; }
    .earlier { color: hsl(120 100% 25%); }
    .later {
        color: var(--fallback-ink);
        background: none;
        aspect-ratio: 16 / 9;
        padding-inline: var(--space) 1rem;
        margin-block: 2px 3px;
        inset-inline: 4px 5px;
        border: none;
        font-weight: bold;
        font-family: "Space Grotesk", sans-serif;
        opacity: 50%;
        transform: translateX(3px) translateY(-2dp) scale(1.25) rotate(0.5turn);
        object-fit: scale-down;
        visibility: visible;
        box-sizing: border-box;
    }
    CSS,
    'ModernCss.pam.php',
);
$assert(
    $modernCss['classes']['later'] === [
        'textColor' => 0xBF0C2238,
        'backgroundColor' => 0,
        'aspectRatio' => (string) (16 / 9),
        'paddingLeft' => '8',
        'paddingRight' => '16',
        'marginTop' => '2',
        'marginBottom' => '3',
        'left' => '4',
        'right' => '5',
        'borderWidth' => '0',
        'borderColor' => 0,
        'fontWeight' => '700',
        'fontFamily' => 'Space Grotesk',
        'opacity' => '0.5',
        'translationX' => '3',
        'translationY' => '-2',
        'scaleX' => '1.25',
        'scaleY' => '1.25',
        'rotation' => '180',
        'resizeMode' => 'contain',
        'visible' => true,
    ],
    'Modern scoped CSS values and native-safe shorthands must compile exactly.',
);
$assert(
    $modernCss['classCascade']['earlier']['textColor']['order'] === 2
        && $modernCss['classCascade']['later']['textColor']['order'] === 3,
    'Scoped CSS must index property source order for a deterministic constant-time cascade.',
);
$cyclicVariableRejected = false;
try {
    ScopedStyleCompiler::compile(
        ':root { --a: var(--b); --b: var(--a); } Text { color: var(--a); }',
        'CyclicVariables.pam.php',
    );
} catch (RuntimeException $error) {
    $cyclicVariableRejected = str_contains($error->getMessage(), 'Circular CSS variable');
}
$assert(
    $cyclicVariableRejected,
    'Scoped CSS must reject custom-property cycles during compilation.',
);

$cascadeTemplate = TemplateCompiler::compile(
    '<Column><Text class="later earlier">Styled</Text></Column>',
);
$cascadeStyled = new CompiledTemplateNode(
    kind: $cascadeTemplate->kind,
    name: $cascadeTemplate->name,
    attributes: [
        ...$cascadeTemplate->attributes,
        '__pamStyles' => json_encode($modernCss, JSON_THROW_ON_ERROR),
    ],
    source: $cascadeTemplate->source,
    line: $cascadeTemplate->line,
    column: $cascadeTemplate->column,
    value: $cascadeTemplate->value,
);
$cascadeStyled->children = $cascadeTemplate->children;
$cascadeElement = TemplateRenderer::render($cascadeStyled, null, []);
$cascadeText = $cascadeElement->children()[0];
$assert(
    $cascadeText->properties()[PropKey::TextColor->value] === 0xBF0C2238,
    'CSS class order in markup must not override stylesheet source order.',
);

$inheritCss = ScopedStyleCompiler::compile(
    <<<'CSS'
    @font-face {
        font-family: "Theme";
        src: url("asset://assets/fonts/Theme-Regular.ttf");
        font-weight: 400;
    }
    @font-face {
        font-family: "Theme";
        src: url("asset://assets/fonts/Theme-Bold.ttf");
        font-weight: 700;
    }
    .theme {
        color: #123;
        font-family: "Theme";
        font-size: 1rem;
        font-weight: normal;
        text-align: center;
    }
    .strong { font-weight: bold; }
    CSS,
    'InheritedCss.pam.php',
);
$inheritTemplate = TemplateCompiler::compile(
    '<Column class="theme"><Row><Text class="strong">Inherited</Text></Row></Column>',
);
$inheritStyled = new CompiledTemplateNode(
    kind: $inheritTemplate->kind,
    name: $inheritTemplate->name,
    attributes: [
        ...$inheritTemplate->attributes,
        '__pamStyles' => json_encode($inheritCss, JSON_THROW_ON_ERROR),
    ],
    source: $inheritTemplate->source,
    line: $inheritTemplate->line,
    column: $inheritTemplate->column,
    value: $inheritTemplate->value,
);
$inheritStyled->children = $inheritTemplate->children;
$inheritText = TemplateRenderer::render($inheritStyled, null, [])
    ->children()[0]
    ->children()[0];
$assert(
    $inheritText->properties()[PropKey::TextColor->value] === 0xFF112233
        && $inheritText->properties()[PropKey::FontSize->value] === 16
        && $inheritText->properties()[PropKey::FontFamily->value]
            === 'asset://assets/fonts/Theme-Bold.ttf'
        && !isset($inheritText->properties()[PropKey::FontWeight->value])
        && $inheritText->properties()[PropKey::TextAlign->value] === 2,
    'Text CSS properties and logical font families must inherit through native layout containers.',
);
$textAlignmentCss = ScopedStyleCompiler::compile(
    '.left { text-align: left; } .right { text-align: right; }',
    'TextAlignmentCss.pam.php',
);
$textAlignmentTemplate = TemplateCompiler::compile(
    '<Column><Text class="left">Left</Text><Text class="right">Right</Text></Column>',
);
$textAlignmentStyled = new CompiledTemplateNode(
    kind: $textAlignmentTemplate->kind,
    name: $textAlignmentTemplate->name,
    attributes: [
        ...$textAlignmentTemplate->attributes,
        '__pamStyles' => json_encode($textAlignmentCss, JSON_THROW_ON_ERROR),
    ],
    source: $textAlignmentTemplate->source,
    line: $textAlignmentTemplate->line,
    column: $textAlignmentTemplate->column,
    value: $textAlignmentTemplate->value,
);
$textAlignmentStyled->children = $textAlignmentTemplate->children;
$textAlignmentChildren = TemplateRenderer::render($textAlignmentStyled, null, [])
    ->children();
$assert(
    $textAlignmentChildren[0]->properties()[PropKey::TextAlign->value]
        === \Pam\Native\TextAlignment::Start->value
        && $textAlignmentChildren[1]->properties()[PropKey::TextAlign->value]
        === \Pam\Native\TextAlignment::End->value,
    'CSS text-align must accept the web left/right aliases.',
);
$cssImportRoot = sys_get_temp_dir().'/pam-native-css-import-'.getmypid();
mkdir($cssImportRoot.'/src/styles', 0o755, true);
mkdir($cssImportRoot.'/src/screens', 0o755, true);
file_put_contents($cssImportRoot.'/composer.json', "{}\n");
file_put_contents(
    $cssImportRoot.'/src/styles/tokens.css',
    ":root { --brand-ink: #163D2A; }\n",
);
file_put_contents(
    $cssImportRoot.'/src/styles/brand.css',
    <<<'CSS'
@import "./tokens.css";

@font-face {
    font-family: "Brand";
    src: url("asset://assets/fonts/Brand-Regular.ttf");
    font-weight: 400;
}

Text {
    color: var(--brand-ink);
    font-family: "Brand";
}
CSS,
);
$cssImportComponent = $cssImportRoot.'/src/screens/Profile.pam.php';
file_put_contents($cssImportComponent, "<?php\n");
$importedCss = ScopedStyleCompiler::compile(
    '@import "../styles/brand.css"; Text { font-size: 15px; }',
    $cssImportComponent,
);
$assert(
    $importedCss['tags']['Text']['textColor'] === 0xFF163D2A
        && $importedCss['tags']['Text']['fontFamily']
            === 'Brand'
        && $importedCss['tags']['Text']['fontSize'] === '15'
        && $importedCss['fonts']['Brand'][0]['source']
            === 'asset://assets/fonts/Brand-Regular.ttf',
    'Scoped CSS imports must inline nested project styles and preserve local cascade order.',
);
$formattedImportPam = PamFormatter::format(
    <<<'PAM'
<?php
?>
<template><Text>Brand</Text></template><style scoped>@import url('../styles/brand.css'); Text { font-size: 15px; }</style>
PAM,
    $cssImportComponent,
);
$assert(
    str_contains($formattedImportPam, '    @import "../styles/brand.css";')
        && PamFormatter::format($formattedImportPam, $cssImportComponent)
            === $formattedImportPam,
    'PAM formatter must normalize and preserve compile-time CSS imports.',
);
$outsideCss = sys_get_temp_dir().'/pam-native-css-outside-'.getmypid().'.css';
file_put_contents($outsideCss, "Text { color: #FF0000; }\n");
$outsideImportRejected = false;
try {
    ScopedStyleCompiler::compile(
        '@import "../../../'.basename($outsideCss).'";',
        $cssImportComponent,
    );
} catch (RuntimeException $error) {
    $outsideImportRejected = str_contains($error->getMessage(), 'outside the project');
}
$assert(
    $outsideImportRejected,
    'Scoped CSS imports must not escape the Composer project root.',
);
file_put_contents(
    $cssImportComponent,
    <<<'PAM'
<?php

declare(strict_types=1);

namespace Pam\Native\Tests\CssImport;

use Pam\Native\Component;

final class Profile extends Component
{
}
?>

<template>
    <Text>Profile</Text>
</template>

<style scoped>
    @import "../styles/brand.css";
</style>
PAM,
);
$cssImportCache = $cssImportRoot.'/.cache';
$firstImportedComponent = PamPhpCompiler::compileFile(
    $cssImportComponent,
    $cssImportCache,
);
$firstImportedStyles = json_decode(
    (string) ($firstImportedComponent->template->attributes['__pamStyles'] ?? ''),
    true,
    32,
    JSON_THROW_ON_ERROR,
);
file_put_contents(
    $cssImportRoot.'/src/styles/tokens.css',
    ":root { --brand-ink: #245E42; }\n",
);
$secondImportedComponent = PamPhpCompiler::compileFile(
    $cssImportComponent,
    $cssImportCache,
);
$secondImportedStyles = json_decode(
    (string) ($secondImportedComponent->template->attributes['__pamStyles'] ?? ''),
    true,
    32,
    JSON_THROW_ON_ERROR,
);
$assert(
    $firstImportedStyles['tags']['Text']['textColor'] === 0xFF163D2A
        && $secondImportedStyles['tags']['Text']['textColor'] === 0xFF245E42,
    'Changing an imported CSS dependency must invalidate the compiled component cache.',
);
file_put_contents(
    $cssImportRoot.'/src/app.css',
    <<<'CSS'
:root {
    --app-ink: #112A1C;
}

Text {
    color: var(--app-ink);
    font-size: 13px;
}

.shared-card {
    padding: 8px;
}
CSS,
);
file_put_contents(
    $cssImportComponent,
    <<<'PAM'
<?php

declare(strict_types=1);

namespace Pam\Native\Tests\CssImport;

use Pam\Native\Component;

final class Profile extends Component
{
}
?>

<template>
    <Column class="shared-card">
        <Text>Profile</Text>
    </Column>
</template>

<style scoped>
    .shared-card {
        padding-left: 16px;
    }

    Text {
        font-size: 15px;
    }
</style>
PAM,
);
$globalStyleComponent = PamPhpCompiler::compileFile(
    $cssImportComponent,
    $cssImportCache,
);
$globalStyles = json_decode(
    (string) ($globalStyleComponent->template->attributes['__pamStyles'] ?? ''),
    true,
    32,
    JSON_THROW_ON_ERROR,
);
$assert(
    $globalStyles['tags']['Text']['textColor'] === 0xFF112A1C
        && $globalStyles['tags']['Text']['fontSize'] === '15'
        && $globalStyles['classes']['shared-card'] === [
            'paddingTop' => '8',
            'paddingRight' => '8',
            'paddingBottom' => '8',
            'paddingLeft' => '16',
        ],
    'src/app.css must apply globally while local component CSS wins the cascade.',
);
unlink($outsideCss);
unlink($cssImportComponent);
foreach (glob($cssImportCache.'/*') ?: [] as $cacheFile) {
    unlink($cacheFile);
}
rmdir($cssImportCache);
unlink($cssImportRoot.'/src/app.css');
unlink($cssImportRoot.'/src/styles/brand.css');
unlink($cssImportRoot.'/src/styles/tokens.css');
unlink($cssImportRoot.'/composer.json');
rmdir($cssImportRoot.'/src/screens');
rmdir($cssImportRoot.'/src/styles');
rmdir($cssImportRoot.'/src');
rmdir($cssImportRoot);
$shadowStyles = ScopedStyleCompiler::compile(
    '.card { box-shadow: 3px 4px 0 1px #FFD23F; }'
        .'.first { box-shadow: rgba(1, 2, 3, 0.5) 0 2px; }'
        .'.flat { box-shadow: none; }',
    'ShadowStyle.pam.php',
);
$assert(
    $shadowStyles['classes']['card'] === [
        'shadowOffsetX' => '3',
        'shadowOffsetY' => '4',
        'shadowBlurRadius' => '0',
        'shadowSpreadRadius' => '1',
        'shadowColor' => 0xFFFFD23F,
    ]
        && $shadowStyles['classes']['first']['shadowColor'] === 0x80010203
        && $shadowStyles['classes']['flat']['shadowColor'] === 0,
    'Scoped CSS box-shadow must compile to the typed native shadow contract.',
);
$axisGapStyles = ScopedStyleCompiler::compile(
    '.wrapped { column-gap: 14px; row-gap: 8px; }',
    'AxisGapStyle.pam.php',
);
$assert(
    $axisGapStyles['classes']['wrapped'] === [
        'gridColumnGap' => '14',
        'gridRowGap' => '8',
    ],
    'Scoped CSS row-gap and column-gap must preserve independent flex axes.',
);
$unformattedPam = <<<'PAM'
<?php

declare(strict_types=1);
?>
<template><Column><!-- Keep this explanation. --><Text v-if="$ready" fontSize="15">Ready</Text><Text v-else>Wait</Text></Column></template><style scoped>.ready { color: #112233; font-size: 15px; }</style>
PAM;
$formattedPam = PamFormatter::format($unformattedPam, 'FormatterTest.pam.php');
$canonicalPam = PamFormatter::format(
    "<?php\n?>\n<template><Button on:press=\"save\" v-model=\"draft\">Save</Button></template>",
    'CanonicalFormatterTest.pam',
);
$assert(
    str_contains($canonicalPam, '@press="save"')
        && str_contains($canonicalPam, 'p-model="draft"')
        && PamFormatter::format($canonicalPam, 'CanonicalFormatterTest.pam') === $canonicalPam,
    'PAM formatter must canonicalize event and model aliases idempotently.',
);
$assert(
    str_contains($formattedPam, 'p-if="$ready"')
        && str_contains($formattedPam, '<Text p-else>Wait</Text>')
        && str_contains($formattedPam, '<!-- Keep this explanation. -->')
        && str_contains(
            $formattedPam,
            "    .ready {\n        color: #112233;\n        font-size: 15px;\n    }",
        )
        && !str_contains($formattedPam, 'v-if')
        && PamFormatter::format($formattedPam, 'FormatterTest.pam.php')
            === $formattedPam,
    'PAM formatter must migrate directives and produce idempotent output.',
);
$emptyStylePam = PamFormatter::format(
    <<<'PAM'
<?php

declare(strict_types=1);
?>
<template><Text>Ready</Text></template><style scoped>

</style>
PAM,
    'EmptyStyleFormatterTest.pam.php',
);
$assert(
    !str_contains($emptyStylePam, '<style scoped>')
        && str_contains($emptyStylePam, '<Text>Ready</Text>'),
    'PAM formatter must remove empty scoped style blocks.',
);

foreach (NodeKind::cases() as $index => $kind) {
    $assert($kind->value === $index + 1, 'Node kinds must remain sequential protocol integers.');
}
foreach (PropKey::cases() as $index => $key) {
    $assert($key->value === $index + 1, 'Property keys must remain sequential protocol integers.');
}
foreach (EventKind::cases() as $index => $kind) {
    $assert($kind->value === $index + 1, 'Event kinds must remain sequential protocol integers.');
}

$gesture = GestureDetector::make(
    GestureType::Pan,
    Text::make('Drag me'),
)
    ->pointers(1, 2)
    ->direction(GestureDirection::Horizontal)
    ->composition(GestureComposition::Simultaneous)
    ->minimumDistance(12.0)
    ->minimumDuration(80)
    ->nativeTransform(
        translationLimitX: 96.0,
        resetOnEnd: true,
    )
    ->onBegin(static function (): void {
    })
    ->onUpdate(static function (): void {
    })
    ->onEnd(static function (): void {
    })
    ->onCancel(static function (): void {
    });
$assert(
    $gesture->kind() === NodeKind::Pressable
        && $gesture->properties()[PropKey::GestureType->value]
            === GestureType::Pan->value
        && $gesture->properties()[PropKey::GestureMaxPointers->value] === 2
        && $gesture->properties()[PropKey::GestureDirection->value]
            === GestureDirection::Horizontal->value
        && $gesture->properties()[PropKey::PressOpacity->value] === 1.0
        && $gesture->properties()[PropKey::PressScale->value] === 1.0
        && $gesture->properties()[PropKey::GestureNativeTranslationLimitX->value]
            === 96.0
        && $gesture->properties()[PropKey::GestureNativeResetOnEnd->value]
            === true
        && count($gesture->events()) === 4,
    'GestureDetector must compile to an additive native Pressable contract.',
);
$gestureEvent = GestureEvent::fromPayload(Wire::map([
    'type' => GestureType::Pinch->value,
    'state' => GestureState::Changed->value,
    'x' => 24.0,
    'y' => 40.0,
    'pageX' => 32.0,
    'pageY' => 72.0,
    'translationX' => 8.0,
    'translationY' => 12.0,
    'velocityX' => 120.0,
    'velocityY' => 80.0,
    'scale' => 1.25,
    'rotation' => 0.2,
    'pointerCount' => 2,
    'timestamp' => 1234,
]));
$assert(
    $gestureEvent->type === GestureType::Pinch
        && $gestureEvent->state === GestureState::Changed
        && $gestureEvent->scale === 1.25
        && $gestureEvent->pointerCount === 2,
    'GestureEvent must decode the bounded cross-platform semantic payload.',
);
$templateGestureScope = new class {
    public ?GestureEvent $event = null;
    public string $layerId = '';

    public function changed(GestureEvent $event): void
    {
        $this->event = $event;
    }

    public function changedLayer(string $layerId, GestureEvent $event): void
    {
        $this->layerId = $layerId;
        $this->event = $event;
    }
};
$templateGesture = TemplateRenderer::render(
    TemplateCompiler::compile(
        '<GestureDetector gestureType="pan" on:gestureUpdate="changed">'
        .'<Text>Drag</Text></GestureDetector>',
    ),
    $templateGestureScope,
    [],
);
$templatePinch = TemplateRenderer::render(
    TemplateCompiler::compile(
        '<GestureDetector gestureType="pinch"><Text>Zoom</Text></GestureDetector>',
    ),
    null,
    [],
);
$explicitGesturePayload = Wire::map([
    'type' => GestureType::Pan->value,
    'state' => GestureState::Ended->value,
    'translationX' => 42.0,
]);
TemplateExpression::evaluate(
    'changedLayer("layer-1", $event)',
    $templateGestureScope,
    ['event' => $explicitGesturePayload],
);
$assert(
    $templateGestureScope->layerId === 'layer-1'
        && $templateGestureScope->event instanceof GestureEvent
        && $templateGestureScope->event->translationX === 42.0,
    'Explicit expression event arguments must honor typed GestureEvent parameters.',
);
$invalidForRejected = false;
try {
    TemplateCompiler::compile(
        '<Column><Text p-for="$item, $index in $items">Invalid</Text></Column>',
        'invalid-indexed-loop.pam.php',
    );
} catch (RuntimeException $error) {
    $invalidForRejected = str_contains($error->getMessage(), 'p-for must use');
}
$assert(
    $invalidForRejected,
    'Template compilation must reject invalid p-for syntax before runtime.',
);
$invalidLegacyForRejected = false;
try {
    TemplateCompiler::compile(
        '<Column><Text v-for="$item, $index in $items">Invalid</Text></Column>',
        'invalid-legacy-for.pam.php',
    );
} catch (RuntimeException $error) {
    $invalidLegacyForRejected = str_contains($error->getMessage(), 'v-for must use');
}
$assert(
    $invalidLegacyForRejected,
    'Template compilation must also reject invalid legacy v-for syntax.',
);
$invalidGestureChildrenRejected = false;
try {
    TemplateCompiler::compile(
        '<GestureDetector><Text>One</Text><Text>Two</Text></GestureDetector>',
        'invalid-gesture-children.pam.php',
    );
} catch (RuntimeException $error) {
    $invalidGestureChildrenRejected = str_contains(
        $error->getMessage(),
        'must resolve to exactly one child',
    );
}
$assert(
    $invalidGestureChildrenRejected,
    'Template compilation must reject ambiguous GestureDetector children before runtime.',
);
TemplateCompiler::compile(
    '<GestureDetector><Image p-if="$video" /><Text p-else>Image</Text></GestureDetector>',
    'conditional-gesture-child.pam.php',
);
TemplateCompiler::compile(
    '<GestureDetector><Image v-if="$video" /><Text v-else>Image</Text></GestureDetector>',
    'legacy-conditional-gesture-child.pam.php',
);
$assert(
    $templatePinch->properties()[PropKey::GestureMinPointers->value] === 2
        && $templatePinch->properties()[PropKey::GestureMaxPointers->value] === 2,
    'Template pinch gestures must retain the native two-pointer defaults.',
);
$templateGesture->events()[EventKind::GestureUpdate->value](Wire::map([
    'type' => GestureType::Pan->value,
    'state' => GestureState::Changed->value,
    'translationX' => -96.0,
    'pointerCount' => 1,
]));
$assert(
    $templateGestureScope->event instanceof GestureEvent
        && $templateGestureScope->event->translationX === -96.0,
    'Template gesture handlers must hydrate their binary payload as GestureEvent.',
);

$repositoryRoot = dirname(__DIR__, 3);
$kotlinProtocol = file_get_contents(
    $repositoryRoot.'/android/app/src/main/java/dev/pam/nativeapp/protocol/PamProtocol.kt',
);
$rustProtocol = file_get_contents(
    $repositoryRoot.'/crates/pam-native-protocol/src/lib.rs',
);
if ($kotlinProtocol === false || $rustProtocol === false) {
    throw new RuntimeException('Cross-language protocol sources must be readable.');
}
$androidBridge = file_get_contents(
    $repositoryRoot.'/android/app/src/main/cpp/pam_android_bridge.cpp',
);
$iosBridge = file_get_contents(
    $repositoryRoot.'/ios/Sources/PamNative/Bridge/pam_native_ios_bridge.cpp',
);
foreach (['Android' => $androidBridge, 'iOS' => $iosBridge] as $platform => $bridge) {
    $assert(
        is_string($bridge)
            && str_contains($bridge, 'if (event.type == EventType::Ui)')
            && str_contains($bridge, 'disposable->type != EventType::Ui')
            && str_contains($bridge, 'state->events.erase(disposable);')
            && str_contains($bridge, 'insertion->type != EventType::Ui')
            && str_contains($bridge, 'state->events.insert(insertion, std::move(event));'),
        $platform.' bridge must preserve module results and reloads when the event queue is full.',
    );
}
if (
    preg_match(
        '/enum class PropKey\\(val value: Int\\) \\{(?<body>.*?)\\n\\}/s',
        $kotlinProtocol,
        $kotlinBlock,
    ) !== 1
    || preg_match(
        '/pub enum PropKey \\{(?<body>.*?)\\n\\}/s',
        $rustProtocol,
        $rustBlock,
    ) !== 1
    || preg_match(
        '/enum class EventKind\\(val value: Int\\) \\{(?<body>.*?)\\n\\}/s',
        $kotlinProtocol,
        $kotlinEventBlock,
    ) !== 1
) {
    throw new RuntimeException('Cross-language protocol enums must be discoverable.');
}
preg_match_all(
    '/^\\s*([A-Z][A-Z0-9_]*)\\((\\d+)\\)[,;]/m',
    $kotlinBlock['body'],
    $kotlinValues,
);
preg_match_all(
    '/^\\s*([A-Za-z][A-Za-z0-9_]*)\\s*=\\s*(\\d+),/m',
    $rustBlock['body'],
    $rustValues,
);
preg_match_all(
    '/^\\s*([A-Z][A-Z0-9_]*)\\((\\d+)\\)[,;]/m',
    $kotlinEventBlock['body'],
    $kotlinEventValues,
);
$phpPropertyValues = array_map(
    static fn (PropKey $key): int => $key->value,
    PropKey::cases(),
);
$kotlinPropertyValues = array_map('intval', $kotlinValues[2]);
$rustPropertyValues = array_map('intval', $rustValues[2]);
$normalizeProtocolName = static function (string $name): string {
    $normalized = preg_replace(
        ['/([a-z0-9])([A-Z])/', '/([A-Z])([A-Z][a-z])/'],
        ['$1_$2', '$1_$2'],
        $name,
    );
    if ($normalized === null) {
        throw new RuntimeException('Protocol enum name could not be normalized.');
    }

    return strtoupper($normalized);
};
$phpPropertyNames = array_map(
    static fn (PropKey $key): string => $normalizeProtocolName($key->name),
    PropKey::cases(),
);
$rustPropertyNames = array_map($normalizeProtocolName, $rustValues[1]);
$assert(
    $kotlinPropertyValues === $phpPropertyValues
        && $rustPropertyValues === $phpPropertyValues
        && $kotlinValues[1] === $phpPropertyNames
        && $rustPropertyNames === $phpPropertyNames,
    'PHP, Kotlin, and Rust property protocol enums must remain byte-for-byte aligned.',
);
$phpEventValues = array_map(
    static fn (EventKind $kind): int => $kind->value,
    EventKind::cases(),
);
$phpEventNames = array_map(
    static fn (EventKind $kind): string => $normalizeProtocolName($kind->name),
    EventKind::cases(),
);
$assert(
    array_map('intval', $kotlinEventValues[2]) === $phpEventValues
        && $kotlinEventValues[1] === $phpEventNames,
    'PHP and Kotlin event protocol enums must remain byte-for-byte aligned.',
);
$kotlinHandshake = (string) file_get_contents(
    $repositoryRoot.'/android/app/src/main/java/dev/pam/nativeapp/protocol/ProtocolHandshake.kt',
);
$swiftHandshake = (string) file_get_contents(
    $repositoryRoot.'/ios/Sources/PamNative/Protocol/ProtocolHandshake.swift',
);
foreach (\Pam\Native\Protocol::CAPABILITIES as $capability) {
    $assert(
        str_contains($rustProtocol, '"'.$capability.'"')
            && str_contains($kotlinHandshake, '"'.$capability.'"')
            && str_contains($swiftHandshake, '"'.$capability.'"'),
        "Runtime capability {$capability} must remain aligned across PHP, Rust, Kotlin, and Swift.",
    );
}
$assert(
    str_contains($rustProtocol, 'pub const ABI_VERSION: u16 = 1;')
        && str_contains($kotlinHandshake, 'PAM_ABI_VERSION = 1')
        && str_contains($swiftHandshake, 'PAM_ABI_VERSION = 1'),
    'ABI version 1 must remain aligned across every runtime host.',
);

foreach ([
    AnimationKind::cases(),
    AsyncStatus::cases(),
    MotionPreset::cases(),
    HapticFeedback::cases(),
    FormStatus::cases(),
    TabPresentation::cases(),
    AccessibilityRole::cases(),
    AccessibilityCheckedState::cases(),
    AccessibilityImportance::cases(),
    AccessibilityLiveRegion::cases(),
    FontStyle::cases(),
    ImageCachePolicy::cases(),
    ImageFit::cases(),
    ImageResizeMethod::cases(),
    InputAutoCapitalize::cases(),
    InputAutofillImportance::cases(),
    InputMode::cases(),
    InputSubmitBehavior::cases(),
    InputTextAlignVertical::cases(),
    PointerEvents::cases(),
    PositionType::cases(),
    ReturnKeyType::cases(),
    RefreshIndicatorSize::cases(),
    SafeAreaMode::cases(),
    TextBreakStrategy::cases(),
    TextDataDetectorType::cases(),
    TextDecoration::cases(),
    TextEllipsizeMode::cases(),
    TextHyphenationFrequency::cases(),
    TextTransform::cases(),
] as $cases) {
    foreach ($cases as $index => $case) {
        $assert(
            $case->value === $index + 1,
            $case::class.' values must remain sequential protocol integers.',
        );
    }
}

$loadingState = AsyncValue::loading(['cached']);
$assert(
    $loadingState->status === AsyncStatus::Loading
        && $loadingState->hasData()
        && $loadingState->isBusy(),
    'AsyncValue must preserve cached content while loading.',
);
$offlineState = AsyncValue::offline(['cached']);
$assert(
    $offlineState->status === AsyncStatus::Offline
        && $offlineState->retryable
        && $offlineState->hasData(),
    'Offline state must retain cached content and recovery semantics.',
);

$registrationForm = new class extends NativeForm {
    #[Required]
    #[Email]
    public string $email = '';

    #[Required]
    #[MinLength(12)]
    #[MaxLength(64)]
    public string $password = '';

    #[Matches('password')]
    public string $passwordConfirmation = '';
};
$registrationForm->fill([
    'email' => 'invalid',
    'password' => 'short',
    'passwordConfirmation' => 'different',
], touch: true);
$assert(
    !$registrationForm->beginSubmit()
        && $registrationForm->status() === FormStatus::Failure
        && $registrationForm->error('email') !== null
        && $registrationForm->error('password') !== null
        && $registrationForm->error('passwordConfirmation') !== null,
    'NativeForm must validate attributed fields before submission.',
);
$registrationForm->fill([
    'email' => 'developer@pam.dev',
    'password' => 'a-secure-password',
    'passwordConfirmation' => 'a-secure-password',
]);
$assert(
    $registrationForm->beginSubmit()
        && $registrationForm->status() === FormStatus::Submitting,
    'NativeForm must enter submitting only after successful validation.',
);
$registrationForm->fail(['email' => ['This email is already registered.']]);
$assert(
    $registrationForm->status() === FormStatus::Failure
        && $registrationForm->error('email') === 'This email is already registered.',
    'NativeForm must map server errors to their fields.',
);

$motionElement = Text::make('Motion')->motion(MotionPreset::SlideUp, 260);
$assert(
    $motionElement->properties()[PropKey::AnimationKind->value]
        === AnimationKind::SlideUp->value
        && $motionElement->properties()[PropKey::AnimationDurationMs->value] === 260,
    'Motion presets must compile to native animation properties.',
);
Haptics::trigger(HapticFeedback::Success);
$assert(
    TestDiagnostics::$typedCall !== null
        && TestDiagnostics::$typedCall['operation'] === NativeOperation::Haptic->value
        && Wire::decodeMap(TestDiagnostics::$typedCall['payload'])['feedback']
            === HapticFeedback::Success->value,
    'Semantic haptics must use the typed native operation channel.',
);
Clipboard::setText('Pam Native');
$assert(
    TestDiagnostics::$typedCall !== null
        && TestDiagnostics::$typedCall['operation']
            === NativeOperation::ClipboardSetText->value
        && Wire::decodeMap(TestDiagnostics::$typedCall['payload'])['text']
            === 'Pam Native',
    'Clipboard writes must use the bounded typed native operation channel.',
);
Clipboard::setSensitiveText('private-pix-code', 45);
$sensitiveClipboardPayload = Wire::decodeMap(TestDiagnostics::$typedCall['payload']);
$assert(
    TestDiagnostics::$typedCall['operation'] === NativeOperation::ClipboardSetText->value
        && $sensitiveClipboardPayload['text'] === 'private-pix-code'
        && $sensitiveClipboardPayload['sensitive'] === true
        && $sensitiveClipboardPayload['clearAfterSeconds'] === 45,
    'Sensitive clipboard writes must carry bounded privacy metadata.',
);
foreach ([14, 301] as $invalidClipboardExpiry) {
    try {
        Clipboard::setSensitiveText('private', $invalidClipboardExpiry);
        $assert(false, 'Sensitive clipboard expiry must reject unsafe bounds.');
    } catch (InvalidArgumentException) {
        $assert(true, 'Sensitive clipboard expiry rejects unsafe bounds.');
    }
}
$assert(
    array_map(
        static fn (NativeOperation $operation): int => $operation->value,
        NativeOperation::cases(),
    ) === range(1, 19),
    'Native operations must remain sequential and append-only.',
);
Sensors::read(SensorType::Gyroscope, static function (): void {
}, 50_000);
$sensorPayload = Wire::decodeMap(TestDiagnostics::$typedCall['payload']);
$assert(
    TestDiagnostics::$typedCall['operation'] === NativeOperation::SensorRead->value
        && $sensorPayload['type'] === SensorType::Gyroscope->value
        && $sensorPayload['timeoutMs'] === 10_000,
    'Sensor reads must use integer types and bounded native timeouts.',
);

$tree = Screen::make(
    Column::make(
        Text::make('Pam Native')->key('title'),
        Button::make('Tap')->onPress(static function (): void {
        }),
        Input::make('value')->placeholder('Type here'),
    )->style(new Style(padding: 16.0, gap: 8.0)),
);
$inputSelection = null;
$inputContentSize = null;
$inputKey = null;
$inputEndValue = null;
$inputElement = Input::make('hello')
    ->multiline()
    ->editable(false)
    ->autoCorrect(false)
    ->autoCapitalize(InputAutoCapitalize::Words)
    ->caretHidden()
    ->contextMenuHidden()
    ->cursorColor(0xFF2563EB)
    ->disableFullscreenUi()
    ->autofillImportance(InputAutofillImportance::Yes)
    ->inputMode(InputMode::Email)
    ->minLines(3)
    ->selectTextOnFocus()
    ->selection(1, 4)
    ->showSoftInputOnFocus(false)
    ->submitBehavior(InputSubmitBehavior::Submit)
    ->textAlignVertical(InputTextAlignVertical::Top)
    ->returnKeyLabel('Publish')
    ->scrollEnabled(false)
    ->underlineColor(0x00000000)
    ->onEndEditing(
        static function (string $value) use (&$inputEndValue): void {
            $inputEndValue = $value;
        },
    )
    ->onSelectionChange(
        static function (InputSelectionEvent $event) use (&$inputSelection): void {
            $inputSelection = $event;
        },
    )
    ->onContentSizeChange(
        static function (InputContentSizeEvent $event) use (
            &$inputContentSize,
        ): void {
            $inputContentSize = $event;
        },
    )
    ->onKeyPress(
        static function (InputKeyEvent $event) use (&$inputKey): void {
            $inputKey = $event;
        },
    );
$inputElement->events()[EventKind::InputEndEditing->value]('finished');
$inputElement->events()[EventKind::InputSelectionChange->value](Wire::map([
    'start' => 1,
    'end' => 4,
]));
$inputElement->events()[EventKind::InputContentSizeChange->value](Wire::map([
    'width' => 240.0,
    'height' => 96.0,
]));
$inputElement->events()[EventKind::InputKeyPress->value](Wire::map([
    'key' => 'Enter',
]));
$assert(
    $inputElement->properties()[PropKey::InputEditable->value] === false
        && $inputElement->properties()[PropKey::InputAutoCorrect->value]
            === false
        && $inputElement->properties()[PropKey::InputAutoCapitalize->value]
            === InputAutoCapitalize::Words->value
        && $inputElement->properties()[PropKey::InputAutofillImportance->value]
            === InputAutofillImportance::Yes->value
        && $inputElement->properties()[PropKey::InputMode->value]
            === InputMode::Email->value
        && $inputElement->properties()[PropKey::InputMinLines->value] === 3
        && $inputElement->properties()[PropKey::InputSelectionStart->value]
            === 1
        && $inputElement->properties()[PropKey::InputSelectionEnd->value] === 4
        && $inputElement->properties()[PropKey::InputSubmitBehavior->value]
            === InputSubmitBehavior::Submit->value
        && $inputElement->properties()[PropKey::InputTextAlignVertical->value]
            === InputTextAlignVertical::Top->value
        && $inputElement->properties()[PropKey::InputReturnKeyLabel->value]
            === 'Publish'
        && $inputElement->properties()[PropKey::InputScrollEnabled->value]
            === false
        && $inputEndValue === 'finished'
        && $inputSelection instanceof InputSelectionEvent
        && $inputSelection->end === 4
        && $inputContentSize instanceof InputContentSizeEvent
        && $inputContentSize->height === 96.0
        && $inputKey instanceof InputKeyEvent
        && $inputKey->key === 'Enter',
    'Input helpers must preserve native editing, selection, keyboard, size and key behavior.',
);
$maskedInput = \Pam\Native\UI\Input::make('11987654321')->mask('(##) #####-####');
$currencyInput = \Pam\Native\UI\Input::make('123456')->currency(2, 'R$ ', ' BRL', 'pt-BR');
$assert(
    $maskedInput->properties()[PropKey::InputFormat->value] === InputFormat::Pattern->value
        && $maskedInput->properties()[PropKey::InputFormatPattern->value] === '(##) #####-####'
        && $maskedInput->properties()[PropKey::InputFormatPlaceholder->value] === '#'
        && $currencyInput->properties()[PropKey::InputFormat->value] === InputFormat::Currency->value
        && $currencyInput->properties()[PropKey::InputFormatDecimalDigits->value] === 2
        && $currencyInput->properties()[PropKey::InputFormatPrefix->value] === 'R$ '
        && $currencyInput->properties()[PropKey::InputFormatSuffix->value] === ' BRL'
        && $currencyInput->properties()[PropKey::InputFormatLocale->value] === 'pt-BR',
    'Input formatting helpers must expose typed pattern and locale-aware currency contracts.',
);
$templateFormattedInputs = TemplateRenderer::render(
    TemplateCompiler::compile(
        '<Column>'
        .'<Input inputFormat="mask" inputFormatPattern="(##) #####-####" />'
        .'<Input inputFormat="currency" inputFormatDecimalDigits="2" inputFormatPrefix="R$ " inputFormatLocale="pt-BR" />'
        .'</Column>',
    ),
    new class {
    },
    [],
);
$assert(
    array_map(
        static fn (\Pam\Native\Element $input): int => $input
            ->properties()[PropKey::InputFormat->value],
        $templateFormattedInputs->children(),
    ) === [InputFormat::Pattern->value, InputFormat::Currency->value],
    'Template inputFormat aliases must compile to the sequential native enum.',
);
$secureAliasElement = TemplateRenderer::render(
    TemplateCompiler::compile('<Input secureTextEntry="true" />'),
    new class {
    },
    [],
);
$assert(
    $secureAliasElement->properties()[PropKey::Secure->value] === true,
    'Input secureTextEntry must remain a compatible alias for secure.',
);
$disabledAliasElement = TemplateRenderer::render(
    TemplateCompiler::compile('<Pressable disabled="true" />'),
    new class {
    },
    [],
);
$assert(
    $disabledAliasElement->properties()[PropKey::Enabled->value] === false,
    'Template disabled must invert to the native enabled property.',
);
$memoryDiskImage = TemplateRenderer::render(
    TemplateCompiler::compile('<Image source="https://example.test/image.webp" cachePolicy="memory-disk" />'),
    new class {
    },
    [],
);
$assert(
    $memoryDiskImage->properties()[PropKey::ImageCachePolicy->value]
        === ImageCachePolicy::ForceCache->value,
    'Image memory-disk must map the familiar Expo policy to the native memory/disk cache.',
);
$uncachedImage = TemplateRenderer::render(
    TemplateCompiler::compile('<Image source="https://example.test/image.webp" cachePolicy="none" />'),
    new class {
    },
    [],
);
$assert(
    $uncachedImage->properties()[PropKey::ImageCachePolicy->value]
        === ImageCachePolicy::None->value,
    'Image none must map to the native read/write cache bypass policy.',
);
$keyboardAliasElement = TemplateRenderer::render(
    TemplateCompiler::compile(
        '<Column>'
        .'<Input keyboardType="default" />'
        .'<Input keyboardType="email-address" />'
        .'<Input keyboardType="number-pad" />'
        .'<Input keyboardType="phone-pad" />'
        .'<Input keyboardType="decimal-pad" />'
        .'</Column>',
    ),
    new class {
    },
    [],
);
$assert(
    array_map(
        static fn (\Pam\Native\Element $input): int => $input
            ->properties()[PropKey::KeyboardType->value],
        $keyboardAliasElement->children(),
    ) === [
        KeyboardType::Text->value,
        KeyboardType::Email->value,
        KeyboardType::Number->value,
        KeyboardType::Phone->value,
        KeyboardType::Decimal->value,
    ],
    'Input keyboardType must accept familiar React Native aliases.',
);
$dynamicColorElement = TemplateRenderer::render(
    TemplateCompiler::compile(
        '<Text :textColor="$active ? \'#1B7A4E\' : \'#777770\'">Status</Text>',
    ),
    null,
    ['active' => true],
);
$assert(
    $dynamicColorElement->properties()[PropKey::TextColor->value] === 0xFF1B7A4E,
    'Dynamically bound hexadecimal colors must cross the native bridge as integers.',
);
$transparentColorElement = TemplateRenderer::render(
    TemplateCompiler::compile(
        '<View backgroundColor="transparent">'
        .'<View backgroundColor="rgba(255 255 255 / 25%)" />'
        .'<View backgroundColor="#1234" />'
        .'<View backgroundColor="#80112233" />'
        .'</View>',
    ),
    null,
    [],
);
$assert(
    $transparentColorElement->properties()[PropKey::BackgroundColor->value] === 0x00000000
        && $transparentColorElement->children()[0]
            ->properties()[PropKey::BackgroundColor->value] === 0x40FFFFFF
        && $transparentColorElement->children()[1]
            ->properties()[PropKey::BackgroundColor->value] === 0x44112233
        && $transparentColorElement->children()[2]
            ->properties()[PropKey::BackgroundColor->value] === 0x80112233,
    'Direct colors must add CSS forms while preserving legacy eight-digit ARGB.',
);
$quotedComparisonTemplate = TemplateCompiler::compile(
    '<Column><Text v-if="$count > 0">More</Text>'
    .'<Text v-if="$count < 1">Less</Text></Column>',
);
$assert(
    $quotedComparisonTemplate->children[0]->children[0]->attributes['v-if']
        === '$count > 0'
        && $quotedComparisonTemplate->children[0]->children[1]->attributes['v-if']
            === '$count < 1',
    'Template tags must keep angle-bracket operators inside quoted attributes.',
);
$pamDirectiveBranches = TemplateRenderer::render(
    TemplateCompiler::compile(
        '<Column>'
        .'<Text p-if="$kind === 1">One</Text>'
        .'<Text p-else-if="$kind === 2">Two</Text>'
        .'<Text p-else>Other</Text>'
        .'</Column>',
    ),
    null,
    ['kind' => 2],
);
$assert(
    count($pamDirectiveBranches->children()) === 1
        && $pamDirectiveBranches->children()[0]
            ->properties()[PropKey::Text->value] === 'Two',
    'Native p-if, p-else-if and p-else directives must render one matching branch.',
);
$scrollViewElement = TemplateRenderer::render(
    TemplateCompiler::compile(
        '<ScrollView horizontal="true" scrollIndicatorStyle="dark">'
        .'<Pressable width="66"><Text>New</Text></Pressable>'
        .'<Pressable width="76"><Text>Saved</Text></Pressable>'
        .'</ScrollView>',
    ),
    null,
    [],
);
$scrollContent = $scrollViewElement->children()[0] ?? null;
$assert(
    $scrollViewElement->kind() === NodeKind::Scroll
        && $scrollViewElement->properties()[PropKey::ScrollIndicatorStyle->value] === ScrollIndicatorStyle::Dark->value
        && $scrollContent instanceof \Pam\Native\Element
        && $scrollContent->kind() === NodeKind::Row
        && count($scrollContent->children()) === 2
        && (float) $scrollContent->children()[0]
            ->properties()[PropKey::Width->value] === 66.0
        && (float) $scrollContent->children()[1]
            ->properties()[PropKey::Width->value] === 76.0,
    'Declarative horizontal ScrollView must preserve direct child widths in a Row container.',
);
$pressInEvent = null;
$pressOutEvent = null;
$pressMoveEvent = null;
$pressableElement = Pressable::make(Text::make('Open'))
    ->ripple(0x66010203, true, 24.0, true, 0.5)
    ->pressedOpacity(0.7)
    ->pressedScale(0.92)
    ->hitSlopEdges(4.0, 6.0, 8.0, 10.0)
    ->pressRetentionEdges(12.0, 14.0, 16.0, 18.0)
    ->delayLongPress(420)
    ->delayPressIn(25)
    ->delayPressOut(40)
    ->androidDisableSound()
    ->onPressIn(static function (PressEvent $event) use (&$pressInEvent): void {
        $pressInEvent = $event;
    })
    ->onPressOut(static function (PressEvent $event) use (&$pressOutEvent): void {
        $pressOutEvent = $event;
    })
    ->onPressMove(static function (PressEvent $event) use (&$pressMoveEvent): void {
        $pressMoveEvent = $event;
    });
$pressPayload = Wire::map([
    'x' => 11.5,
    'y' => 12.5,
    'pageX' => 21.5,
    'pageY' => 22.5,
    'timestamp' => 1234,
    'pointerId' => 7,
]);
$pressableElement->events()[EventKind::PressIn->value]($pressPayload);
$pressableElement->events()[EventKind::PressOut->value]($pressPayload);
$pressableElement->events()[EventKind::PressMove->value]($pressPayload);
$assert(
    $pressableElement->properties()[PropKey::HitSlopLeft->value] === 4.0
        && $pressableElement->properties()[PropKey::HitSlopBottom->value] === 10.0
        && $pressableElement->properties()[PropKey::PressRetentionRight->value] === 16.0
        && $pressableElement->properties()[PropKey::PressDelayLongMs->value] === 420
        && $pressableElement->properties()[PropKey::PressDelayInMs->value] === 25
        && $pressableElement->properties()[PropKey::PressDelayOutMs->value] === 40
        && $pressableElement->properties()[PropKey::PressAndroidDisableSound->value] === true
        && $pressableElement->properties()[PropKey::PressScale->value] === 0.92
        && $pressableElement->properties()[PropKey::RippleBorderless->value] === true
        && $pressableElement->properties()[PropKey::RippleRadius->value] === 24.0
        && $pressableElement->properties()[PropKey::RippleForeground->value] === true
        && $pressableElement->properties()[PropKey::RippleAlpha->value] === 0.5
        && $pressInEvent instanceof PressEvent
        && $pressInEvent->x === 11.5
        && $pressOutEvent instanceof PressEvent
        && $pressMoveEvent instanceof PressEvent
        && $pressMoveEvent->pointerId === 7,
    'Pressable helpers must preserve complete native gesture geometry and lifecycle events.',
);
$accessibilityElement = Text::make('Upload')
    ->accessibilityRole(AccessibilityRole::ProgressBar)
    ->accessible()
    ->accessibilityLiveRegion(AccessibilityLiveRegion::Polite)
    ->accessibilityImportance(AccessibilityImportance::Yes)
    ->accessibilityExpanded(false)
    ->accessibilityBusy(true)
    ->accessibilityChecked(AccessibilityCheckedState::Mixed)
    ->accessibilityValue(0.0, 100.0, 40.0, '40 percent');
$assert(
    $accessibilityElement->properties()[PropKey::Accessible->value] === true
        && $accessibilityElement
            ->properties()[PropKey::AccessibilityLiveRegion->value]
            === AccessibilityLiveRegion::Polite->value
        && $accessibilityElement
            ->properties()[PropKey::AccessibilityImportance->value]
            === AccessibilityImportance::Yes->value
        && $accessibilityElement
            ->properties()[PropKey::AccessibilityExpanded->value] === false
        && $accessibilityElement
            ->properties()[PropKey::AccessibilityBusy->value] === true
        && $accessibilityElement
            ->properties()[PropKey::AccessibilityCheckedState->value]
            === AccessibilityCheckedState::Mixed->value
        && $accessibilityElement
            ->properties()[PropKey::AccessibilityValueNow->value] === 40.0
        && $accessibilityElement
            ->properties()[PropKey::AccessibilityValueText->value]
            === '40 percent',
    'Accessibility state and range helpers must use fixed protocol properties.',
);

$accessibilityActionElement = Text::make('Message')
    ->accessibilityActions(
        new AccessibilityAction('archive', 'Archive message'),
        new AccessibilityAction('reply', 'Reply to message'),
    )
    ->onAccessibilityAction(static fn (string $name): string => $name);
$accessibilityActionDefinitions = json_decode(
    $accessibilityActionElement->properties()[PropKey::AccessibilityActions->value],
    true,
    flags: JSON_THROW_ON_ERROR,
);
$assert(
    $accessibilityActionElement->properties()[PropKey::Accessible->value] === true
        && $accessibilityActionElement
            ->properties()[PropKey::OnAccessibilityAction->value] === true
        && $accessibilityActionElement->events()[EventKind::AccessibilityAction->value]('reply')
            === 'reply'
        && $accessibilityActionDefinitions === [
            ['name' => 'archive', 'label' => 'Archive message'],
            ['name' => 'reply', 'label' => 'Reply to message'],
        ],
    'Accessibility actions must stay bounded, typed and connected to event 65.',
);
foreach ([
    static fn () => new AccessibilityAction('Not Safe', 'Label'),
    static fn () => new AccessibilityAction('safe', ''),
    static fn () => Text::make('Duplicate')->accessibilityActions(
        new AccessibilityAction('open', 'Open'),
        new AccessibilityAction('open', 'Open again'),
    ),
] as $invalidAccessibilityAction) {
    try {
        $invalidAccessibilityAction();
        throw new RuntimeException('Invalid accessibility action should fail closed.');
    } catch (InvalidArgumentException) {
    }
}

$safeAreaElement = SafeAreaView::make(Text::make('Inset content'))
    ->edges(top: true, right: false, bottom: true, left: false)
    ->mode(SafeAreaMode::Margin);
$assert(
    $safeAreaElement->properties()[PropKey::SafeAreaTop->value] === true
        && $safeAreaElement->properties()[PropKey::SafeAreaRight->value] === false
        && $safeAreaElement
            ->properties()[PropKey::SafeAreaBottomEdge->value] === true
        && $safeAreaElement->properties()[PropKey::SafeAreaLeft->value] === false
        && $safeAreaElement->properties()[PropKey::SafeAreaMode->value]
            === SafeAreaMode::Margin->value,
    'Safe area helpers must preserve per-edge and mode protocol properties.',
);

$keyboardAvoidingElement = KeyboardAvoidingView::make(
    Text::make('Keyboard content'),
    KeyboardAvoidingBehavior::Padding,
)->verticalOffset(24.0)->avoidingEnabled(false);
$assert(
    $keyboardAvoidingElement->properties()[PropKey::KeyboardBehavior->value]
        === KeyboardAvoidingBehavior::Padding->value
        && $keyboardAvoidingElement
            ->properties()[PropKey::KeyboardVerticalOffset->value] === 24.0
        && $keyboardAvoidingElement
            ->properties()[PropKey::KeyboardAvoidingEnabled->value] === false,
    'Keyboard avoidance helpers must preserve behavior, offset and enabled state.',
);

$interactiveKeyboardElement = KeyboardAvoidingView::make(
    Text::make('Interactive sheet'),
    KeyboardAvoidingBehavior::Interactive,
);
$assert(
    $interactiveKeyboardElement->properties()[PropKey::KeyboardBehavior->value]
        === KeyboardAvoidingBehavior::Interactive->value,
    'Interactive keyboard avoidance must preserve its sequential protocol value.',
);

$refreshColors = [0xff112233, 0xff445566];
$refreshElement = RefreshControl::make(Text::make('Refresh content'), true)
    ->colors(...$refreshColors)
    ->progressBackgroundColor(0xfff8fafc)
    ->progressViewOffset(16.0)
    ->enabled(false)
    ->size(RefreshIndicatorSize::Large);
$assert(
    $refreshElement->properties()[PropKey::Refreshing->value] === true
        && $refreshElement->properties()[PropKey::RefreshColors->value]
            === implode(',', $refreshColors)
        && $refreshElement
            ->properties()[PropKey::RefreshProgressBackgroundColor->value]
            === 0xfff8fafc
        && $refreshElement
            ->properties()[PropKey::RefreshProgressViewOffset->value] === 16.0
        && $refreshElement->properties()[PropKey::Enabled->value] === false
        && $refreshElement->properties()[PropKey::RefreshIndicatorSize->value]
            === RefreshIndicatorSize::Large->value,
    'Refresh control helpers must preserve Android indicator and gesture properties.',
);

$textElement = Text::make('Selectable https://pam.dev')
    ->numberOfLines(2)
    ->selectable()
    ->selectionColor(0x66112233)
    ->ellipsize(TextEllipsizeMode::Middle)
    ->allowFontScaling()
    ->maxFontSizeMultiplier(1.5)
    ->adjustsFontSizeToFit(minimumScale: 0.5)
    ->breakStrategy(TextBreakStrategy::Balanced)
    ->hyphenation(TextHyphenationFrequency::Full)
    ->dataDetector(TextDataDetectorType::Link);
$assert(
    $textElement->properties()[PropKey::NumberOfLines->value] === 2
        && $textElement->properties()[PropKey::TextSelectable->value] === true
        && $textElement->properties()[PropKey::SelectionColor->value] === 0x66112233
        && $textElement->properties()[PropKey::TextEllipsizeMode->value]
            === TextEllipsizeMode::Middle->value
        && $textElement->properties()[PropKey::TextAllowFontScaling->value] === true
        && $textElement
            ->properties()[PropKey::TextMaxFontSizeMultiplier->value] === 1.5
        && $textElement
            ->properties()[PropKey::TextAdjustsFontSizeToFit->value] === true
        && $textElement->properties()[PropKey::TextMinimumFontScale->value] === 0.5
        && $textElement->properties()[PropKey::TextBreakStrategy->value]
            === TextBreakStrategy::Balanced->value
        && $textElement->properties()[PropKey::TextHyphenationFrequency->value]
            === TextHyphenationFrequency::Full->value
        && $textElement->properties()[PropKey::TextDataDetectorType->value]
            === TextDataDetectorType::Link->value,
    'Text helpers must preserve selection, fitting, breaking and detector properties.',
);
$assert(
    Text::make('Bounded')
        ->maxFontSizeMultiplier(0.5)
        ->properties()[PropKey::TextMaxFontSizeMultiplier->value] === 1.0
        && Text::make('Unbounded')
            ->maxFontSizeMultiplier(0.0)
            ->properties()[PropKey::TextMaxFontSizeMultiplier->value] === 0.0,
    'Text font scaling must encode zero as unbounded and clamp positive caps to at least one.',
);

$statusBarElement = StatusBar::make(
    0x80112233,
    StatusBarAppearance::Light,
    true,
)->animated()->translucent()->navigationBarHidden();
$assert(
    $statusBarElement->properties()[PropKey::StatusBarColor->value] === 0x80112233
        && $statusBarElement->properties()[PropKey::StatusBarStyle->value]
            === StatusBarAppearance::Light->value
        && $statusBarElement->properties()[PropKey::StatusBarHidden->value] === true
        && $statusBarElement->properties()[PropKey::StatusBarAnimated->value] === true
        && $statusBarElement->properties()[PropKey::StatusBarTranslucent->value] === true
        && $statusBarElement->properties()[PropKey::NavigationBarHidden->value] === true,
    'Status bar helpers must preserve color, style, visibility and edge-to-edge properties.',
);
$statusBarAliases = TemplateRenderer::render(
    TemplateCompiler::compile(
        '<StatusBar barStyle="light-content" backgroundColor="#F7F6F2" '
            .'animated="true" translucent="true" navigationBarHidden="true" />',
    ),
    null,
    [],
);
$assert(
    $statusBarAliases->properties()[PropKey::StatusBarColor->value] === 0xFFF7F6F2
        && $statusBarAliases->properties()[PropKey::StatusBarStyle->value]
            === StatusBarAppearance::Light->value
        && $statusBarAliases->properties()[PropKey::StatusBarAnimated->value] === true
        && $statusBarAliases->properties()[PropKey::StatusBarTranslucent->value] === true
        && $statusBarAliases->properties()[PropKey::NavigationBarHidden->value] === true,
    'StatusBar must accept the familiar backgroundColor and barStyle aliases.',
);
$statusBarDefaults = TemplateRenderer::render(
    TemplateCompiler::compile('<StatusBar barStyle="dark-content" />'),
    null,
    [],
);
$assert(
    !array_key_exists(
        PropKey::NavigationBarHidden->value,
        $statusBarDefaults->properties(),
    ),
    'StatusBar must not override global navigation visibility when the property is absent.',
);
$modalShown = false;
$modalDismissed = false;
$modalRequestedClose = false;
$modalOrientation = null;
$modalElement = Modal::make(
    Text::make('Modal content'),
    true,
    ModalPresentation::Sheet,
)
    ->animationType(ModalAnimationType::Slide)
    ->backdropColor(0xFF102030)
    ->transparent()
    ->hardwareAccelerated()
    ->navigationBarTranslucent()
    ->statusBarTranslucent()
    ->allowSwipeDismissal()
    ->onRequestClose(static function () use (&$modalRequestedClose): void {
        $modalRequestedClose = true;
    })
    ->onShow(static function () use (&$modalShown): void {
        $modalShown = true;
    })
    ->onDismiss(static function () use (&$modalDismissed): void {
        $modalDismissed = true;
    })
    ->onOrientationChange(
        static function (ModalOrientation $orientation) use (
            &$modalOrientation,
        ): void {
            $modalOrientation = $orientation;
        },
    );
$modalElement->events()[EventKind::ModalRequestClose->value]('');
$modalElement->events()[EventKind::ModalShow->value]('');
$modalElement->events()[EventKind::ModalDismiss->value]('');
$modalElement->events()[EventKind::ModalOrientationChange->value](
    (string) ModalOrientation::Landscape->value,
);
$assert(
    $modalElement->properties()[PropKey::ModalPresentation->value]
        === ModalPresentation::Sheet->value
        && $modalElement->properties()[PropKey::ModalAnimationType->value]
            === ModalAnimationType::Slide->value
        && $modalElement->properties()[PropKey::ModalBackdropColor->value]
            === 0xFF102030
        && $modalElement->properties()[PropKey::ModalTransparent->value] === true
        && $modalElement
            ->properties()[PropKey::ModalHardwareAccelerated->value] === true
        && $modalElement
            ->properties()[PropKey::ModalNavigationBarTranslucent->value] === true
        && $modalElement
            ->properties()[PropKey::ModalStatusBarTranslucent->value] === true
        && $modalElement
            ->properties()[PropKey::ModalAllowSwipeDismissal->value] === true
        && $modalRequestedClose
        && $modalShown
        && $modalDismissed
        && $modalOrientation === ModalOrientation::Landscape,
    'Modal helpers must preserve window configuration and typed lifecycle events.',
);

$scrollElement = Scroll::make(Text::make('Scrollable'))
    ->horizontal()
    ->contentOffset(24.0, 8.0)
    ->fillViewport(false)
    ->overScrollMode(ScrollOverScrollMode::Never)
    ->nestedScrollEnabled()
    ->fadingEdgeLength(12.0)
    ->persistentScrollbar()
    ->pagingEnabled()
    ->snapToInterval(80.0)
    ->decelerationRate(0.9)
    ->keyboardDismissMode(ScrollKeyboardDismissMode::OnDrag)
    ->scrollRequest(7, 'first-unread', 143.5, ScrollTargetAlignment::Center)
    ->scrollEnabled(false)
    ->showsIndicator()
    ->indicatorStyle(ScrollIndicatorStyle::Dark)
    ->onScroll(static function (): void {
    });
$assert(
    $scrollElement->properties()[PropKey::ScrollHorizontal->value] === true
        && $scrollElement->properties()[PropKey::ScrollIndicatorStyle->value] === ScrollIndicatorStyle::Dark->value
        && $scrollElement->properties()[PropKey::ScrollContentOffsetX->value] === 24.0
        && $scrollElement->properties()[PropKey::ScrollContentOffsetY->value] === 8.0
        && $scrollElement->properties()[PropKey::ScrollFillViewport->value] === false
        && $scrollElement->properties()[PropKey::ScrollOverScrollMode->value]
            === ScrollOverScrollMode::Never->value
        && $scrollElement->properties()[PropKey::ScrollNestedEnabled->value] === true
        && $scrollElement->properties()[PropKey::ScrollFadingEdgeLength->value] === 12.0
        && $scrollElement
            ->properties()[PropKey::ScrollPersistentScrollbar->value] === true
        && $scrollElement->properties()[PropKey::ScrollPagingEnabled->value] === true
        && $scrollElement->properties()[PropKey::ScrollSnapInterval->value] === 80.0
        && $scrollElement->properties()[PropKey::ScrollDecelerationRate->value] === 0.9
        && $scrollElement->properties()[PropKey::ScrollKeyboardDismissMode->value]
            === ScrollKeyboardDismissMode::OnDrag->value
        && $scrollElement->properties()[PropKey::ScrollTargetTestId->value]
            === 'first-unread'
        && $scrollElement->properties()[PropKey::ScrollTargetOffset->value] === 143.5
        && $scrollElement->properties()[PropKey::ScrollTargetAlignment->value]
            === ScrollTargetAlignment::Center->value
        && $scrollElement->properties()[PropKey::ScrollRequest->value] === 7
        && isset($scrollElement->events()[EventKind::Scroll->value]),
    'Scroll helpers must preserve Android-owned orientation, momentum and viewport behavior.',
);

$indicatorElement = ActivityIndicator::make(false)
    ->hidesWhenStopped(false)
    ->size(ActivityIndicatorSize::Large)
    ->color(0xFF2563EB);
$assert(
    $indicatorElement->properties()[PropKey::ActivityAnimating->value] === false
        && $indicatorElement
            ->properties()[PropKey::ActivityHidesWhenStopped->value] === false
        && $indicatorElement->properties()[PropKey::ActivitySize->value] === 36.0
        && $indicatorElement->properties()[PropKey::ProgressColor->value] === 0xFF2563EB,
    'Activity indicator helpers must preserve animation, stopped visibility, size and tint.',
);

$toggleElement = Toggle::make(true)
    ->trackColors(0xFF64748B, 0xFF2563EB)
    ->thumbColor(0xFFFFFFFF);
$assert(
    $toggleElement->properties()[PropKey::Checked->value] === true
        && $toggleElement
            ->properties()[PropKey::SwitchTrackColorFalse->value] === 0xFF64748B
        && $toggleElement
            ->properties()[PropKey::SwitchTrackColorTrue->value] === 0xFF2563EB
        && $toggleElement->properties()[PropKey::SwitchThumbColor->value] === 0xFFFFFFFF,
    'Switch helpers must preserve checked, track and thumb colors.',
);

$imageStarted = false;
$imageProgress = null;
$imageLoaded = null;
$imageError = null;
$imageEnded = false;
$imageElement = Image::make('https://example.test/photo.jpg')
    ->fit(ImageFit::Repeat)
    ->defaultSource('asset://placeholder.png')
    ->loadingIndicatorSource('asset://loading.png')
    ->fadeDuration(180)
    ->resizeMethod(ImageResizeMethod::Resize)
    ->resizeMultiplier(2.0)
    ->progressiveRendering()
    ->cache(ImageCachePolicy::ForceCache)
    ->overlayColor(0xFF0F172A)
    ->sourceSet(
        'https://example.test/photo.png 1x, '.
        'https://example.test/photo@2x.png 2x',
    )
    ->headers(['X-Image-Variant' => 'retina'])
    ->onLoadStart(static function () use (&$imageStarted): void {
        $imageStarted = true;
    })
    ->onProgress(
        static function (ImageProgressEvent $event) use (&$imageProgress): void {
            $imageProgress = $event;
        },
    )
    ->onLoad(
        static function (ImageLoadEvent $event) use (&$imageLoaded): void {
            $imageLoaded = $event;
        },
    )
    ->onError(
        static function (ImageErrorEvent $event) use (&$imageError): void {
            $imageError = $event;
        },
    )
    ->onLoadEnd(static function () use (&$imageEnded): void {
        $imageEnded = true;
    });
$imageElement->events()[EventKind::ImageLoadStart->value]('');
$imageElement->events()[EventKind::ImageProgress->value](Wire::map([
    'loaded' => 65_536,
    'total' => 131_072,
]));
$imageElement->events()[EventKind::ImageLoad->value](Wire::map([
    'uri' => 'https://example.test/photo@2x.png',
    'width' => 800.0,
    'height' => 600.0,
]));
$imageElement->events()[EventKind::ImageError->value](Wire::map([
    'error' => 'offline',
]));
$imageElement->events()[EventKind::ImageLoadEnd->value]('');
$imageBackground = ImageBackground::make(
    'asset://hero.jpg',
    Text::make('Overlay'),
)->tint(0xFFFFFFFF);
$assert(
    $imageElement->properties()[PropKey::ImageFit->value]
        === ImageFit::Repeat->value
        && $imageElement->properties()[PropKey::ImageDefaultSource->value]
            === 'asset://placeholder.png'
        && $imageElement
            ->properties()[PropKey::ImageLoadingIndicatorSource->value]
            === 'asset://loading.png'
        && $imageElement->properties()[PropKey::ImageFadeDurationMs->value]
            === 180
        && $imageElement->properties()[PropKey::ImageResizeMethod->value]
            === ImageResizeMethod::Resize->value
        && $imageElement->properties()[PropKey::ImageResizeMultiplier->value]
            === 2.0
        && $imageElement
            ->properties()[PropKey::ImageProgressiveRenderingEnabled->value]
            === true
        && $imageElement->properties()[PropKey::ImageCachePolicy->value]
            === ImageCachePolicy::ForceCache->value
        && $imageElement->properties()[PropKey::ImageOverlayColor->value]
            === 0xFF0F172A
        && $imageElement->properties()[PropKey::ImageRequestHeaders->value]
            === 'X-Image-Variant:retina'
        && $imageStarted
        && $imageProgress instanceof ImageProgressEvent
        && $imageProgress->loaded === 65_536
        && $imageLoaded instanceof ImageLoadEvent
        && $imageLoaded->width === 800.0
        && $imageError instanceof ImageErrorEvent
        && $imageError->message === 'offline'
        && $imageEnded
        && $imageBackground->children()[0]->kind() === NodeKind::Text
        && $imageBackground->properties()[PropKey::TintColor->value]
            === 0xFFFFFFFF,
    'Image helpers must preserve native loading, cache, resize, lifecycle and background behavior.',
);

$templateMediaScope = new class extends Component {
    public float $currentTime = -1.0;
    public float $duration = -1.0;

    public function mediaProgress(float $currentTime, float $duration): void
    {
        $this->currentTime = $currentTime;
        $this->duration = $duration;
    }

    public function render(): \Pam\Native\Element
    {
        return Text::make('media progress fixture');
    }
};
$templateMedia = TemplateRenderer::render(
    TemplateCompiler::compile(
        '<MediaPlayer source="https://example.test/video.mp4" '
        .'on:mediaProgress="mediaProgress" />',
    ),
    $templateMediaScope,
    [],
);
($templateMedia->events()[EventKind::MediaProgress->value])(Wire::map([
    'currentTime' => 2.5,
    'duration' => 10.0,
]));
$assert(
    $templateMediaScope->currentTime === 2.5
        && $templateMediaScope->duration === 10.0,
    'Declarative MediaPlayer progress must decode the wire map into two typed arguments.',
);

$drawingChanged = '';
$drawingCanvas = DrawingCanvas::make(
    'pam-file:///editor/source.jpg',
    '{"version":1,"strokes":[]}',
)
    ->brush(0xFF2563EB, 8.0, DrawingMode::Eraser)
    ->clearRequest(2)
    ->undoRequest(3)
    ->onChange(static function (string $value) use (&$drawingChanged): void {
        $drawingChanged = $value;
    });
($drawingCanvas->events()[EventKind::Change->value])('{"version":1,"strokes":[1]}');
$assert(
    $drawingCanvas->kind() === NodeKind::DrawingCanvas
        && $drawingCanvas->properties()[PropKey::Source->value]
            === 'pam-file:///editor/source.jpg'
        && $drawingCanvas->properties()[PropKey::DrawingColor->value] === 0xFF2563EB
        && $drawingCanvas->properties()[PropKey::DrawingWidth->value] === 8.0
        && $drawingCanvas->properties()[PropKey::DrawingMode->value]
            === DrawingMode::Eraser->value
        && $drawingCanvas->properties()[PropKey::DrawingClearRequest->value] === 2
        && $drawingCanvas->properties()[PropKey::DrawingUndoRequest->value] === 3
        && $drawingChanged === '{"version":1,"strokes":[1]}',
    'DrawingCanvas must keep stroke rendering and completed-stroke events native.',
);

$nativeControlTemplate = TemplateRenderer::render(
    TemplateCompiler::compile(<<<'PAM'
<Screen>
    <ScrollView
        horizontal="true"
        contentOffset="24"
        anchorToEnd="true"
        maintainVisibleContentPosition="true"
        autoScrollToEndThreshold="32"
        scrollTargetTestId="first-unread"
        scrollTargetOffset="143.5"
        scrollTargetAlignment="center"
        scrollRequest="9"
        pagingEnabled="true"
        snapToInterval="80"
        decelerationRate="fast"
        overScrollMode="never"
        keyboardDismissMode="on-drag"
    >
        <Text>Scrollable</Text>
    </ScrollView>
    <ActivityIndicator
        animating="false"
        hidesWhenStopped="false"
        size="large"
        progressColor="#2563eb"
    />
    <Switch
        checked="true"
        trackColorFalse="#64748b"
        trackColorTrue="#2563eb"
        thumbColor="#ffffff"
    />
    <DrawingCanvas
        source="pam-file:///editor/source.jpg"
        value="{&quot;version&quot;:1,&quot;strokes&quot;:[]}"
        brushColor="#2563eb"
        brushWidth="7"
        drawingMode="eraser"
        clearRequest="4"
        undoRequest="5"
    />
</Screen>
PAM),
    null,
    [],
);
$templateScroll = $nativeControlTemplate->children()[0];
$templateIndicator = $nativeControlTemplate->children()[1];
$templateSwitch = $nativeControlTemplate->children()[2];
$templateDrawing = $nativeControlTemplate->children()[3];
$assert(
    $templateScroll->properties()[PropKey::ScrollHorizontal->value] === true
        && $templateScroll
            ->properties()[PropKey::ScrollContentOffsetX->value] === 24.0
        && $templateScroll->properties()[PropKey::ScrollAnchorToEnd->value] === true
        && $templateScroll
            ->properties()[PropKey::ScrollMaintainVisibleContentPosition->value] === true
        && $templateScroll
            ->properties()[PropKey::ScrollAutoScrollToEndThreshold->value] === 32.0
        && $templateScroll
            ->properties()[PropKey::ScrollTargetTestId->value] === 'first-unread'
        && $templateScroll
            ->properties()[PropKey::ScrollTargetOffset->value] === 143.5
        && $templateScroll
            ->properties()[PropKey::ScrollTargetAlignment->value]
            === ScrollTargetAlignment::Center->value
        && $templateScroll->properties()[PropKey::ScrollRequest->value] === 9
        && $templateScroll->properties()[PropKey::ScrollPagingEnabled->value] === true
        && $templateScroll->properties()[PropKey::ScrollSnapInterval->value] === 80
        && $templateScroll
            ->properties()[PropKey::ScrollDecelerationRate->value] === 0.9
        && $templateIndicator->properties()[PropKey::ActivityAnimating->value] === false
        && $templateIndicator
            ->properties()[PropKey::ActivityHidesWhenStopped->value] === false
        && $templateIndicator->properties()[PropKey::ActivitySize->value] === 36.0
        && $templateSwitch
            ->properties()[PropKey::SwitchTrackColorFalse->value] === 0xFF64748B
        && $templateSwitch
            ->properties()[PropKey::SwitchTrackColorTrue->value] === 0xFF2563EB
        && $templateSwitch->properties()[PropKey::SwitchThumbColor->value] === 0xFFFFFFFF
        && $templateDrawing->kind() === NodeKind::DrawingCanvas
        && $templateDrawing->properties()[PropKey::DrawingColor->value] === 0xFF2563EB
        && (float) $templateDrawing->properties()[PropKey::DrawingWidth->value] === 7.0
        && $templateDrawing->properties()[PropKey::DrawingMode->value]
            === DrawingMode::Eraser->value
        && $templateDrawing->properties()[PropKey::DrawingClearRequest->value] === 4
        && $templateDrawing->properties()[PropKey::DrawingUndoRequest->value] === 5,
    'Native control tags must map to typed scroll, indicator, switch and drawing protocols.',
);
$normalDecelerationScroll = TemplateRenderer::render(
    TemplateCompiler::compile(
        '<ScrollView decelerationRate="normal"><Text>Normal</Text></ScrollView>',
    ),
    null,
    [],
);
$boundedDecelerationScroll = TemplateRenderer::render(
    TemplateCompiler::compile(
        '<ScrollView decelerationRate="1.5"><Text>Bounded</Text></ScrollView>',
    ),
    null,
    [],
);
$assert(
    $normalDecelerationScroll
        ->properties()[PropKey::ScrollDecelerationRate->value] === 0.985
        && $boundedDecelerationScroll
            ->properties()[PropKey::ScrollDecelerationRate->value] === 1.0,
    'Declarative ScrollView deceleration rates must normalize named aliases and bound numeric values.',
);

$listElement = FlatList::make(['One', 'Two', 'Three'])
    ->rowHeight(56.0)
    ->prefetch(8)
    ->columns(2)
    ->inverted()
    ->initialScrollIndex(1)
    ->removeClippedSubviews(false)
    ->scrollEnabled(false)
    ->showsIndicator(false)
    ->onScroll(static function (): void {
    })
    ->onEndReached(static function (): void {
    }, 0.25);
$assert(
    $listElement->properties()[PropKey::ListRowHeight->value] === 56.0
        && $listElement->properties()[PropKey::ListPrefetch->value] === 8
        && $listElement->properties()[PropKey::ListNumColumns->value] === 2
        && $listElement->properties()[PropKey::ListInverted->value] === true
        && $listElement->properties()[PropKey::ListInitialScrollIndex->value] === 1
        && $listElement
            ->properties()[PropKey::ListRemoveClippedSubviews->value] === false
        && $listElement->properties()[PropKey::ScrollEnabled->value] === false
        && $listElement->properties()[PropKey::ShowsScrollIndicator->value] === false
        && $listElement->properties()[PropKey::EndReachedThreshold->value] === 0.25
        && isset($listElement->events()[EventKind::Scroll->value])
        && isset($listElement->events()[EventKind::EndReached->value]),
    'List helpers must preserve recycling, prefetch, layout and scroll event properties.',
);

$richListElement = VirtualizedList::make(
    Column::make(
        Image::make('https://example.com/one.png'),
        Text::make('One'),
    )->key('one'),
    Pressable::make(Text::make('Two'))->key('two'),
)
    ->estimatedRowHeight(180.0)
    ->columns(2)
    ->prefetch(6)
    ->scrollRequest(4, 'target-cell', 320.0, ScrollTargetAlignment::End);
$assert(
    $richListElement->kind() === NodeKind::VirtualList
        && count($richListElement->children()) === 2
        && $richListElement->children()[0]->children()[0]->kind() === NodeKind::Image
        && $richListElement->properties()[PropKey::ListRowHeight->value] === 180.0
        && $richListElement->properties()[PropKey::ListNumColumns->value] === 2
        && $richListElement->properties()[PropKey::ListPrefetch->value] === 6
        && $richListElement->properties()[PropKey::ScrollTargetTestId->value] === 'target-cell'
        && $richListElement->properties()[PropKey::ScrollTargetOffset->value] === 320.0
        && $richListElement->properties()[PropKey::ScrollTargetAlignment->value]
            === ScrollTargetAlignment::End->value
        && $richListElement->properties()[PropKey::ScrollRequest->value] === 4,
    'VirtualizedList must retain arbitrary keyed component trees as recyclable cells.',
);
$adaptiveListTemplate = TemplateRenderer::render(
    TemplateCompiler::compile(
        '<VirtualizedList estimatedRowHeight="180"><Column height="240" /></VirtualizedList>',
    ),
    null,
    [],
);
$assert(
    $adaptiveListTemplate->properties()[PropKey::ListRowHeight->value] == 180.0
        && $adaptiveListTemplate->children()[0]->properties()[PropKey::Height->value] == 240.0,
    'VirtualizedList estimatedRowHeight must preserve an explicit rich-cell extent.',
);
$virtualScrollTemplate = TemplateRenderer::render(
    TemplateCompiler::compile(
        '<VirtualizedList scrollTargetOffset="0" scrollRequest="9"><Text>Top</Text></VirtualizedList>',
    ),
    null,
    [],
);
$assert(
    $virtualScrollTemplate->properties()[PropKey::ScrollTargetOffset->value] == 0.0
        && $virtualScrollTemplate->properties()[PropKey::ScrollRequest->value] === 9,
    'VirtualizedList must retain tokenized imperative scroll requests.',
);
$legacyVirtualizedList = VirtualizedList::make(['One', 'Two']);
$assert(
    $legacyVirtualizedList->kind() === NodeKind::List
        && $legacyVirtualizedList->children() === [],
    'VirtualizedList must remain source-compatible with legacy string-array call sites.',
);

$virtualGridElement = VirtualGrid::make(
    3,
    Text::make('A')->key('a'),
    Image::make('https://example.com/b.png')->key('b'),
);
$assert(
    $virtualGridElement->kind() === NodeKind::VirtualList
        && count($virtualGridElement->children()) === 2
        && $virtualGridElement->properties()[PropKey::ListNumColumns->value] === 3,
    'VirtualGrid must expose rich virtual cells with an explicit native column count.',
);

$sectionListElement = SectionList::make([
    'Frameworks' => ['Laravel', 'PAM'],
])
    ->rowHeight(52.0)
    ->prefetch(6)
    ->horizontal()
    ->columns(2)
    ->inverted()
    ->initialScrollIndex(1)
    ->removeClippedSubviews(false);
$assert(
    $sectionListElement->properties()[PropKey::ListRowHeight->value] === 52.0
        && $sectionListElement->properties()[PropKey::ListPrefetch->value] === 6
        && $sectionListElement->properties()[PropKey::ListHorizontal->value] === true
        && $sectionListElement->properties()[PropKey::ListNumColumns->value] === 2
        && $sectionListElement->properties()[PropKey::ListInverted->value] === true
        && $sectionListElement
            ->properties()[PropKey::ListInitialScrollIndex->value] === 1
        && $sectionListElement
            ->properties()[PropKey::ListRemoveClippedSubviews->value] === false,
    'Section list helpers must preserve native recycler configuration.',
);

$first = (new TreeEncoder())->encode($tree);
$second = (new TreeEncoder())->encode($tree);
$firstFrame = $first['frame'];
$secondFrame = $second['frame'];

if ($firstFrame === null || $secondFrame === null) {
    throw new RuntimeException('Fresh encoders must produce complete tree frames.');
}

$assert($firstFrame === $secondFrame, 'Tree encoding must be deterministic.');
$assert(str_starts_with($firstFrame, 'PNT1'), 'Tree frame magic is missing.');
$assert(count($first['callbacks']) === 1, 'Event callback was not registered.');

$invalidTreeTextRejected = false;
try {
    (new TreeEncoder())->encode(Text::make("\xc3\x28"));
} catch (InvalidArgumentException) {
    $invalidTreeTextRejected = true;
}
$assert($invalidTreeTextRejected, 'Tree encoding must reject malformed UTF-8 text.');

$invalidWireTextRejected = false;
try {
    Wire::map(['text' => "\xc3\x28"]);
} catch (InvalidArgumentException) {
    $invalidWireTextRejected = true;
}
$assert($invalidWireTextRejected, 'Wire maps must reject malformed UTF-8 text.');

$invalidPackedListTextRejected = false;
try {
    Wire::stringList(["\xc3\x28"]);
} catch (InvalidArgumentException) {
    $invalidPackedListTextRejected = true;
}
$assert($invalidPackedListTextRejected, 'Packed string lists must reject malformed UTF-8 text.');

$invalidPackedSectionTextRejected = false;
try {
    Wire::stringSections(['section' => ["\xc3\x28"]]);
} catch (InvalidArgumentException) {
    $invalidPackedSectionTextRejected = true;
}
$assert($invalidPackedSectionTextRejected, 'Packed sections must reject malformed UTF-8 text.');

$listBoundaryText = str_repeat('x', Wire::MAX_VALUE_BYTES - 8);
$assert(
    strlen(Wire::stringList([$listBoundaryText])) === Wire::MAX_VALUE_BYTES,
    'Packed string lists must accept the exact one-megabyte boundary.',
);
$oversizedStringListRejected = false;
try {
    Wire::stringList([$listBoundaryText.'x']);
} catch (InvalidArgumentException) {
    $oversizedStringListRejected = true;
}
$assert($oversizedStringListRejected, 'Packed string lists must reject one megabyte plus one byte.');

$sectionBoundaryText = str_repeat('x', Wire::MAX_VALUE_BYTES - 17);
$assert(
    strlen(Wire::stringSections(['a' => [$sectionBoundaryText]])) === Wire::MAX_VALUE_BYTES,
    'Packed sections must accept the exact one-megabyte boundary.',
);
$oversizedSectionListRejected = false;
try {
    Wire::stringSections(['a' => [$sectionBoundaryText.'x']]);
} catch (InvalidArgumentException) {
    $oversizedSectionListRejected = true;
}
$assert($oversizedSectionListRejected, 'Packed sections must reject one megabyte plus one byte.');

$maximumPackedItems = array_fill(0, Wire::MAX_LIST_ITEMS, '');
$assert(
    strlen(Wire::stringList($maximumPackedItems)) === 4 + (Wire::MAX_LIST_ITEMS * 4),
    'Packed string lists must accept exactly 100,000 items.',
);
$tooManyPackedItemsRejected = false;
try {
    Wire::stringList([...$maximumPackedItems, '']);
} catch (InvalidArgumentException) {
    $tooManyPackedItemsRejected = true;
}
$assert($tooManyPackedItemsRejected, 'Packed string lists must reject item 100,001.');
unset($maximumPackedItems);

$maximumSections = [];
for ($index = 0; $index < Wire::MAX_SECTIONS; $index++) {
    $maximumSections["s{$index}"] = [];
}
$assert(Wire::stringSections($maximumSections) !== '', 'Packed sections must accept 10,000 sections.');
$tooManySectionsRejected = false;
try {
    Wire::stringSections([...$maximumSections, 'overflow' => []]);
} catch (InvalidArgumentException) {
    $tooManySectionsRejected = true;
}
$assert($tooManySectionsRejected, 'Packed sections must reject section 10,001.');
unset($maximumSections);

$maximumSectionItems = array_fill(0, Wire::MAX_SECTION_ENTRIES - 1, '');
$assert(
    Wire::stringSections(['section' => $maximumSectionItems]) !== '',
    'Packed sections must accept exactly 100,000 total entries.',
);
$tooManySectionEntriesRejected = false;
try {
    Wire::stringSections(['section' => [...$maximumSectionItems, '']]);
} catch (InvalidArgumentException) {
    $tooManySectionEntriesRejected = true;
}
$assert($tooManySectionEntriesRejected, 'Packed sections must reject total entry 100,001.');
unset($maximumSectionItems);

$invalidWireDecodeRejected = false;
try {
    Wire::decodeMap(
        pack('v', 1).pack('v', 4).'text'."\x01".pack('V', 2)."\xc3\x28",
    );
} catch (InvalidArgumentException) {
    $invalidWireDecodeRejected = true;
}
$assert($invalidWireDecodeRejected, 'Wire map decoding must reject malformed UTF-8 text.');

$invalidWireKeyRejected = false;
try {
    Wire::map(['1invalid' => 'value']);
} catch (InvalidArgumentException) {
    $invalidWireKeyRejected = true;
}
$assert($invalidWireKeyRejected, 'Wire map encoding must reject non-portable keys.');

$invalidWireBooleanRejected = false;
try {
    Wire::decodeMap(pack('v', 1).pack('v', 4).'flag'."\x04\x02");
} catch (InvalidArgumentException) {
    $invalidWireBooleanRejected = true;
}
$assert($invalidWireBooleanRejected, 'Wire map decoding must reject invalid booleans.');

$duplicateWireKeyRejected = false;
try {
    Wire::decodeMap(
        pack('v', 2)
        .pack('v', 3).'key'."\x04\x00"
        .pack('v', 3).'key'."\x04\x01",
    );
} catch (InvalidArgumentException) {
    $duplicateWireKeyRejected = true;
}
$assert($duplicateWireKeyRejected, 'Wire map decoding must reject duplicate keys.');

$invalidTreeFloatRejected = false;
try {
    (new TreeEncoder())->encode(\Pam\Native\UI\Spacer::make(NAN));
} catch (InvalidArgumentException) {
    $invalidTreeFloatRejected = true;
}
$assert($invalidTreeFloatRejected, 'Tree encoding must reject non-finite floats.');

$invalidWireFloatRejected = false;
try {
    Wire::map(['value' => INF]);
} catch (InvalidArgumentException) {
    $invalidWireFloatRejected = true;
}
$assert($invalidWireFloatRejected, 'Wire map encoding must reject non-finite decimals.');

$invalidWireFloatDecodeRejected = false;
try {
    Wire::decodeMap(
        pack('v', 1).pack('v', 5).'value'."\x03".pack('e', NAN),
    );
} catch (InvalidArgumentException) {
    $invalidWireFloatDecodeRejected = true;
}
$assert($invalidWireFloatDecodeRejected, 'Wire map decoding must reject non-finite decimals.');

$canonicalWire = Wire::map([
    'zeta' => 42,
    'ratio' => 1.5,
    'enabled' => true,
    'alpha' => 'Pam',
]);
$assert(
    $canonicalWire === Wire::map([
        'alpha' => 'Pam',
        'enabled' => true,
        'ratio' => 1.5,
        'zeta' => 42,
    ])
        && bin2hex($canonicalWire)
            === '04000500616c706861010300000050616d0700656e61626c656404010500726174696f03000000000000f83f04007a657461022a00000000000000',
    'Wire maps must use the shared canonical key order and golden bytes.',
);

$wireBoundaryText = str_repeat('x', Wire::MAX_VALUE_BYTES - 10);
$assert(
    strlen(Wire::map(['a' => $wireBoundaryText])) === Wire::MAX_VALUE_BYTES,
    'Wire maps must accept the exact one-megabyte boundary.',
);

$oversizedWireEncodeRejected = false;
try {
    Wire::map(['a' => $wireBoundaryText.'x']);
} catch (InvalidArgumentException) {
    $oversizedWireEncodeRejected = true;
}
$assert($oversizedWireEncodeRejected, 'Wire map encoding must reject one megabyte plus one byte.');

$oversizedWireDecodeRejected = false;
try {
    Wire::decodeMap(
        pack('v', 1).pack('v', 1).'a'."\x01".pack('V', strlen($wireBoundaryText) + 1)
        .$wireBoundaryText.'x',
    );
} catch (InvalidArgumentException) {
    $oversizedWireDecodeRejected = true;
}
$assert($oversizedWireDecodeRejected, 'Wire map decoding must reject one megabyte plus one byte.');

$nativeContainer = CustomView::make(
    'community.container',
    ['axis' => 1],
    Text::make('Native child'),
);
$assert(
    count($nativeContainer->children()) === 1,
    'Custom native view containers must retain declarative children.',
);

$capturedParentVariants = null;
TemplateRegistry::reset();
TemplateRegistry::component(
    'VariantParent',
    static fn (array $props, array $children): \Pam\Native\Renderable =>
        Column::make(...$children),
);
TemplateRegistry::component(
    'VariantChild',
    static function (array $props) use (&$capturedParentVariants): \Pam\Native\Renderable {
        $capturedParentVariants = $props['__parentVariants'] ?? null;

        return Text::make('Child');
    },
);
$variantTemplate = TemplateCompiler::compile(
    '<VariantParent variant="outline" size="lg"><VariantChild /></VariantParent>',
);
TemplateRenderer::render($variantTemplate, null, []);
$assert(
    $capturedParentVariants === ['variant' => 'outline', 'size' => 'lg'],
    'Custom template components must inherit parent variant context.',
);
$gallery = [
    ['url' => 'file:///mountain.jpg', 'alt' => 'Mountain'],
    ['url' => 'file:///ocean.jpg', 'alt' => 'Ocean'],
];
$variantTemplate = TemplateCompiler::compile(
    '<VariantParent images="$gallery"><VariantChild /></VariantParent>',
);
TemplateRenderer::render($variantTemplate, null, ['gallery' => $gallery]);
$assert(
    $capturedParentVariants === ['images' => $gallery],
    'Bound declarative arrays must remain available to compound child components.',
);
$capturedClassName = null;
TemplateRegistry::component(
    'SemanticClasses',
    static function (
        array $props,
    ) use (&$capturedClassName): \Pam\Native\Renderable {
        $capturedClassName = $props['className'] ?? null;

        return Column::make();
    },
);
TemplateRegistry::styleResolver(
    static fn (string $class): ?array => $class === 'grid-cols-2'
        ? []
        : null,
);
$semanticClassTemplate = TemplateCompiler::compile(
    '<SemanticClasses class="grid-cols-2 gap-3" />',
);
$semanticClassElement = TemplateRenderer::render(
    $semanticClassTemplate,
    null,
    [],
);
$assert(
    $capturedClassName === 'grid-cols-2 gap-3'
        && ($semanticClassElement->properties()[PropKey::Gap->value] ?? null)
            === 12.0,
    'Registered template components must receive className before visual utilities are applied.',
);
$capturedStyleBoundaryProps = null;
TemplateRegistry::component(
    'StyleBoundary',
    static function (
        array $props,
    ) use (&$capturedStyleBoundaryProps): \Pam\Native\Renderable {
        $capturedStyleBoundaryProps = $props;

        return Text::make('Inherited');
    },
);
TemplateRenderer::render(
    TemplateCompiler::compile(
        '<Column textColor="#123456"><StyleBoundary /></Column>',
    ),
    null,
    [],
);
$assert(
    !array_key_exists('textColor', $capturedStyleBoundaryProps ?? [])
        && ($capturedStyleBoundaryProps['__pamInheritedStyles']['textColor'] ?? null)
            === 0xFF123456,
    'Inherited CSS must cross a component boundary as internal style context, not constructor props.',
);
$coreRoleElement = TemplateRenderer::render(
    TemplateCompiler::compile(
        '<Text accessibilityRole="header">Accessible heading</Text>',
    ),
    null,
    [],
);
$accessibilityActionScope = new class {
    /** @var list<array{name: string, label: string}> */
    public array $actions = [
        ['name' => 'archive', 'label' => 'Archive message'],
    ];

    public string $selectedAction = '';

    public function selectAction(string $name): void
    {
        $this->selectedAction = $name;
    }
};
$templateAccessibilityActionElement = TemplateRenderer::render(
    TemplateCompiler::compile(
        '<Text :accessibilityActions="$actions" on:accessibilityAction="selectAction">Message</Text>',
    ),
    $accessibilityActionScope,
    [],
);
$templateAccessibilityActionElement
    ->events()[EventKind::AccessibilityAction->value]('archive');
$assert(
    json_decode(
        $templateAccessibilityActionElement
            ->properties()[PropKey::AccessibilityActions->value],
        true,
        flags: JSON_THROW_ON_ERROR,
    ) === [['name' => 'archive', 'label' => 'Archive message']]
        && $accessibilityActionScope->selectedAction === 'archive',
    'Templates must preserve typed custom accessibility actions and their event payload.',
);
$flexAliasElement = TemplateRenderer::render(
    TemplateCompiler::compile(
        '<Row alignItems="flex-start" alignSelf="flex-end" justifyContent="flex-end" />',
    ),
    null,
    [],
);
$assert(
    $flexAliasElement->properties()[PropKey::AlignItems->value] === 1
        && $flexAliasElement->properties()[PropKey::AlignSelf->value] === 3
        && $flexAliasElement->properties()[PropKey::JustifyContent->value] === 3,
    'Template flex-start and flex-end aliases must match native start and end layout values.',
);
$baselineElement = TemplateRenderer::render(
    TemplateCompiler::compile('<Row alignItems="baseline" />'),
    null,
    [],
);
$assert(
    $baselineElement->properties()[PropKey::AlignItems->value] === \Pam\Native\Align::Baseline->value,
    'Template baseline alignment must reach the native layout engine.',
);
$gridElement = TemplateRenderer::render(
    TemplateCompiler::compile(
        '<Grid gutterX="16" gutterY="8"><Column span="12" spanSm="6" spanMd="4"><Image source="cover.webp" aspectRatio="1" /><Pressable><Text>Open</Text></Pressable></Column><Column class="col-6 col-lg-3 offset-lg-1 order-md-2" /></Grid>',
    ),
    null,
    [],
);
$assert(
    $gridElement->properties()[PropKey::GridColumns->value] === 12
        && $gridElement->properties()[PropKey::GridColumnGap->value] === 16.0
        && $gridElement->properties()[PropKey::GridRowGap->value] === 8.0
        && $gridElement->children()[0]->properties()[PropKey::GridSpan->value] === 12
        && $gridElement->children()[0]->properties()[PropKey::GridSpanSm->value] === 6
        && $gridElement->children()[0]->properties()[PropKey::GridSpanMd->value] === 4
        && $gridElement->children()[1]->properties()[PropKey::GridSpan->value] === 6
        && $gridElement->children()[1]->properties()[PropKey::GridSpanLg->value] === 3
        && $gridElement->children()[1]->properties()[PropKey::GridOffsetLg->value] === 1
        && $gridElement->children()[1]->properties()[PropKey::GridOrderMd->value] === 2
        && $gridElement->children()[0]->children()[0]->kind() === NodeKind::Image
        && $gridElement->children()[0]->children()[1]->kind() === NodeKind::Pressable,
    'Responsive grids must compile rich cells identically from explicit properties and utility classes.',
);
$autoFitTemplate = TemplateRenderer::render(
    TemplateCompiler::compile('<Grid columns="4" gridMinColumnWidth="120"><Column span="1"><Text>Adaptive</Text></Column></Grid>'),
    null,
    [],
);
$assert(
    $autoFitTemplate->properties()[PropKey::GridMinColumnWidth->value] === 120.0
        && (new \Pam\Native\Style(gridMinColumnWidth: 120.0))->properties()[PropKey::GridMinColumnWidth->value] === 120.0,
    'Auto-fit minimum width must compile through templates and typed Style.',
);
$virtualGridTemplate = TemplateRenderer::render(
    TemplateCompiler::compile('<Grid gridTemplate="0,2,8,4;640,3,12,8;768,4,16,12;1024,4,20,16;1280,5,24,20;1536,6,28,24"><Column span2xl="2" offset2xl="1" order2xl="3" /></Grid>'),
    null,
    [],
);
$gridWire = '0,2,8,4;640,3,12,8;768,4,16,12;1024,4,20,16;1280,5,24,20;1536,6,28,24';
$typedGridPlan = \Pam\Native\GridTemplate::fromWire($gridWire);
$typedGridStyle = new \Pam\Native\Style(gridTemplate: $typedGridPlan, gridSpan2xl: 2, gridOffset2xl: 1, gridOrder2xl: 3);
$assert($typedGridPlan->toWire() === $gridWire
    && $typedGridStyle->properties()[PropKey::GridTemplate->value] === $gridWire
    && $virtualGridTemplate->properties()[PropKey::GridTemplate->value] === $gridWire
    && $virtualGridTemplate->children()[0]->properties()[PropKey::GridSpan2xl->value] === 2
    && $virtualGridTemplate->children()[0]->properties()[PropKey::GridOffset2xl->value] === 1
    && $virtualGridTemplate->children()[0]->properties()[PropKey::GridOrder2xl->value] === 3,
    'Typed and template responsive plans must preserve all six levels and sixth-tier child properties.');
foreach (['', '1,2,0,0', '0,0,0,0', '0,65,0,0', '0,2,-1,0', '0,2,INF,0', '0,2,0,0;0,3,0,0', '0,2,0,0;',
    '0,2,0,0;640,3,0,0;640.000001,4,0,0', '0,2,0,0;1e-100,3,0,0'] as $invalidGridWire) {
    try {
        \Pam\Native\GridTemplate::fromWire($invalidGridWire);
        throw new RuntimeException('Invalid grid plan was accepted.');
    } catch (InvalidArgumentException) {
        $assert(true, 'Invalid grid plans fail before native dispatch.');
    }
}
$virtualGridTemplate = TemplateRenderer::render(
    TemplateCompiler::compile(
        '<VirtualGrid columns="2" rowHeight="220" prefetch="7"><Column key="photo-1"><Image source="one.webp" /><Text>One</Text></Column><Pressable key="photo-2"><Image source="two.webp" /></Pressable></VirtualGrid>',
    ),
    null,
    [],
);
$assert(
    $virtualGridTemplate->kind() === NodeKind::VirtualList
        && count($virtualGridTemplate->children()) === 2
        && $virtualGridTemplate->children()[0]->children()[0]->kind() === NodeKind::Image
        && $virtualGridTemplate->properties()[PropKey::ListNumColumns->value] === 2
        && $virtualGridTemplate->properties()[PropKey::ListRowHeight->value] === 220
        && $virtualGridTemplate->properties()[PropKey::ListPrefetch->value] === 7,
    'VirtualGrid markup must retain arbitrary keyed component trees and native list tuning.',
);
$assert(
    $coreRoleElement->properties()[PropKey::AccessibilityRole->value]
        === AccessibilityRole::Header->value,
    'Core tag accessibility roles must compile to sequential protocol integers.',
);
$pressScope = new class {
    public ?PressEvent $move = null;

    public function moved(PressEvent $event): void
    {
        $this->move = $event;
    }
};
$corePressableElement = TemplateRenderer::render(
    TemplateCompiler::compile(
        '<Pressable hitSlopLeft="4" hitSlopBottom="10" '
        .'pressRetentionOffset="12" delayLongPress="420" '
        .'androidDisableSound="true" rippleAlpha="0.5" '
        .'on:pressMove="moved"><Text>Open</Text></Pressable>',
    ),
    $pressScope,
    [],
);
$corePressableElement->events()[EventKind::PressMove->value](Wire::map([
    'x' => 2.0,
    'y' => 3.0,
    'pageX' => 12.0,
    'pageY' => 13.0,
    'timestamp' => 99,
    'pointerId' => 1,
]));
$assert(
    $corePressableElement->properties()[PropKey::HitSlopLeft->value] === 4.0
        && $corePressableElement
            ->properties()[PropKey::HitSlopBottom->value] === 10.0
        && $corePressableElement
            ->properties()[PropKey::PressRetentionLeft->value] === 12.0
        && $corePressableElement
            ->properties()[PropKey::PressRetentionBottom->value] === 12.0
        && $corePressableElement
            ->properties()[PropKey::PressDelayLongMs->value] === 420
        && $corePressableElement
            ->properties()[PropKey::PressAndroidDisableSound->value] === true
        && $corePressableElement
            ->properties()[PropKey::RippleAlpha->value] === 0.5
        && $pressScope->move instanceof PressEvent
        && $pressScope->move->pageX === 12.0,
    'Core Pressable tags must retain gesture properties and typed move events.',
);
$itemActionScope = new class {
    public string $selected = '';

    public function select(string $id): void
    {
        $this->selected = $id;
    }
};
$itemActionElement = TemplateRenderer::render(
    TemplateCompiler::compile(
        '<Column><Pressable v-for="$item in $items" '
        .'on:longPress="select($item[\'id\'])"><Text>{{ $item[\'id\'] }}</Text>'
        .'</Pressable></Column>',
    ),
    $itemActionScope,
    ['items' => [['id' => 'first'], ['id' => 'second']]],
);
$assert(
    $itemActionScope->selected === '',
    'Native event expressions must not execute during template rendering.',
);
$itemActionElement
    ->children()[1]
    ->events()[EventKind::LongPress->value]('');
$assert(
    $itemActionScope->selected === 'second',
    'Native event expressions must capture v-for item data until dispatch.',
);
$directiveScope = new class {
    /** @var list<string> */
    public array $calls = [];

    public function outside(): void { $this->calls[] = 'outside'; }
    public function intersect(): void { $this->calls[] = 'intersect'; }
    public function mutate(): void { $this->calls[] = 'mutate'; }
    public function resize(): void { $this->calls[] = 'resize'; }
    public function scroll(): void { $this->calls[] = 'scroll'; }
    public function touchStart(): void { $this->calls[] = 'touchStart'; }
    public function touchMove(): void { $this->calls[] = 'touchMove'; }
    public function touchEnd(): void { $this->calls[] = 'touchEnd'; }
};
$directiveElement = TemplateRenderer::render(
    TemplateCompiler::compile(
        '<View p-click-outside="outside" p-intersect="intersect" '
        .'p-mutate="mutate" p-resize="resize" p-scroll="scroll" '
        .'p-touch-start="touchStart" p-touch-move="touchMove" '
        .'p-touch-end="touchEnd"><Text>Directives</Text></View>',
    ),
    $directiveScope,
    [],
);
foreach ([
    EventKind::ClickOutside,
    EventKind::Intersect,
    EventKind::Mutate,
    EventKind::Resize,
    EventKind::Scroll,
    EventKind::TouchStart,
    EventKind::TouchMove,
    EventKind::TouchEnd,
] as $directiveEvent) {
    $directiveElement->events()[$directiveEvent->value]('');
}
$assert(
    $directiveScope->calls === [
        'outside',
        'intersect',
        'mutate',
        'resize',
        'scroll',
        'touchStart',
        'touchMove',
        'touchEnd',
    ],
    'Native p-* directives must compile to distinct append-only event handlers.',
);
$rippleDirective = TemplateRenderer::render(
    TemplateCompiler::compile(
        '<View p-ripple><Text>Ripple</Text></View>',
    ),
    null,
    [],
);
$assert(
    $rippleDirective->properties()[PropKey::RippleColor->value] === 0
        && $rippleDirective->properties()[PropKey::RippleAlpha->value] === 0.12
        && $rippleDirective->properties()[PropKey::RippleBorderless->value] === false
        && $rippleDirective->properties()[PropKey::RippleForeground->value] === false,
    'p-ripple must compile to a theme-aware native MD3 state layer.',
);
$modalScope = new class {
    public ?ModalOrientation $orientation = null;

    public function oriented(ModalOrientation $orientation): void
    {
        $this->orientation = $orientation;
    }
};
$coreModalElement = TemplateRenderer::render(
    TemplateCompiler::compile(
        '<Modal visible="true" presentation="fullScreen" '
        .'animationType="fade" transparent="true" '
        .'hardwareAccelerated="true" statusBarTranslucent="true" '
        .'on:orientationChange="oriented"><Text>Dialog</Text></Modal>',
    ),
    $modalScope,
    [],
);
$coreModalElement->events()[EventKind::ModalOrientationChange->value](
    (string) ModalOrientation::Landscape->value,
);
$assert(
    $coreModalElement->properties()[PropKey::ModalPresentation->value]
        === ModalPresentation::FullScreen->value
        && $coreModalElement->properties()[PropKey::ModalAnimationType->value]
            === ModalAnimationType::Fade->value
        && $coreModalElement->properties()[PropKey::ModalTransparent->value]
            === true
        && $coreModalElement
            ->properties()[PropKey::ModalHardwareAccelerated->value] === true
        && $coreModalElement
            ->properties()[PropKey::ModalStatusBarTranslucent->value] === true
        && $modalScope->orientation === ModalOrientation::Landscape,
    'Core Modal tags must preserve window properties and typed orientation events.',
);
$eventScope = new class {
    public string $submission = '';

    public function submit(string $payload): void
    {
        $this->submission = $payload;
    }
};
TemplateRegistry::component(
    'AdaptedEvent',
    static fn (array $_props, array $children): \Pam\Native\Renderable =>
        Column::make(...$children),
);
TemplateRegistry::eventAdapter(
    'AdaptedEvent',
    static fn (
        EventKind $_kind,
        Closure $handler,
        array $props,
    ): Closure => static function (string $payload) use (
        $handler,
        $props,
    ): void {
        $prefix = is_string($props['prefix'] ?? null)
            ? $props['prefix']
            : '';
        $handler($prefix.$payload);
    },
);
$adaptedEventTemplate = TemplateCompiler::compile(
    '<AdaptedEvent prefix="ui:" on:submit="submit" />',
);
$adaptedEventElement = TemplateRenderer::render(
    $adaptedEventTemplate,
    $eventScope,
    [],
);
$adaptedEventElement->events()[EventKind::Submit->value]('payload');
$assert(
    $eventScope->submission === 'ui:payload',
    'Registered components must be able to adapt declarative event contracts.',
);
$capturedEventContexts = null;
TemplateRegistry::component(
    'EventParent',
    static fn (array $_props, array $children): \Pam\Native\Renderable =>
        Column::make(...$children),
);
TemplateRegistry::component(
    'EventChild',
    static function (
        array $props,
    ) use (&$capturedEventContexts): \Pam\Native\Renderable {
        $capturedEventContexts = $props['__pamEventContexts'] ?? null;

        return Text::make('Child');
    },
);
$eventContextTemplate = TemplateCompiler::compile(
    '<EventParent value="framework" on:change="submit"><EventChild /></EventParent>',
);
TemplateRenderer::render($eventContextTemplate, $eventScope, []);
if (!is_array($capturedEventContexts)) {
    throw new RuntimeException('Declarative event contexts are missing.');
}
$eventContext = $capturedEventContexts['EventParent'] ?? null;
if (!is_array($eventContext)) {
    throw new RuntimeException('Declarative event context is missing.');
}
$eventContextEvents = $eventContext['events'] ?? null;
$eventContextProps = $eventContext['props'] ?? null;
$eventContextHandler = is_array($eventContextEvents)
    ? ($eventContextEvents[EventKind::Change->value] ?? null)
    : null;
if (!$eventContextHandler instanceof Closure) {
    throw new RuntimeException('Declarative event context handler is missing.');
}
if (!is_array($eventContextProps)) {
    throw new RuntimeException('Declarative event context props are missing.');
}
$eventContextHandler('laravel');
$assert(
    ($eventContextProps['value'] ?? null) === 'framework'
        && $eventScope->submission === 'laravel',
    'Registered child components must receive bounded ancestor event context.',
);
TemplateRegistry::reset();
TemplateRegistry::styleResolver(
    static fn (string $class): ?array => $class === 'w-1/2'
        ? [PropKey::WidthPercent->value => 50.0]
        : null,
);
$assert(
    TemplateRegistry::classProperties('w-1/2')
        === [PropKey::WidthPercent->value => 50.0],
    'Plugin utility resolvers must compile classes lazily.',
);
$assert(
    TemplateRegistry::classProperties('unknown-utility') === null,
    'Plugin utility resolvers must delegate unsupported classes.',
);
TemplateRegistry::reset();

$nestedStateChild = new class extends Component {
    /** @return array{label: string} */
    protected function initialState(): array
    {
        return ['label' => 'Nested A'];
    }

    public function changeLabel(string $label): void
    {
        $this->state->label = $label;
    }

    public function render(): \Pam\Native\Renderable
    {
        return Text::make((string) $this->state->label);
    }
};
$nestedStateParent = new class($nestedStateChild) extends Component {
    public function __construct(private readonly Component $child)
    {
    }

    /** @return array{revision: int} */
    protected function initialState(): array
    {
        return ['revision' => 0];
    }

    public function render(): \Pam\Native\Renderable
    {
        // Give the parent its own dependency so it is eligible for retained
        // subtree reuse, matching a real stateful route component.
        $this->state->revision;

        return Column::make($this->child);
    }
};
$nestedInitial = $nestedStateParent->toElement();
$nestedStateChild->changeLabel('Nested B');
$nestedUpdated = $nestedStateParent->toElement();
$assert(
    ($nestedInitial->children()[0]->properties()[PropKey::Text->value] ?? null) === 'Nested A'
        && ($nestedUpdated->children()[0]->properties()[PropKey::Text->value] ?? null) === 'Nested B',
    'Nested component state changes must invalidate every retained ancestor.',
);

$incremental = new TreeEncoder();
$initial = $incremental->encode(Text::make('A')->key('value'));
$unchanged = $incremental->encode(Text::make('A')->key('value'));
$patch = $incremental->encode(Text::make('B')->key('value'));
$initialFrame = $initial['frame'];
$patchFrame = $patch['frame'];

if ($initialFrame === null || $patchFrame === null) {
    throw new RuntimeException('Initial and changed trees must produce frames.');
}

$assert(str_starts_with($initialFrame, 'PNT1'), 'Initial tree frame is missing.');
$assert($unchanged['frame'] === null, 'An unchanged tree must not cross the native bridge.');
$assert(str_starts_with($patchFrame, 'PNP1'), 'Property update must use a patch frame.');
$assert(strlen($patchFrame) < strlen($initialFrame), 'Property patch must be smaller than the full tree.');

$structuralTree = Column::make(
    Text::make('B')->key('value'),
    Text::make('New')->key('new'),
)->key('content');
$structural = $incremental->encode($structuralTree);
$assert(
    $structural['frame'] !== null && str_starts_with($structural['frame'], 'PNP1'),
    'Structural changes after boot must use a patch frame.',
);
$incremental->forceFullFrame();
$recovery = $incremental->encode($structuralTree);
$assert(
    $recovery['full']
        && $recovery['frame'] !== null
        && str_starts_with($recovery['frame'], 'PNT1'),
    'A rejected patch must be recoverable with a complete frame.',
);

$wire = Wire::map([
    'name' => 'Pam',
    'count' => 42,
    'ratio' => 1.5,
    'enabled' => true,
]);
$assert(Wire::decodeMap($wire) == [
    'count' => 42,
    'enabled' => true,
    'name' => 'Pam',
    'ratio' => 1.5,
], 'Wire map round-trip failed.');

$counter = new class extends Component {
    public int $count = 0;

    public function render(): \Pam\Native\Element
    {
        return Screen::make(
            Button::make("Count: {$this->count}")
                ->key('counter')
                ->onPress(function (): void {
                    $this->count++;
                }),
        );
    }
};

App::run($counter);
$frame = Runtime::lastFrame();
$assert($frame !== null, 'App did not render its initial frame.');
$moduleResult = null;
$requestId = NativeModules::call(
    'community.echo',
    'echo',
    ['message' => 'fast'],
    static function (NativeModuleResult $result) use (&$moduleResult): void {
        $moduleResult = $result;
    },
);
$assert(
    TestDiagnostics::$moduleCall !== null
        && TestDiagnostics::$moduleCall['requestId'] === $requestId
        && TestDiagnostics::$moduleCall['module'] === 'community.echo'
        && Wire::decodeMap(TestDiagnostics::$moduleCall['payload']) == ['message' => 'fast'],
    'Public native module facade did not emit a typed bridge call.',
);
Runtime::dispatchModuleResult(
    $requestId,
    \Pam\Native\ModuleResultStatus::Success->value,
    Wire::map(['message' => 'fast']),
);
$assert(
    $moduleResult instanceof NativeModuleResult
        && $moduleResult->succeeded()
        && $moduleResult->values() === ['message' => 'fast'],
    'Public native module facade did not decode its result.',
);

$captureError = null;
$captureSucceeded = false;
$captureRequestId = MediaCapture::capture(
    CaptureType::Photo,
    static function (FileReference $_) use (&$captureSucceeded): void {
        $captureSucceeded = true;
    },
    static function (string $message) use (&$captureError): void {
        $captureError = $message;
    },
);
Runtime::dispatchModuleResult(
    $captureRequestId,
    ModuleResultStatus::Failure->value,
    'Camera is unavailable.',
);
$assert(
    !$captureSucceeded && $captureError === 'Camera is unavailable.',
    'Media capture failures must reach the optional failure callback.',
);

$location = null;
$locationRequest = Location::current(
    static function (LocationPosition $position) use (&$location): void {
        $location = $position;
    },
    highAccuracy: false,
    timeoutMs: 4_000,
    maximumAgeMs: 12_000,
);
$locationCall = TestDiagnostics::$moduleCall;
$locationPayload = $locationCall === null
    ? []
    : Wire::decodeMap($locationCall['payload']);
$assert(
    $locationCall !== null
        && $locationCall['requestId'] === $locationRequest
        && $locationCall['module'] === 'location'
        && $locationCall['method'] === 'current'
        && $locationPayload === [
            'highAccuracy' => false,
            'maximumAgeMs' => 12_000,
            'timeoutMs' => 4_000,
        ],
    'Location facade did not emit its typed native module call.',
);
Runtime::dispatchModuleResult(
    $locationRequest,
    ModuleResultStatus::Success->value,
    Wire::map([
        'latitude' => -23.55052,
        'longitude' => -46.633308,
        'accuracy' => 3.5,
        'altitude' => 760.0,
        'speed' => 0.4,
        'bearing' => 90.0,
        'timestamp' => 1_785_000_000_000,
    ]),
);
$assert(
    $location instanceof LocationPosition
        && $location->latitude === -23.55052
        && $location->longitude === -46.633308
        && $location->accuracy === 3.5
        && $location->timestamp === 1_785_000_000_000,
    'Location facade did not decode the native position.',
);

$locationFailure = null;
$failedLocationRequest = Location::current(
    static function (LocationPosition $_): void {
        throw new RuntimeException('A failed location request must not resolve a position.');
    },
    failure: static function (string $message) use (&$locationFailure): void {
        $locationFailure = $message;
    },
);
Runtime::dispatchModuleResult(
    $failedLocationRequest,
    ModuleResultStatus::Failure->value,
    'Location request timed out.',
);
$assert(
    $locationFailure === 'Location request timed out.',
    'Location failures must reach the optional failure callback.',
);

foreach ([true, false] as $notificationGranted) {
    $notificationDecision = null;
    $permissionRequest = \Pam\Native\System\Notifications::requestPermission(
        static function (bool $granted) use (&$notificationDecision): void { $notificationDecision = $granted; },
        failure: static function (string $message): void { throw new RuntimeException('A permission decision is not a failure.'); },
    );
    Runtime::dispatchModuleResult($permissionRequest, ModuleResultStatus::Success->value, Wire::map(['granted' => $notificationGranted]));
    $assert($notificationDecision === $notificationGranted, 'Notification permission must preserve granted and denied decisions.');
}
$notificationFailure = null;
$permissionRequest = \Pam\Native\System\Notifications::requestPermission(
    static function (bool $granted): void { throw new RuntimeException('Native failure must not invoke permission success.'); },
    failure: static function (string $message) use (&$notificationFailure): void { $notificationFailure = $message; },
);
Runtime::dispatchModuleResult($permissionRequest, ModuleResultStatus::Failure->value, 'No foreground activity.');
$assert($notificationFailure === 'No foreground activity.', 'Notification permission failure must reach the optional callback.');
$permissionRequest = \Pam\Native\System\Notifications::requestPermission(static function (bool $granted): void {});
$permissionErrorsBefore = count(TestDiagnostics::$messages);
Runtime::dispatchModuleResult($permissionRequest, ModuleResultStatus::Failure->value, 'Permission module failed.');
$assert(count(TestDiagnostics::$messages) === $permissionErrorsBefore + 1
    && str_contains(TestDiagnostics::$messages[array_key_last(TestDiagnostics::$messages)], 'Permission module failed.'),
    'Omitting the permission failure callback must preserve legacy error reporting.');
array_pop(TestDiagnostics::$messages);

$pushRegistrationFailure = null;
$pushRegistrationRequest = PushNotifications::register(
    static function (): void {
        throw new RuntimeException('Failed push registration must not invoke success.');
    },
    static function (string $message) use (&$pushRegistrationFailure): void {
        $pushRegistrationFailure = $message;
    },
);
$pushRegistrationCall = TestDiagnostics::$moduleCall;
$assert(
    $pushRegistrationCall !== null
        && $pushRegistrationCall['requestId'] === $pushRegistrationRequest
        && $pushRegistrationCall['module'] === 'notifications'
        && $pushRegistrationCall['method'] === 'registerPush',
    'Push registration must emit its typed native module call.',
);
Runtime::dispatchModuleResult(
    $pushRegistrationRequest,
    ModuleResultStatus::Failure->value,
    'Firebase rejected push token registration.',
);
$assert(
    $pushRegistrationFailure === 'Firebase rejected push token registration.',
    'Push registration failures must reach the optional failure callback.',
);

$pushUnregistered = false;
$pushUnregisterRequest = PushNotifications::unregister(
    static function () use (&$pushUnregistered): void { $pushUnregistered = true; },
    static function (string $message): void { throw new RuntimeException($message); },
);
$pushUnregisterCall = TestDiagnostics::$moduleCall;
$assert(
    $pushUnregisterCall !== null
        && $pushUnregisterCall['requestId'] === $pushUnregisterRequest
        && $pushUnregisterCall['module'] === 'notifications'
        && $pushUnregisterCall['method'] === 'unregisterPush',
    'Push unregistration must emit its typed native module call.',
);
Runtime::dispatchModuleResult($pushUnregisterRequest, ModuleResultStatus::Success->value, '');
$assert($pushUnregistered, 'Push unregistration must invoke its success callback.');

$pushUnregisterFailure = null;
$failedPushUnregisterRequest = PushNotifications::unregister(
    static function (): void { throw new RuntimeException('Failed push unregistration must not invoke success.'); },
    static function (string $message) use (&$pushUnregisterFailure): void { $pushUnregisterFailure = $message; },
);
Runtime::dispatchModuleResult(
    $failedPushUnregisterRequest,
    ModuleResultStatus::Failure->value,
    'Firebase rejected push token unregistration.',
);
$assert(
    $pushUnregisterFailure === 'Firebase rejected push token unregistration.',
    'Push unregistration failures must reach the optional failure callback.',
);

$recording = null;
$audioRequest = AudioRecorder::stop(
    static function (AudioRecording $value) use (&$recording): void {
        $recording = $value;
    },
);
$assert(
    TestDiagnostics::$moduleCall !== null
        && TestDiagnostics::$moduleCall['requestId'] === $audioRequest
        && TestDiagnostics::$moduleCall['module'] === 'audio-recorder'
        && TestDiagnostics::$moduleCall['method'] === 'stop',
    'Audio recorder facade did not emit its typed native module call.',
);
Runtime::dispatchModuleResult(
    $audioRequest,
    ModuleResultStatus::Success->value,
    Wire::map([
        'uri' => 'file:///tmp/pam-voice-test.m4a',
        'relativePath' => 'recordings/pam-voice-test.m4a',
        'fileName' => 'pam-voice-test.m4a',
        'mimeType' => 'audio/mp4',
        'durationMs' => 2_400,
        'size' => 19_200,
    ]),
);
$assert(
    $recording instanceof AudioRecording
        && $recording->durationMs === 2_400
        && $recording->size === 19_200
        && $recording->relativePath === 'recordings/pam-voice-test.m4a'
        && $recording->mimeType === 'audio/mp4',
    'Audio recorder facade did not decode the native recording.',
);

$audioFailure = null;
$audioStartRequest = AudioRecorder::start(
    static function (): void {
        throw new RuntimeException('Failed audio start must not invoke success.');
    },
    static function (string $message) use (&$audioFailure): void {
        $audioFailure = $message;
    },
);
Runtime::dispatchModuleResult(
    $audioStartRequest,
    ModuleResultStatus::Failure->value,
    'Microphone is unavailable.',
);
$assert(
    $audioFailure === 'Microphone is unavailable.',
    'Audio recorder failures must reach the optional failure callback.',
);

$linkOpenFailure = null;
$linkOpenRequest = \Pam\Native\System\Linking::open(
    'invalid://destination',
    static function (): void {
        throw new RuntimeException('Failed link open must not invoke success.');
    },
    static function (string $message) use (&$linkOpenFailure): void {
        $linkOpenFailure = $message;
    },
);
Runtime::dispatchModuleResult(
    $linkOpenRequest,
    ModuleResultStatus::Failure->value,
    'No application can open this URL.',
);
$assert(
    $linkOpenFailure === 'No application can open this URL.',
    'Link open failures must reach the optional failure callback.',
);

$pickedFiles = [];
$pickManyRequest = Files::pickMany(
    MediaPickerType::Media,
    static function (array $files) use (&$pickedFiles): void {
        $pickedFiles = $files;
    },
    6,
);
$pickManyCall = TestDiagnostics::$moduleCall;
$pickManyPayload = $pickManyCall === null
    ? []
    : Wire::decodeMap($pickManyCall['payload']);
$assert(
    $pickManyCall !== null
        && $pickManyCall['requestId'] === $pickManyRequest
        && $pickManyCall['module'] === 'files'
        && $pickManyCall['method'] === 'pickMany'
        && $pickManyPayload === ['limit' => 6, 'type' => MediaPickerType::Media->value],
    'Files pickMany must emit a bounded typed native module call.',
);
Runtime::dispatchModuleResult(
    $pickManyRequest,
    ModuleResultStatus::Success->value,
    Wire::map([
        'items' => json_encode([
            [
                'path' => 'imports/photo-one.jpg',
                'name' => 'photo-one.jpg',
                'mimeType' => 'image/jpeg',
                'size' => 1_024,
            ],
            [
                'path' => 'imports/photo-two.webp',
                'name' => 'photo-two.webp',
                'mimeType' => 'image/webp',
                'size' => 2_048,
            ],
        ], JSON_THROW_ON_ERROR),
    ]),
);
$assert(
    count($pickedFiles) === 2
        && $pickedFiles[0] instanceof FileReference
        && $pickedFiles[0]->path === 'imports/photo-one.jpg'
        && $pickedFiles[0]->uri() === 'pam-file:///imports/photo-one.jpg'
        && $pickedFiles[1]->mimeType === 'image/webp'
        && $pickedFiles[1]->size === 2_048,
    'Files pickMany must decode every native file reference in selection order.',
);

$cancelledPick = new FileReference('unexpected', 'unexpected', 'text/plain', 1);
$cancelledPickRequest = Files::pick(
    MediaPickerType::Image,
    static function (?FileReference $file) use (&$cancelledPick): void {
        $cancelledPick = $file;
    },
);
Runtime::dispatchModuleResult(
    $cancelledPickRequest,
    ModuleResultStatus::Success->value,
    '',
);
$assert(
    $cancelledPick === null,
    'Files pick must resolve user cancellation with null instead of throwing.',
);

$largePickFailure = null;
$largePickRequest = Files::pick(
    MediaPickerType::Any,
    static function (?FileReference $file): void {
        throw new RuntimeException('Failed document pick must not invoke success.');
    },
    mimeType: 'application/zip',
    failure: static function (string $message) use (&$largePickFailure): void {
        $largePickFailure = $message;
    },
    maximumBytes: 2_147_483_648,
);
$largePickCall = TestDiagnostics::$moduleCall;
$largePickPayload = $largePickCall === null ? [] : Wire::decodeMap($largePickCall['payload']);
$assert(
    $largePickCall !== null
        && $largePickCall['method'] === 'pick'
        && ($largePickPayload['type'] ?? null) === MediaPickerType::Any->value
        && ($largePickPayload['mimeType'] ?? null) === 'application/zip'
        && ($largePickPayload['maximumBytes'] ?? null) === 2_147_483_648,
    'Files pick must forward a typed MIME filter and explicit streaming import limit.',
);
Runtime::dispatchModuleResult(
    $largePickRequest,
    ModuleResultStatus::Failure->value,
    'Selected file exceeds 2048 MiB',
);
$assert(
    $largePickFailure === 'Selected file exceeds 2048 MiB',
    'Files pick must deliver native import errors to the optional failure callback.',
);
foreach (['application/zip\n', 'not-a-mime'] as $invalidMime) {
    $rejected = false;
    try {
        Files::pick(MediaPickerType::Any, static function (): void {}, mimeType: $invalidMime);
    } catch (InvalidArgumentException) {
        $rejected = true;
    }
    $assert($rejected, 'Files pick must reject malformed MIME filters before calling native code.');
}
foreach ([0, 8_589_934_593] as $invalidLimit) {
    $rejected = false;
    try {
        Files::pick(MediaPickerType::Any, static function (): void {}, maximumBytes: $invalidLimit);
    } catch (InvalidArgumentException) {
        $rejected = true;
    }
    $assert($rejected, 'Files pick must reject unsafe import limits before calling native code.');
}

$cancelledMany = [new FileReference('unexpected', 'unexpected', 'text/plain', 1)];
$cancelledManyRequest = Files::pickMany(
    MediaPickerType::Media,
    static function (array $files) use (&$cancelledMany): void {
        $cancelledMany = $files;
    },
);
Runtime::dispatchModuleResult(
    $cancelledManyRequest,
    ModuleResultStatus::Success->value,
    Wire::map(['items' => '[]']),
);
$assert(
    $cancelledMany === [],
    'Files pickMany must resolve user cancellation with an empty list.',
);

$cancelledCapture = new FileReference('unexpected', 'unexpected', 'text/plain', 1);
$cancelledCaptureRequest = \Pam\Native\System\MediaCapture::capture(
    \Pam\Native\CaptureType::Photo,
    static function (?FileReference $file) use (&$cancelledCapture): void {
        $cancelledCapture = $file;
    },
);
Runtime::dispatchModuleResult(
    $cancelledCaptureRequest,
    ModuleResultStatus::Success->value,
    '',
);
$assert(
    $cancelledCapture === null,
    'Media capture must resolve user cancellation with null instead of throwing.',
);

$fileDigest = null;
$hashRequest = Files::sha256('documents/identity.pdf', static function (string $digest) use (&$fileDigest): void {
    $fileDigest = $digest;
});
$hashCall = TestDiagnostics::$moduleCall;
$assert($hashCall !== null && $hashCall['module'] === 'files' && $hashCall['method'] === 'sha256'
    && Wire::decodeMap($hashCall['payload']) === ['path' => 'documents/identity.pdf'],
    'Files SHA-256 must bridge only a private path, never file bytes.');
Runtime::dispatchModuleResult($hashRequest, ModuleResultStatus::Success->value, Wire::map(['sha256' => hash('sha256', 'abc')]));
$assert($fileDigest === hash('sha256', 'abc'), 'Files SHA-256 must deliver the native digest.');

$hashFailure = null;
$hashRequest = Files::sha256('missing.pdf', static function (string $_): void {}, static function (string $message) use (&$hashFailure): void {
    $hashFailure = $message;
});
Runtime::dispatchModuleResult($hashRequest, ModuleResultStatus::Failure->value, 'File does not exist');
$assert($hashFailure === 'File does not exist', 'Files SHA-256 must expose native failure through the optional failure callback.');

foreach (['', ' ', '/absolute', '../outside', 'a//b', 'a/../b', 'a\\b', "bad\nname", str_repeat('a', 4097)] as $unsafeHashPath) {
    $rejected = false;
    try { Files::sha256($unsafeHashPath, static function (string $_): void {}); }
    catch (InvalidArgumentException) { $rejected = true; }
    $assert($rejected, 'Files SHA-256 must reject unsafe private paths before crossing the bridge.');
}
$diagnosticsBeforeHashTests = TestDiagnostics::$messages;
foreach (['', str_repeat('A', 64), str_repeat('g', 64), str_repeat('a', 63), str_repeat('a', 64)."\n", 42] as $invalidDigest) {
    $fileDigest = null;
    $beforeMessages = count(TestDiagnostics::$messages);
    $hashRequest = Files::sha256('document.pdf', static function (string $digest) use (&$fileDigest): void { $fileDigest = $digest; });
    Runtime::dispatchModuleResult($hashRequest, ModuleResultStatus::Success->value, Wire::map(['sha256' => $invalidDigest]));
    $assert($fileDigest === null && count(TestDiagnostics::$messages) > $beforeMessages,
        'Files SHA-256 must reject malformed native digest results.');
}
TestDiagnostics::$messages = $diagnosticsBeforeHashTests;

$copiedAsset = null;
$copyAssetRequest = Files::copyAsset(
    'assets/templates/story.webp',
    'drafts/story.webp',
    static function (FileReference $file) use (&$copiedAsset): void {
        $copiedAsset = $file;
    },
);
$copyAssetCall = TestDiagnostics::$moduleCall;
$assert(
    $copyAssetCall !== null
        && $copyAssetCall['requestId'] === $copyAssetRequest
        && $copyAssetCall['module'] === 'files'
        && $copyAssetCall['method'] === 'copyAsset'
        && Wire::decodeMap($copyAssetCall['payload']) == [
            'assetPath' => 'assets/templates/story.webp',
            'path' => 'drafts/story.webp',
        ],
    'Files copyAsset must emit safe project and sandbox paths.',
);
Runtime::dispatchModuleResult(
    $copyAssetRequest,
    ModuleResultStatus::Success->value,
    Wire::map([
        'path' => 'drafts/story.webp',
        'name' => 'story.webp',
        'mimeType' => 'image/webp',
        'size' => 75_446,
    ]),
);
$assert(
    $copiedAsset instanceof FileReference
        && $copiedAsset->path === 'drafts/story.webp'
        && $copiedAsset->mimeType === 'image/webp',
    'Files copyAsset must return the materialized typed file reference.',
);
$unsafeAssetRejected = false;
try {
    Files::copyAsset('../secret', 'drafts/secret', static function (FileReference $_): void {});
} catch (InvalidArgumentException) {
    $unsafeAssetRejected = true;
}
$assert($unsafeAssetRejected, 'Files copyAsset must reject traversal before crossing the bridge.');

$downloadedFile = null;
$downloadRequest = Files::download(
    'https://cdn.example.test/media/story.webp',
    'drafts/remote-story.webp',
    static function (FileReference $file) use (&$downloadedFile): void {
        $downloadedFile = $file;
    },
    8_388_608,
);
$downloadCall = TestDiagnostics::$moduleCall;
$assert(
    $downloadCall !== null
        && $downloadCall['requestId'] === $downloadRequest
        && $downloadCall['module'] === 'files'
        && $downloadCall['method'] === 'download'
        && Wire::decodeMap($downloadCall['payload']) == [
            'url' => 'https://cdn.example.test/media/story.webp',
            'path' => 'drafts/remote-story.webp',
            'maximumBytes' => 8_388_608,
            'headers' => '[]',
        ],
    'Files download must emit a bounded HTTPS sandbox download.',
);
Runtime::dispatchModuleResult(
    $downloadRequest,
    ModuleResultStatus::Success->value,
    Wire::map([
        'path' => 'drafts/remote-story.webp',
        'name' => 'remote-story.webp',
        'mimeType' => 'image/webp',
        'size' => 82_944,
    ]),
);
$assert(
    $downloadedFile instanceof FileReference
        && $downloadedFile->path === 'drafts/remote-story.webp'
        && $downloadedFile->size === 82_944,
    'Files download must decode the materialized typed file reference.',
);
$unsafeDownloadRejected = false;
try {
    Files::download(
        'http://example.test/media.webp',
        'drafts/media.webp',
        static function (FileReference $_): void {},
    );
} catch (InvalidArgumentException) {
    $unsafeDownloadRejected = true;
}
$assert($unsafeDownloadRejected, 'Files download must reject non-HTTPS URLs before crossing the bridge.');

$downloadProgress = null;
$downloadWithProgressFile = null;
$downloadWithProgressError = null;
$downloadSubscription = Files::downloadWithProgress(
    'https://api.example.test/private/report.pdf',
    'documents/report.pdf',
    static function (FileReference $file) use (&$downloadWithProgressFile): void {
        $downloadWithProgressFile = $file;
    },
    static function (FileDownloadProgress $progress) use (&$downloadProgress): void {
        $downloadProgress = $progress;
    },
    ['Authorization' => 'Bearer secret-token'],
    16_777_216,
    static function (string $message) use (&$downloadWithProgressError): void {
        $downloadWithProgressError = $message;
    },
);
$downloadStartRequest = TestDiagnostics::$moduleCall['requestId'] ?? 0;
$downloadStartPayload = Wire::decodeMap(TestDiagnostics::$moduleCall['payload'] ?? '');
$assert(
    $downloadSubscription > 0
        && (TestDiagnostics::$moduleCall['method'] ?? '') === 'downloadStart'
        && $downloadStartPayload['headers'] === '{"Authorization":"Bearer secret-token"}',
    'Progress downloads must forward validated authentication headers.',
);
Runtime::dispatchModuleResult(
    $downloadStartRequest,
    ModuleResultStatus::Success->value,
    Wire::map(['subscription' => 77]),
);
$downloadNextRequest = TestDiagnostics::$moduleCall['requestId'] ?? 0;
$assert(
    (TestDiagnostics::$moduleCall['method'] ?? '') === 'downloadNext'
        && Wire::decodeMap(TestDiagnostics::$moduleCall['payload'] ?? '') == ['subscription' => 77],
    'Progress downloads must consume the native observation channel.',
);
Runtime::dispatchModuleResult(
    $downloadNextRequest,
    ModuleResultStatus::Success->value,
    Wire::map([
        'state' => 1,
        'bytesWritten' => 512,
        'totalBytes' => 1024,
    ]),
);
$assert(
    $downloadProgress instanceof FileDownloadProgress
        && $downloadProgress->fraction() === 0.5,
    'Progress downloads must expose typed byte progress.',
);
$downloadCompleteRequest = TestDiagnostics::$moduleCall['requestId'] ?? 0;
Runtime::dispatchModuleResult(
    $downloadCompleteRequest,
    ModuleResultStatus::Success->value,
    Wire::map([
        'state' => 2,
        'path' => 'documents/report.pdf',
        'name' => 'report.pdf',
        'mimeType' => 'application/pdf',
        'size' => 1024,
    ]),
);
$assert(
    $downloadWithProgressFile instanceof FileReference
        && $downloadWithProgressFile->path === 'documents/report.pdf'
        && $downloadWithProgressError === null,
    'Progress downloads must resolve their typed sandbox file.',
);
$openFile = false;
$openRequest = Files::open(
    'documents/report.pdf',
    'application/pdf',
    static function () use (&$openFile): void { $openFile = true; },
    static function (string $_): void {},
);
$assert(
    (TestDiagnostics::$moduleCall['method'] ?? '') === 'open'
        && Wire::decodeMap(TestDiagnostics::$moduleCall['payload'] ?? '') == [
            'path' => 'documents/report.pdf',
            'mimeType' => 'application/pdf',
        ],
    'Files open must request a sandboxed platform viewer.',
);
Runtime::dispatchModuleResult($openRequest, ModuleResultStatus::Success->value, '');
$assert($openFile, 'Files open must report a successful viewer launch.');

$importedFile = null;
$importUriRequest = Files::importUri(
    'content://media/external/images/media/42',
    static function (FileReference $file) use (&$importedFile): void {
        $importedFile = $file;
    },
);
$importUriCall = TestDiagnostics::$moduleCall;
$assert(
    $importUriCall !== null
        && $importUriCall['requestId'] === $importUriRequest
        && $importUriCall['module'] === 'files'
        && $importUriCall['method'] === 'importUri'
        && Wire::decodeMap($importUriCall['payload']) == [
            'uri' => 'content://media/external/images/media/42',
        ],
    'Files importUri must emit a typed content URI import.',
);
Runtime::dispatchModuleResult(
    $importUriRequest,
    ModuleResultStatus::Success->value,
    Wire::map([
        'path' => 'imports/photo-42.jpg',
        'name' => 'photo-42.jpg',
        'mimeType' => 'image/jpeg',
        'size' => 4_096,
    ]),
);
$assert(
    $importedFile instanceof FileReference
        && $importedFile->path === 'imports/photo-42.jpg'
        && $importedFile->mimeType === 'image/jpeg'
        && $importedFile->size === 4_096,
    'Files importUri must decode the sandboxed file reference.',
);
$photoImport = Files::importUri('phasset://asset/QUJD', static function (FileReference $file): void {});
$photoImportCall = TestDiagnostics::$moduleCall;
$assert(
    $photoImportCall !== null
        && $photoImportCall['requestId'] === $photoImport
        && $photoImportCall['module'] === 'files'
        && $photoImportCall['method'] === 'importUri'
        && Wire::decodeMap($photoImportCall['payload']) === ['uri' => 'phasset://asset/QUJD'],
    'Files importUri must also forward iOS PhotoKit asset URIs.',
);
Runtime::dispatchModuleResult($photoImport, ModuleResultStatus::Success->value, Wire::map([
    'path' => 'imports/photo.jpg',
    'name' => 'photo.jpg',
    'mimeType' => 'image/jpeg',
    'size' => 1_024,
]));

$missingStoredValue = 'not-dispatched';
$storageRequest = Storage::get(
    'chat.draft.missing',
    static function (?string $value) use (&$missingStoredValue): void {
        $missingStoredValue = $value;
    },
);
Runtime::dispatchModuleResult(
    $storageRequest,
    ModuleResultStatus::Success->value,
    '',
);
$assert(
    $missingStoredValue === null,
    'Storage get must treat an empty successful payload as a cache miss.',
);

$batchRequestId = SQLite::executeMany(
    'nitro.db',
    'INSERT INTO messages (id, body) VALUES (?, ?)',
    [
        ['m1', 'fast'],
        ['m2', 'faster'],
    ],
);
$batchCall = TestDiagnostics::$moduleCall;
$batchPayload = $batchCall === null ? [] : Wire::decodeMap($batchCall['payload']);
$assert(
    $batchCall !== null
        && $batchCall['requestId'] === $batchRequestId
        && $batchCall['module'] === 'sqlite'
        && $batchCall['method'] === 'executeMany'
        && json_decode((string) ($batchPayload['arguments'] ?? ''), true) === [
            ['m1', 'fast'],
            ['m2', 'faster'],
        ],
    'SQLite executeMany did not emit one typed bridge call for the complete batch.',
);
Runtime::dispatchModuleResult(
    $batchRequestId,
    \Pam\Native\ModuleResultStatus::Success->value,
    '',
);

$transactionRequestId = SQLite::transaction(
    'nitro.db',
    [
        [
            'sql' => 'DELETE FROM messages WHERE chat_id = ?',
            'arguments' => ['chat-1'],
        ],
        [
            'sql' => 'INSERT INTO messages (id, chat_id, body) VALUES (?, ?, ?)',
            'argumentSets' => [
                ['m3', 'chat-1', 'atomic'],
                ['m4', 'chat-1', 'batched'],
            ],
        ],
    ],
);
$transactionCall = TestDiagnostics::$moduleCall;
$transactionPayload = $transactionCall === null
    ? []
    : Wire::decodeMap($transactionCall['payload']);
$assert(
    $transactionCall !== null
        && $transactionCall['requestId'] === $transactionRequestId
        && $transactionCall['module'] === 'sqlite'
        && $transactionCall['method'] === 'transaction'
        && json_decode((string) ($transactionPayload['arguments'] ?? ''), true) === [
            [
                'sql' => 'DELETE FROM messages WHERE chat_id = ?',
                'arguments' => ['chat-1'],
            ],
            [
                'sql' => 'INSERT INTO messages (id, chat_id, body) VALUES (?, ?, ?)',
                'arguments' => [],
                'argumentSets' => [
                    ['m3', 'chat-1', 'atomic'],
                    ['m4', 'chat-1', 'batched'],
                ],
            ],
        ],
    'SQLite transaction did not emit one typed bridge call for heterogeneous statements.',
);
Runtime::dispatchModuleResult(
    $transactionRequestId,
    \Pam\Native\ModuleResultStatus::Success->value,
    '',
);

$contacts = null;
$contactsRequestId = Contacts::all(static function (array $items) use (&$contacts): void {
    $contacts = $items;
});
$contactsCall = TestDiagnostics::$moduleCall;
$assert(
    $contactsCall !== null
        && $contactsCall['requestId'] === $contactsRequestId
        && $contactsCall['module'] === 'contacts'
        && $contactsCall['method'] === 'list'
        && Wire::decodeMap($contactsCall['payload']) == ['offset' => 0, 'limit' => 250],
    'Contacts facade did not request the first bounded native page.',
);
Runtime::dispatchModuleResult(
    $contactsRequestId,
    \Pam\Native\ModuleResultStatus::Success->value,
    Wire::map([
        'items' => json_encode([[
            'id' => '42',
            'displayName' => 'Ada Lovelace',
            'givenName' => 'Ada',
            'familyName' => 'Lovelace',
            'phoneNumbers' => ['+5511999999999'],
            'emailAddresses' => ['ada@example.test'],
        ]], JSON_THROW_ON_ERROR),
        'hasMore' => false,
    ]),
);

$mediaPage = null;
$mediaRequestId = MediaLibrary::assets(
    MediaPickerType::Media,
    static function (MediaAssetPage $page) use (&$mediaPage): void {
        $mediaPage = $page;
    },
    limit: 80,
    offset: 160,
    albumId: 'camera',
);
$mediaCall = TestDiagnostics::$moduleCall;
$assert(
    $mediaCall !== null
        && $mediaCall['requestId'] === $mediaRequestId
        && $mediaCall['module'] === 'media-library'
        && $mediaCall['method'] === 'assets'
        && Wire::decodeMap($mediaCall['payload']) == [
            'albumId' => 'camera',
            'limit' => 80,
            'offset' => 160,
            'type' => MediaPickerType::Media->value,
        ],
    'MediaLibrary assets must emit a bounded paginated native query.',
);
Runtime::dispatchModuleResult(
    $mediaRequestId,
    ModuleResultStatus::Success->value,
    Wire::map([
        'items' => json_encode([[
            'id' => '42',
            'uri' => 'content://media/external/images/media/42',
            'name' => 'photo-42.jpg',
            'mimeType' => 'image/jpeg',
            'width' => 1_080,
            'height' => 1_350,
            'durationMs' => 0,
            'size' => 4_096,
            'createdAt' => 1_785_000_000_000,
            'modifiedAt' => 1_785_000_100_000,
            'albumId' => 'camera',
            'albumTitle' => 'Câmera',
            'favorite' => true,
        ]], JSON_THROW_ON_ERROR),
        'hasMore' => true,
    ]),
);
$assert(
    $mediaPage instanceof MediaAssetPage
        && $mediaPage->hasMore
        && $mediaPage->nextOffset === 161
        && count($mediaPage->items) === 1
        && $mediaPage->items[0] instanceof MediaAsset
        && $mediaPage->items[0]->id === '42'
        && $mediaPage->items[0]->width === 1_080
        && $mediaPage->items[0]->favorite
        && !$mediaPage->items[0]->video(),
    'MediaLibrary assets must decode typed media metadata and pagination.',
);

$mediaAlbums = null;
$albumRequestId = MediaLibrary::albums(
    MediaPickerType::Image,
    static function (array $items) use (&$mediaAlbums): void {
        $mediaAlbums = $items;
    },
);
$albumCall = TestDiagnostics::$moduleCall;
$assert(
    $albumCall !== null
        && $albumCall['requestId'] === $albumRequestId
        && $albumCall['module'] === 'media-library'
        && $albumCall['method'] === 'albums'
        && Wire::decodeMap($albumCall['payload']) == [
            'type' => MediaPickerType::Image->value,
        ],
    'MediaLibrary albums must emit its typed media filter.',
);
Runtime::dispatchModuleResult(
    $albumRequestId,
    ModuleResultStatus::Success->value,
    Wire::map([
        'items' => json_encode([[
            'id' => 'camera',
            'title' => 'Câmera',
            'count' => 42,
            'coverUri' => 'content://media/external/images/media/42',
        ]], JSON_THROW_ON_ERROR),
    ]),
);
$assert(
    is_array($mediaAlbums)
        && count($mediaAlbums) === 1
        && $mediaAlbums[0] instanceof MediaAlbum
        && $mediaAlbums[0]->id === 'camera'
        && $mediaAlbums[0]->count === 42,
    'MediaLibrary albums must decode typed album metadata.',
);

$smsAvailable = null;
$smsAvailabilityRequest = Sms::isAvailable(
    static function (bool $available) use (&$smsAvailable): void {
        $smsAvailable = $available;
    },
);
$smsAvailabilityCall = TestDiagnostics::$moduleCall;
$assert(
    $smsAvailabilityCall !== null
        && $smsAvailabilityCall['requestId'] === $smsAvailabilityRequest
        && $smsAvailabilityCall['module'] === 'sms'
        && $smsAvailabilityCall['method'] === 'isAvailable',
    'SMS facade must query platform availability.',
);
Runtime::dispatchModuleResult(
    $smsAvailabilityRequest,
    ModuleResultStatus::Success->value,
    Wire::map(['available' => true]),
);
$assert($smsAvailable === true, 'SMS facade must decode platform availability.');

$smsOpened = false;
$smsComposeRequest = Sms::compose(
    [' +55 11 99999-0000 ', '+55 11 99999-0000'],
    'Convite do Zé Chat',
    static function () use (&$smsOpened): void {
        $smsOpened = true;
    },
);
$smsComposeCall = TestDiagnostics::$moduleCall;
$assert(
    $smsComposeCall !== null
        && $smsComposeCall['requestId'] === $smsComposeRequest
        && $smsComposeCall['module'] === 'sms'
        && $smsComposeCall['method'] === 'compose'
        && Wire::decodeMap($smsComposeCall['payload']) == [
            'recipients' => '+55 11 99999-0000',
            'body' => 'Convite do Zé Chat',
        ],
    'SMS facade must normalize recipients and encode the draft.',
);
Runtime::dispatchModuleResult(
    $smsComposeRequest,
    ModuleResultStatus::Success->value,
    '',
);
$assert($smsOpened, 'SMS facade must report a presented composer.');
$smsFailure = '';
$smsFailureRequest = Sms::compose(
    ['+5511999990000'],
    'Convite',
    failed: static function (string $message) use (&$smsFailure): void {
        $smsFailure = $message;
    },
);
Runtime::dispatchModuleResult(
    $smsFailureRequest,
    ModuleResultStatus::Failure->value,
    'SMS unavailable',
);
$assert(
    $smsFailure === 'SMS unavailable',
    'SMS facade must expose recoverable native failures to applications.',
);

$incomingShare = null;
$incomingShareRequestId = IncomingShares::initial(
    static function (?IncomingShare $share) use (&$incomingShare): void {
        $incomingShare = $share;
    },
);
$incomingShareCall = TestDiagnostics::$moduleCall;
$assert(
    $incomingShareCall !== null
        && $incomingShareCall['requestId'] === $incomingShareRequestId
        && $incomingShareCall['module'] === 'incoming-share'
        && $incomingShareCall['method'] === 'initial',
    'IncomingShares facade did not request the cold-start payload.',
);
Runtime::dispatchModuleResult(
    $incomingShareRequestId,
    \Pam\Native\ModuleResultStatus::Success->value,
    Wire::map([
        'available' => true,
        'text' => 'Shared caption',
        'subject' => 'Shared subject',
        'mimeType' => 'image/jpeg',
        'files' => json_encode([[
            'path' => '/data/user/0/app/cache/pam-incoming-shares/incoming-photo.jpg',
            'name' => 'photo.jpg',
            'mimeType' => 'image/jpeg',
            'size' => 1234,
        ]], JSON_THROW_ON_ERROR),
    ]),
);
$assert(
    $incomingShare instanceof IncomingShare
        && $incomingShare->text === 'Shared caption'
        && count($incomingShare->files) === 1
        && $incomingShare->files[0]->name === 'photo.jpg'
        && $incomingShare->files[0]->size === 1234,
    'IncomingShares facade did not decode the sandboxed file payload.',
);

$cacheUsage = null;
$cacheRequestId = Caches::usage(
    static function (\Pam\Native\CacheUsage $usage) use (&$cacheUsage): void {
        $cacheUsage = $usage;
    },
);
$cacheCall = TestDiagnostics::$moduleCall;
$assert(
    $cacheCall !== null
        && $cacheCall['requestId'] === $cacheRequestId
        && $cacheCall['module'] === 'cache'
        && $cacheCall['method'] === 'usage',
    'Caches facade did not request native cache usage.',
);
Runtime::dispatchModuleResult(
    $cacheRequestId,
    \Pam\Native\ModuleResultStatus::Success->value,
    Wire::map([
        'fileCount' => 12,
        'freedBytes' => 0,
        'imageBytes' => 1024,
        'mediaBytes' => 4096,
        'temporaryBytes' => 128,
        'totalBytes' => 5248,
    ]),
);
$assert(
    $cacheUsage instanceof \Pam\Native\CacheUsage
        && $cacheUsage->fileCount === 12
        && $cacheUsage->totalBytes === 5248,
    'Caches facade did not decode typed native cache usage.',
);

$cacheCleared = null;
$cacheClearRequestId = Caches::clear(
    static function (\Pam\Native\CacheUsage $usage) use (&$cacheCleared): void {
        $cacheCleared = $usage;
    },
);
$cacheClearCall = TestDiagnostics::$moduleCall;
$assert(
    $cacheClearCall !== null
        && $cacheClearCall['module'] === 'cache'
        && $cacheClearCall['method'] === 'clear'
        && Wire::decodeMap($cacheClearCall['payload']) == ['preserveOffline' => true],
    'Caches clear must preserve pinned offline media by default.',
);
Runtime::dispatchModuleResult(
    $cacheClearRequestId,
    \Pam\Native\ModuleResultStatus::Success->value,
    Wire::map([
        'fileCount' => 2,
        'freedBytes' => 4096,
        'imageBytes' => 0,
        'mediaBytes' => 1024,
        'temporaryBytes' => 0,
        'totalBytes' => 1024,
    ]),
);
$assert(
    $cacheCleared instanceof \Pam\Native\CacheUsage
        && $cacheCleared->freedBytes === 4096
        && $cacheCleared->totalBytes === 1024,
    'Caches clear did not decode the reclaimed byte count.',
);
$assert(
    is_array($contacts)
        && count($contacts) === 1
        && $contacts[0] instanceof Contact
        && $contacts[0]->displayName === 'Ada Lovelace'
        && $contacts[0]->phoneNumbers === ['+5511999999999'],
    'Contacts facade did not decode native contacts into typed values.',
);

$httpResponse = null;
$httpRequestId = Http::json(
    method: 'post',
    url: 'https://api.example.test/login',
    data: ['email' => 'person@example.test', 'password' => 'secret'],
    callback: static function (HttpResponse $response) use (&$httpResponse): void {
        $httpResponse = $response;
    },
    headers: ['Authorization' => 'Bearer access-token'],
    timeoutMs: 45_000,
);
$httpCall = TestDiagnostics::$moduleCall;
$httpPayload = Wire::decodeMap($httpCall['payload'] ?? '');
$httpHeaders = json_decode((string) ($httpPayload['headers'] ?? ''), true, flags: JSON_THROW_ON_ERROR);
$httpBody = json_decode((string) ($httpPayload['body'] ?? ''), true, flags: JSON_THROW_ON_ERROR);
$assert(
    $httpCall !== null
        && $httpCall['requestId'] === $httpRequestId
        && $httpCall['module'] === 'http'
        && $httpCall['method'] === 'request'
        && $httpPayload['url'] === 'https://api.example.test/login'
        && $httpPayload['method'] === 'POST'
        && $httpPayload['timeoutMs'] === 45_000
        && $httpHeaders === [
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer access-token',
        ]
        && $httpBody === ['email' => 'person@example.test', 'password' => 'secret'],
    'Generic HTTP JSON request did not preserve method, URL, headers, body and timeout.',
);
Runtime::dispatchModuleResult(
    $httpRequestId,
    \Pam\Native\ModuleResultStatus::Success->value,
    Wire::map(['statusCode' => 201, 'body' => '{"token":"access-token"}']),
);
$assert(
    $httpResponse instanceof HttpResponse
        && $httpResponse->statusCode === 201
        && $httpResponse->successful()
        && $httpResponse->body === '{"token":"access-token"}',
    'Generic HTTP request did not decode its response.',
);

$uploadResponse = null;
$uploadId = Http::upload('https://storage.example.test/signed', 'documents/test.png',
    static function (HttpResponse $response) use (&$uploadResponse): void { $uploadResponse = $response; },
    ['Content-Type' => 'image/png'],
);
$uploadCall = TestDiagnostics::$moduleCall;
$uploadPayload = Wire::decodeMap($uploadCall['payload'] ?? '');
$assert($uploadCall['method'] === 'upload' && $uploadPayload['method'] === 'PUT'
    && $uploadPayload['path'] === 'documents/test.png' && !array_key_exists('body', $uploadPayload)
    && $uploadPayload['timeoutMs'] === 120_000,
    'HTTP upload must send a private path instead of file bytes through PHP.');
Runtime::dispatchModuleResult($uploadId, \Pam\Native\ModuleResultStatus::Success->value,
    Wire::map(['statusCode' => 204, 'body' => '']));
$assert($uploadResponse instanceof HttpResponse && $uploadResponse->successful(), 'Upload response was not delivered.');
foreach (['', '/absolute', '../outside', 'a/../b', 'a//b', "a\\b", "a\0b"] as $path) {
    $rejected = false;
    try { Http::upload('https://storage.example.test/signed', $path, static function (HttpResponse $response): void {}); }
    catch (RuntimeException) { $rejected = true; }
    $assert($rejected, 'Invalid upload path reached the native module.');
}
foreach (['Host', 'Content-Length', 'Transfer-Encoding', 'Connection', 'Trailer', 'Upgrade'] as $header) {
    $rejected = false;
    try { Http::upload('https://storage.example.test/signed', 'document.png',
        static function (HttpResponse $response): void {}, [$header => 'invalid']); }
    catch (RuntimeException) { $rejected = true; }
    $assert($rejected, 'Upload allowed a transport-managed header.');
}

$traceparent = '00-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01';
$trace = new OutboundTraceContext($traceparent, 'https://api.example.test/');
Http::get('https://api.example.test/orders', static function (HttpResponse $response): void {}, $trace);
$tracedPayload = Wire::decodeMap(TestDiagnostics::$moduleCall['payload'] ?? '');
$assert(
    ($tracedPayload['traceparent'] ?? null) === $traceparent
        && ($tracedPayload['traceOrigin'] ?? null) === 'https://api.example.test',
    'HTTP trace propagation must use a dedicated origin-scoped payload.',
);

foreach (
    [
        static fn () => new OutboundTraceContext('forged', 'https://api.example.test'),
        static fn () => new OutboundTraceContext($traceparent, 'http://api.example.test'),
        static fn () => new OutboundTraceContext($traceparent, 'https://user@api.example.test'),
        static fn () => new OutboundTraceContext($traceparent, 'https://api.example.test/path'),
    ] as $invalidTraceContext
) {
    try {
        $invalidTraceContext();
        throw new RuntimeException('Invalid outbound trace context was accepted.');
    } catch (InvalidArgumentException $error) {
        $assert(
            $error->getMessage() !== 'Invalid outbound trace context was accepted.',
            'Outbound trace validation did not fail closed.',
        );
    }
}

foreach (
    [
        static fn () => Http::get(
            'https://attacker.example.test/orders',
            static function (HttpResponse $response): void {},
            $trace,
        ),
        static fn () => Http::request(
            'GET',
            'https://api.example.test/orders',
            static function (HttpResponse $response): void {},
            ['TraceParent' => $traceparent],
        ),
    ] as $unsafeTraceRequest
) {
    try {
        $unsafeTraceRequest();
        throw new RuntimeException('Unsafe HTTP trace propagation was accepted.');
    } catch (RuntimeException $error) {
        $assert(
            $error->getMessage() !== 'Unsafe HTTP trace propagation was accepted.',
            'HTTP trace context escaped its declared origin or generic-header boundary.',
        );
    }
}

$transportFailure = null;
$transportFailureId = Http::get(
    'https://offline.example.test',
    static function (HttpResponse $response) use (&$transportFailure): void {
        $transportFailure = $response;
    },
);
Runtime::dispatchModuleResult(
    $transportFailureId,
    \Pam\Native\ModuleResultStatus::Failure->value,
    'Unable to resolve host.',
);
$assert(
    $transportFailure instanceof HttpResponse
        && $transportFailure->statusCode === 0
        && $transportFailure->body === ''
        && $transportFailure->error === 'Unable to resolve host.'
        && $transportFailure->transportFailed()
        && !$transportFailure->successful(),
    'HTTP transport failures must reach the callback without crashing the runtime.',
);

foreach (['post' => 'POST', 'put' => 'PUT', 'patch' => 'PATCH', 'delete' => 'DELETE'] as $helper => $method) {
    Http::{$helper}(
        'https://api.example.test/resource',
        static function (HttpResponse $response): void {},
        ['Authorization' => 'Bearer access-token'],
        '{"enabled":true}',
    );
    $helperCall = TestDiagnostics::$moduleCall;
    $helperPayload = Wire::decodeMap($helperCall['payload'] ?? '');
    $assert(
        $helperCall !== null
            && $helperCall['method'] === 'request'
            && $helperPayload['method'] === $method
            && $helperPayload['body'] === '{"enabled":true}',
        "HTTP {$method} helper did not emit a generic native request.",
    );
}

$encoded = (new TreeEncoder())->encode($counter->render());
$eventKey = array_key_first($encoded['callbacks']);

if ($eventKey === null) {
    throw new RuntimeException('Counter callback is missing.');
}

[$nodeId, $eventKind] = array_map('intval', explode(':', $eventKey));
Runtime::dispatchEvent($nodeId, $eventKind, '');
$assert($counter->count === 1, 'Event did not update component state.');
$assert(Runtime::lastFrame() !== $frame, 'State update did not produce a new frame.');
Runtime::shutdown();

$lifecycleState = null;
$windowMetrics = null;
$memoryPressure = null;
App::onAppState(static function (AppState $state) use (&$lifecycleState): void {
    $lifecycleState = $state;
});
App::onDimensions(static function (WindowMetrics $metrics) use (&$windowMetrics): void {
    $windowMetrics = $metrics;
});
App::onMemoryPressure(static function (MemoryPressure $pressure) use (&$memoryPressure): void {
    $memoryPressure = $pressure;
});
App::run(Text::make('Lifecycle'));
Runtime::dispatchEvent(0, EventKind::AppState->value, (string) AppState::Background->value);
Runtime::dispatchEvent(0, EventKind::Dimensions->value, Wire::map([
    'width' => 412.0,
    'height' => 915.0,
    'density' => 3.0,
    'appearance' => UserInterfaceAppearance::Dark->value,
    'fontScale' => 1.15,
    'safeAreaTop' => 24.0,
    'safeAreaBottom' => 16.0,
    'refreshRate' => 120.0,
    'reducedMotion' => true,
    'deviceType' => 'tablet',
    'pointer' => 'fine',
    'inputMode' => 'mouse',
    'dynamicRange' => 'high',
    'memoryClass' => 512.0,
    'performanceTier' => 3.0,
]));
Runtime::dispatchEvent(
    0,
    EventKind::MemoryPressure->value,
    (string) MemoryPressure::Critical->value,
);
$assert($lifecycleState === AppState::Background, 'App-state lifecycle event was not decoded.');
$assert(
    $windowMetrics instanceof WindowMetrics
        && $windowMetrics->width === 412.0
        && $windowMetrics->height === 915.0
        && $windowMetrics->density === 3.0
        && $windowMetrics->appearance === UserInterfaceAppearance::Dark
        && $windowMetrics->fontScale === 1.15
        && $windowMetrics->safeAreaTop === 24.0
        && $windowMetrics->safeAreaBottom === 16.0
        && $windowMetrics->refreshRate === 120.0
        && $windowMetrics->reducedMotion
        && $windowMetrics->deviceType === 'tablet'
        && $windowMetrics->pointer === 'fine'
        && $windowMetrics->inputMode === 'mouse'
        && $windowMetrics->dynamicRange === 'high'
        && $windowMetrics->memoryClass === 512.0
        && $windowMetrics->performanceTier === 3.0,
    'Window metrics lifecycle event was not decoded.',
);
$assert(
    $memoryPressure === MemoryPressure::Critical,
    'Memory-pressure lifecycle event was not decoded.',
);
Runtime::shutdown();

$deviceInfo = new DeviceInfo(
    width: 412.0,
    height: 915.0,
    density: 3.0,
    appearance: UserInterfaceAppearance::Dark,
    appState: AppState::Active,
    safeAreaTop: 32.0,
    safeAreaRight: 0.0,
    safeAreaBottom: 24.0,
    safeAreaLeft: 0.0,
    timeZone: 'America/Sao_Paulo',
);
$assert(
    $deviceInfo->safeAreaTop === 32.0
        && $deviceInfo->safeAreaBottom === 24.0
        && $deviceInfo->timeZone === 'America/Sao_Paulo',
    'Device info must expose platform safe-area insets and the IANA time-zone identifier.',
);
$legacyDeviceInfo = new DeviceInfo(
    width: 360.0,
    height: 800.0,
    density: 2.0,
    appearance: UserInterfaceAppearance::Light,
    appState: AppState::Active,
);
$assert(
    $legacyDeviceInfo->safeAreaTop === 0.0
        && $legacyDeviceInfo->safeAreaRight === 0.0
        && $legacyDeviceInfo->safeAreaBottom === 0.0
        && $legacyDeviceInfo->safeAreaLeft === 0.0
        && $legacyDeviceInfo->timeZone === 'UTC',
    'Device info safe-area additions must preserve constructor compatibility.',
);

State::set('test.value', ['count' => 7]);
State::resetCache();
$assert(State::get('test.value') === ['count' => 7], 'Atomic state persistence failed.');

$restorable = new class extends Component implements Restorable {
    public int $count = 0;

    public function stateKey(): string
    {
        return 'tests.counter';
    }

    public function restoreState(array $state): void
    {
        $this->count = is_int($state['count'] ?? null) ? $state['count'] : 0;
    }

    public function saveState(): array
    {
        return ['count' => $this->count];
    }

    public function render(): \Pam\Native\Element
    {
        return Button::make((string) $this->count)
            ->key('restorable')
            ->onPress(function (): void {
                $this->count++;
            });
    }
};
App::run($restorable);
$restorableFrame = (new TreeEncoder())->encode($restorable->render());
$restorableEvent = array_key_first($restorableFrame['callbacks']);
if ($restorableEvent === null) {
    throw new RuntimeException('Restorable component callback is missing.');
}
[$restorableNode, $restorableKind] = array_map('intval', explode(':', $restorableEvent));
Runtime::dispatchEvent($restorableNode, $restorableKind, '');
$assert($restorable->count === 1, 'Restorable component did not update.');
Runtime::shutdown();
State::resetCache();

$restored = new class extends Component implements Restorable {
    public int $count = 0;

    public function stateKey(): string
    {
        return 'tests.counter';
    }

    public function restoreState(array $state): void
    {
        $this->count = is_int($state['count'] ?? null) ? $state['count'] : 0;
    }

    public function saveState(): array
    {
        return ['count' => $this->count];
    }

    public function render(): \Pam\Native\Element
    {
        return Text::make((string) $this->count);
    }
};
App::run($restored);
$assert($restored->count === 1, 'Component state was not restored after runtime restart.');
Runtime::shutdown();

$templateDirectory = sys_get_temp_dir().'/pam-native-template-tests';

if (!is_dir($templateDirectory) && !mkdir($templateDirectory, 0o755, true) && !is_dir($templateDirectory)) {
    throw new RuntimeException('Cannot create the template test directory.');
}

file_put_contents(
    $templateDirectory.'/counter.pam',
    <<<'PAM'
<Screen>
    <Column class="p-4 gap-2 bg-white">
        <Text key="greeting">Hello, {{ $name }}</Text>
        <Input model="name" placeholder="Name" sync="debounced" />
        <Button key="increment" on:press="increment">Count: {{ $count }}</Button>
        <If condition="$details">
            <Text key="details">Template details</Text>
        </If>
    </Column>
</Screen>
PAM,
);
file_put_contents(
    $templateDirectory.'/panel.pam',
    <<<'PAM'
<Column class="card gap-2">
    <Text key="panel-title">{{ $props.title }}</Text>
    <Slot>
        <Text>Fallback</Text>
    </Slot>
</Column>
PAM,
);
file_put_contents(
    $templateDirectory.'/slots.pam',
    <<<'PAM'
<Screen>
    <Panel title="Metrics">
        <Text key="slot-content">Fast native content</Text>
    </Panel>
</Screen>
PAM,
);
file_put_contents(
    $templateDirectory.'/override.pam',
    <<<'PAM'
<Button>
    <Text>Plugin child</Text>
</Button>
PAM,
);
App::views($templateDirectory, $templateDirectory.'/cache');
App::theme(Theme::pamLab());
App::component('Panel', 'panel');
$assert(
    TemplateRegistry::classProperties('card') !== null,
    'Theme class tokens were not registered.',
);
$assert(
    DesignTokens::TouchTarget === 48.0
        && DesignTokens::MotionFastMs >= 150
        && DesignTokens::MotionStandardMs <= 300,
    'Design tokens must preserve accessible touch targets and responsive motion.',
);
foreach (ThemeMode::cases() as $themeMode) {
    App::theme(Theme::adaptive($themeMode));
    $buttonTokens = TemplateRegistry::classProperties('button-primary');
    $surfaceTokens = TemplateRegistry::classProperties('surface');
    $surfaceMutedTokens = TemplateRegistry::classProperties('surface-muted');
    $metricTokens = TemplateRegistry::classProperties('metric');
    $focusTokens = TemplateRegistry::classProperties('focus-ring');
    $assert(
        ($buttonTokens[PropKey::MinHeight->value] ?? null) === DesignTokens::TouchTarget
            && isset($buttonTokens[PropKey::BackgroundColor->value])
            && isset($buttonTokens[PropKey::TextColor->value]),
        "Adaptive theme {$themeMode->name} must expose semantic accessible button tokens.",
    );
    $assert(
        Theme::contrastRatio(
            $metricTokens[PropKey::TextColor->value],
            $surfaceTokens[PropKey::BackgroundColor->value],
        ) >= 4.5
            && Theme::contrastRatio(
                $focusTokens[PropKey::BorderColor->value],
                $surfaceTokens[PropKey::BackgroundColor->value],
            ) >= 3.0
            && Theme::contrastRatio(
                $focusTokens[PropKey::BorderColor->value],
                $surfaceMutedTokens[PropKey::BackgroundColor->value],
            ) >= 3.0,
        "Adaptive theme {$themeMode->name} must preserve text and focus contrast.",
    );
}
$assert(
    Theme::contrastRatio(0xFF0F172A, 0xFFF8FAFC) >= 4.5
        && Theme::contrastRatio(0xFF4ADE80, 0xFF052E16) >= 4.5,
    'Theme contrast validation must enforce WCAG AA semantic pairs.',
);
$darkDefaults = Theme::pamLab()->applyTo(
    Screen::make(
        Text::make('Visible'),
        Button::make('Action'),
    ),
);
$defaultText = $darkDefaults->children()[0] ?? null;
$defaultButton = $darkDefaults->children()[1] ?? null;
$assert(
    isset($darkDefaults->properties()[PropKey::BackgroundColor->value])
        && $defaultText instanceof \Pam\Native\Element
        && isset($defaultText->properties()[PropKey::TextColor->value])
        && $defaultButton instanceof \Pam\Native\Element
        && isset($defaultButton->properties()[PropKey::BackgroundColor->value])
        && isset($defaultButton->properties()[PropKey::TextColor->value]),
    'Applied themes must give imperative trees visible semantic defaults.',
);
$authoredText = Theme::pamLab()->applyTo(
    Text::make('Brand')->style(new Style(textColor: 0xFFFF00FF)),
);
$assert(
    $authoredText->properties()[PropKey::TextColor->value] === 0xFFFF00FF,
    'Theme defaults must never replace authored imperative properties.',
);

$template = new class extends Component {
    private string $name = 'PHP';
    private int $count = 0;
    private bool $details = true;

    public function render(): View
    {
        return View::make('counter');
    }

    public function increment(): void
    {
        $this->count++;
    }

    public function count(): int
    {
        return $this->count;
    }

    /** @return array{name: string, details: bool} */
    public function templateState(): array
    {
        return ['name' => $this->name, 'details' => $this->details];
    }
};

App::run($template);
$templateRoot = $template->toElement();
$templateFrame = Runtime::lastFrame();
$templateEncoded = (new TreeEncoder())->encode($templateRoot);
$assert($templateFrame !== null, 'Tag template did not produce a native frame.');
$assert(count($templateEncoded['callbacks']) === 2, 'Template model and press callbacks are missing.');
$pressCallback = array_key_first(array_filter(
    $templateEncoded['callbacks'],
    static fn (string $key): bool => str_ends_with($key, ':1'),
    ARRAY_FILTER_USE_KEY,
));

if ($pressCallback === null) {
    throw new RuntimeException('Template press callback is missing.');
}

[$templateNode, $templateEvent] = array_map('intval', explode(':', $pressCallback));
Runtime::dispatchEvent($templateNode, $templateEvent, '');
$assert($template->count() === 1, 'Template event did not invoke its component method.');
$assert(
    $template->toElement() !== $templateRoot,
    'Template events must invalidate dependency-skipped component trees after direct state mutation.',
);
Runtime::shutdown();

$slotView = View::make('slots')->toElement();
$assert(
    $slotView->children() !== [],
    'Component props and slots did not render native children.',
);

TemplateRegistry::component(
    'Button',
    static fn (array $_props, array $children, ?object $_scope): Pressable => Pressable::make(...$children),
);
$overriddenButton = View::make('override')->toElement();
$assert(
    $overriddenButton->kind() === NodeKind::Pressable
        && count($overriddenButton->children()) === 1,
    'Plugin tags must be able to override core tags and receive element children.',
);

$failing = new class extends Component {
    public function render(): \Pam\Native\Element
    {
        return Button::make('Fail')->onPress(static function (): void {
            throw new RuntimeException('Expected recoverable PHP error.');
        });
    }
};
App::run($failing);
$failingFrame = (new TreeEncoder())->encode($failing->render());
$failingEvent = array_key_first($failingFrame['callbacks']);
if ($failingEvent === null) {
    throw new RuntimeException('Failing callback is missing.');
}
[$failingNode, $failingKind] = array_map('intval', explode(':', $failingEvent));
Runtime::dispatchEvent($failingNode, $failingKind, '');
$assert(
    isset(TestDiagnostics::$messages[0])
        && str_starts_with(TestDiagnostics::$messages[0], "PAMERR1\n")
        && str_contains(TestDiagnostics::$messages[0], 'Expected recoverable PHP error.'),
    'Recoverable PHP errors must emit structured diagnostics.',
);
$assert(Runtime::lastFrame() !== null, 'A PHP callback error stopped the runtime.');
Runtime::shutdown();

$pluginProject = sys_get_temp_dir().'/pam-native-plugin-tests-'.getmypid();
$pluginPackage = $pluginProject.'/vendor/community/fixture';

if (
    !is_dir($pluginPackage)
    && !mkdir($pluginPackage, 0o755, true)
    && !is_dir($pluginPackage)
) {
    throw new RuntimeException('Cannot create the plugin fixture package.');
}
if (
    !is_dir($pluginProject.'/vendor/composer')
    && !mkdir($pluginProject.'/vendor/composer', 0o755, true)
    && !is_dir($pluginProject.'/vendor/composer')
) {
    throw new RuntimeException('Cannot create the Composer fixture directory.');
}

file_put_contents(
    $pluginProject.'/vendor/composer/installed.json',
    <<<'JSON'
{
    "packages": [
        {
            "name": "community/fixture",
            "version": "1.0.0",
            "install-path": "../community/fixture",
            "extra": {
                "pam-native": {
                    "plugin": "pam-native.plugin.json"
                }
            }
        }
    ]
}
JSON,
);
file_put_contents(
    $pluginPackage.'/pam-native.plugin.json',
    <<<'JSON'
{
    "version": 1,
    "protocol": 1,
    "pamNative": {
        "minimum": "1.0.0",
        "maximumExclusive": "2.0.0"
    },
    "php": {
        "provider": "Pam\\Native\\Tests\\Fixtures\\ExamplePluginProvider"
    }
}
JSON,
);

PluginManager::reset();
PluginManager::boot($pluginProject);
$assert(
    ExamplePluginProvider::$registered === 1
        && ExamplePluginProvider::$booted === 1
        && TemplateRegistry::factory('FixtureTag') !== null,
    'Composer plugin provider was not registered and booted exactly once.',
);
PluginManager::boot($pluginProject);
$assert(
    ExamplePluginProvider::$registered === 1 && ExamplePluginProvider::$booted === 1,
    'Plugin providers must be idempotent within a runtime.',
);
PluginManager::reset();
file_put_contents(
    $pluginProject.'/vendor/composer/installed.json',
    <<<'JSON'
{
    "packages": [
        {
            "name": "community/fixture",
            "version": "1.0.0",
            "install-path": "../community/fixture",
            "extra": {
                "pam-native": {
                    "plugin": "../outside.json"
                }
            }
        }
    ]
}
JSON,
);
$unsafeDescriptorRejected = false;

try {
    PluginManager::discover($pluginProject);
} catch (PluginException) {
    $unsafeDescriptorRejected = true;
}

$assert($unsafeDescriptorRejected, 'Plugin descriptor traversal must be rejected.');

$pamPhpDirectory = sys_get_temp_dir().'/pam-native-sfc-tests-'.getmypid();
$pamPhpCache = $pamPhpDirectory.'/.cache';

if (
    !is_dir($pamPhpDirectory)
    && !mkdir($pamPhpDirectory, 0o755, true)
    && !is_dir($pamPhpDirectory)
) {
    throw new RuntimeException('Cannot create the .pam.php fixture directory.');
}

file_put_contents(
    $pamPhpDirectory.'/CounterCard.pam.php',
    <<<'PAM'
<?php

declare(strict_types=1);

namespace Pam\Native\Tests\Sfc;

use Pam\Native\Attributes\State;
use Pam\Native\Component;

final class CounterCard extends Component
{
    /** @var list<string> */
    public static array $lifecycle = [];

    /** @var list<string> */
    public static array $changedDrafts = [];

    #[State]
    public int $count = 0;

    #[State]
    public bool $enabled = false;
    public string $draft = '';

    /** @var list<string> */
    public array $items = ['One', 'Two'];

    public int $repeatCount = 3;

    public function __construct(
        public string $title,
        public ?string $subtitle = null,
        public bool $elevated = false,
    ) {
    }

    public function boot(): void
    {
        self::$lifecycle[] = 'boot';
    }

    public function mount(): void
    {
        self::$lifecycle[] = 'mount';
    }

    public function attached(): void
    {
        self::$lifecycle[] = 'attached';
    }

    public function resumed(): void
    {
        self::$lifecycle[] = 'resumed';
    }

    public function updated(string $property): void
    {
        self::$lifecycle[] = 'updated:'.$property;
    }

    public function paused(): void
    {
        self::$lifecycle[] = 'paused';
    }

    public function inactive(): void
    {
        self::$lifecycle[] = 'inactive';
    }

    public function activated(): void
    {
        self::$lifecycle[] = 'activated';
    }

    public function unmount(): void
    {
        self::$lifecycle[] = 'unmount';
    }

    public function increment(): void
    {
        $this->count++;
        $this->emit('changed', $this->count);
    }

    public function draftChanged(string $value): void
    {
        self::$changedDrafts[] = $this->draft.'|'.$value;
    }

    /** @return array<array-key, string|bool> */
    public function cardClasses(): array
    {
        return [
            'p-4',
            'gap-2',
            'elevation-2' => $this->elevated,
        ];
    }
}
?>

<template>
    <Column :class="cardClasses()">
        <Text
            :class="$elevated ? 'profile-title' : ''"
            fontSize="16"
        >{{ $title }}</Text>
        <Text p-if="$subtitle">{{ $subtitle }}</Text>
        <Text p-for="$item in $items">{{ $item }}</Text>
        <Text p-for="$number in $repeatCount">Repeat {{ $number }}</Text>
        <Text p-for="$_ in 0">Never rendered</Text>
        <Button @press="increment">
            {{ $count === 0 ? 'Ready' : $count }}
        </Button>
        <Switch bind:checked="$enabled" />
        <Input bind:value="$draft" on:change="draftChanged" />
        <Slot name="action">
            <Text>Fallback action</Text>
        </Slot>
        <Slot />
    </Column>
</template>

<style scoped>
    @font-face {
        font-family: "Brand";
        src: url("asset://assets/fonts/Brand-Bold.ttf");
        font-weight: 700;
    }

    Text {
        color: #222222;
        font-size: 13px;
    }

    .profile-title {
        color: #1B7A4E;
        font-family: "Brand";
        font-size: 15px;
        font-weight: 700;
        line-height: 18px;
    }
</style>
PAM,
);
file_put_contents(
    $pamPhpDirectory.'/Dashboard.pam.php',
    <<<'PAM'
<?php

declare(strict_types=1);

namespace Pam\Native\Tests\Sfc;

use Pam\Native\Component;

final class Dashboard extends Component
{
    public string $title = 'PAM Native';
    public int $changes = 0;

    public function changed(int $count): void
    {
        $this->changes = $count;
        $this->title = 'Changed';
    }

}
?>

<template>
    <CounterCard
        :title="$title"
        subtitle="Compiled .pam.php"
        :elevated="true"
        @changed="changed"
    >
        <template #action>
            <Text>Named action</Text>
        </template>

        <Text>Default slot</Text>
    </CounterCard>
</template>
PAM,
);
file_put_contents(
    $pamPhpDirectory.'/ConditionalRoot.pam.php',
    <<<'PAM'
<?php

declare(strict_types=1);

namespace Pam\Native\Tests\Sfc;

use Pam\Native\Component;

final class ConditionalRoot extends Component
{
    public bool $visible = false;
}
?>

<template>
    <View p-if="$visible">
        <Text>Visible</Text>
    </View>
</template>
PAM,
);
file_put_contents(
    $pamPhpDirectory.'/InheritedText.pam.php',
    <<<'PAM'
<?php

declare(strict_types=1);

namespace Pam\Native\Tests\Sfc;

use Pam\Native\Component;

final class InheritedText extends Component
{
}
?>

<template>
    <Text>Inherited component text</Text>
</template>
PAM,
);
file_put_contents(
    $pamPhpDirectory.'/InheritedStyleHost.pam.php',
    <<<'PAM'
<?php

declare(strict_types=1);

namespace Pam\Native\Tests\Sfc;

use Pam\Native\Component;

final class InheritedStyleHost extends Component
{
}
?>

<template>
    <Column textColor="#123456" fontSize="17">
        <InheritedText />
    </Column>
</template>
PAM,
);

$invalidPamPhpDirectory = $pamPhpDirectory.'-invalid';
if (
    !is_dir($invalidPamPhpDirectory)
    && !mkdir($invalidPamPhpDirectory, 0o755, true)
    && !is_dir($invalidPamPhpDirectory)
) {
    throw new RuntimeException('Cannot create the invalid component fixture directory.');
}
file_put_contents(
    $invalidPamPhpDirectory.'/Invalid.pam.php',
    <<<'PAM'
<?php

declare(strict_types=1);

namespace Pam\Native\Tests\Sfc;

use Pam\Native\Component;

final class Invalid extends Component
{
}
?>

<template>
    <Text invalid="unterminated></Text>
</template>
PAM,
);
TestDiagnostics::$messages = [];
$prebootError = null;
try {
    App::components($invalidPamPhpDirectory, $invalidPamPhpDirectory.'/.cache');
} catch (RuntimeException $error) {
    $prebootError = $error;
}
$assert(
    $prebootError instanceof RuntimeException
        && isset(TestDiagnostics::$messages[0])
        && str_starts_with(TestDiagnostics::$messages[0], "PAMERR1\n")
        && str_contains(TestDiagnostics::$messages[0], 'Invalid attributes'),
    'Component compilation errors before runtime boot must emit structured diagnostics.',
);
unlink($invalidPamPhpDirectory.'/Invalid.pam.php');
rmdir($invalidPamPhpDirectory.'/.cache');
rmdir($invalidPamPhpDirectory);
TestDiagnostics::$messages = [];

$assert(
    \Pam\Native\Internal\TemplateExpression::evaluate(
        '$left && $right',
        null,
        ['left' => false, 'right' => true],
    ) === false,
    'Template logical AND must consume its right operand when the left operand is false.',
);
$assert(
    TemplateExpression::evaluate(
        'TypedRouteTestName::Home->value',
        new TemplateEnumScope(),
        [],
    ) === 'home',
    'Template expressions must resolve scoped PHP enum cases and their backed values.',
);
$assert(
    TemplateExpression::evaluate(
        'ImportedState::Ready->value',
        new \Pam\Native\Tests\Fixtures\Screen\TemplateEnumScope(),
        [],
    ) === 1,
    'Template expressions must resolve imported and aliased PHP enum cases from the component file.',
);
$assert(
    \Pam\Native\Internal\TemplateExpression::evaluate(
        '$left || $right',
        null,
        ['left' => true, 'right' => false],
    ) === true,
    'Template logical OR must consume its right operand when the left operand is true.',
);
$assert(
    \Pam\Native\Internal\TemplateExpression::evaluate(
        'count($selected)',
        null,
        ['selected' => ['message-1', 'message-2']],
    ) === 2,
    'Template expressions must expose the safe count() collection helper.',
);
$assert(
    \Pam\Native\Internal\TemplateExpression::evaluate(
        'in_array($messageId, $selected, true)',
        null,
        [
            'messageId' => 'message-2',
            'selected' => ['message-1', 'message-2'],
        ],
    ) === true,
    'Template expressions must expose strict in_array() membership checks.',
);
$assert(
    \Pam\Native\Internal\TemplateExpression::evaluate(
        'mb_strlen(trim($query)) < 2',
        null,
        ['query' => ' á '],
    ) === true,
    'Template expressions must compose safe whitespace and multibyte string helpers.',
);
$assert(
    \Pam\Native\Internal\TemplateExpression::evaluate(
        'mb_strtoupper(mb_substr($author, 0, 1))',
        null,
        ['author' => 'élida'],
    ) === 'É',
    'Template expressions must expose safe multibyte substring and casing helpers.',
);
$assert(
    \Pam\Native\Internal\TemplateExpression::evaluate(
        'strtoupper(substr(trim($label), 0, 3))',
        null,
        ['label' => ' pam native '],
    ) === 'PAM',
    'Template expressions must expose safe byte-string helpers without eval.',
);
$unsafeTemplateFunctionRejected = false;
try {
    \Pam\Native\Internal\TemplateExpression::evaluate(
        'file_get_contents($path)',
        null,
        ['path' => '/etc/passwd'],
    );
} catch (RuntimeException $error) {
    $unsafeTemplateFunctionRejected = str_contains(
        $error->getMessage(),
        'does not exist',
    );
}
$assert(
    $unsafeTemplateFunctionRejected,
    'Template expressions must reject functions outside the explicit pure helper allowlist.',
);
$assert(
    \Pam\Native\Internal\TemplateExpression::evaluate(
        '72 + $bottomSpacing * 2',
        null,
        ['bottomSpacing' => 12],
    ) === 96,
    'Template arithmetic must preserve multiplication precedence over addition.',
);
$assert(
    \Pam\Native\Internal\TemplateExpression::evaluate(
        '($mediaIndex + 1) % 3',
        null,
        ['mediaIndex' => 2],
    ) === 0,
    'Template arithmetic must support grouping and integer modulo.',
);
$assert(
    \Pam\Native\Internal\TemplateExpression::evaluate(
        "'@'.\$username.' · '.(\$count + 1)",
        null,
        ['username' => 'pam', 'count' => 2],
    ) === '@pam · 3',
    'Template expressions must support PHP string concatenation with arithmetic precedence.',
);
$assert(
    \Pam\Native\Internal\TemplateExpression::evaluate(
        '$props.title',
        null,
        ['props' => ['title' => 'Profile']],
    ) === 'Profile',
    'Template dot-property paths must remain distinct from string concatenation.',
);
$assert(
    \Pam\Native\Internal\TemplateExpression::evaluate(
        '$profile["bio"] ?? $fallback ?? "Sem bio"',
        null,
        ['profile' => [], 'fallback' => null],
    ) === 'Sem bio',
    'Template null coalescing must be right associative and tolerate a missing array key.',
);
$assert(
    \Pam\Native\Internal\TemplateExpression::evaluate(
        '$profile["details"]["website"] ?? "Sem site"',
        null,
        ['profile' => []],
    ) === 'Sem site',
    'Template null coalescing must safely traverse a missing nested path.',
);
$assert(
    \Pam\Native\Internal\TemplateExpression::evaluate(
        '$profile["bio"] ?? "Sem bio"',
        null,
        ['profile' => ['bio' => 'PAM']],
    ) === 'PAM',
    'Template null coalescing must preserve a present non-null value.',
);
$missingWithoutCoalescingRejected = false;
try {
    \Pam\Native\Internal\TemplateExpression::evaluate(
        '$profile["bio"]',
        null,
        ['profile' => []],
    );
} catch (RuntimeException $error) {
    $missingWithoutCoalescingRejected = str_contains(
        $error->getMessage(),
        'Cannot resolve template value',
    );
}
$assert(
    $missingWithoutCoalescingRejected,
    'Missing template values must remain strict outside null coalescing.',
);
$concatenationRejected = false;
try {
    \Pam\Native\Internal\TemplateExpression::evaluate(
        "'items: '.\$items",
        null,
        ['items' => ['one']],
    );
} catch (RuntimeException $error) {
    $concatenationRejected = str_contains(
        $error->getMessage(),
        'requires scalar, null, or Stringable operands',
    );
}
$assert(
    $concatenationRejected,
    'Template concatenation must reject arrays instead of coercing them with a warning.',
);

TemplateRegistry::reset();
$preloadResult = PamPhpPreloader::optimize($pamPhpDirectory, $pamPhpCache);
$preloadManifest = json_decode(
    (string) file_get_contents($preloadResult['manifest']),
    true,
    flags: JSON_THROW_ON_ERROR,
);
$preloadComponents = $preloadManifest['components'] ?? [];
$assert(
    $preloadResult['components'] === count($preloadComponents)
        && $preloadResult['components'] >= 5
        && is_file($preloadResult['preload'])
        && array_reduce(
            $preloadComponents,
            static fn (bool $valid, mixed $entry): bool => $valid
                && is_array($entry)
                && isset($entry['sha256'])
                && is_string($entry['sha256'])
                && strlen($entry['sha256']) === 64,
            true,
        ),
    'PHP Runtime Turbo must emit a complete deterministic preload manifest.',
);
$freezeResult = PamPhpPreloader::optimize(
    $pamPhpDirectory,
    $pamPhpCache.'-freeze',
    ['Dashboard'],
);
$freezeManifest = json_decode(
    (string) file_get_contents($freezeResult['freeze']),
    true,
    flags: JSON_THROW_ON_ERROR,
);
$freezePreload = json_decode(
    (string) file_get_contents($freezeResult['manifest']),
    true,
    flags: JSON_THROW_ON_ERROR,
);
$freezeTags = array_column($freezePreload['components'] ?? [], 'tag');
$assert(
    $freezeResult['discovered'] === $preloadResult['components']
        && $freezeResult['components'] === 2
        && $freezeResult['eliminated'] === $freezeResult['discovered'] - 2
        && $freezeTags === ['CounterCard', 'Dashboard']
        && $freezeManifest['abiVersion'] === \Pam\Native\Protocol::ABI_VERSION
        && $freezeManifest['protocolVersion'] === \Pam\Native\Protocol::VERSION
        && $freezeManifest['entrypoints'] === ['Dashboard']
        && $freezeManifest['buildId'] === $freezeResult['buildId']
        && str_contains((string) file_get_contents($freezeResult['preload']), 'hash_equals'),
    'PAM Freeze must tree-shake unreachable components and pin a deterministic ABI build manifest.',
);
require $preloadResult['preload'];
$assert(
    PamPhpRegistry::preloadMetadata([
        'Pam\\Native\\Tests\\Sfc\\CounterCard',
    ]) === 1,
    'PHP Runtime Turbo must warm generated constructor and prop metadata.',
);
App::components($pamPhpDirectory, $pamPhpCache);
$dashboardClass = 'Pam\\Native\\Tests\\Sfc\\Dashboard';
$counterClass = 'Pam\\Native\\Tests\\Sfc\\CounterCard';
$conditionalRoot = App::make('Pam\\Native\\Tests\\Sfc\\ConditionalRoot')->toElement();
$inheritedStyleHost = App::make(
    'Pam\\Native\\Tests\\Sfc\\InheritedStyleHost',
)->toElement();
$inheritedText = $inheritedStyleHost->children()[0] ?? null;
$assert(
    $inheritedText instanceof \Pam\Native\Element
        && $inheritedText->properties()[PropKey::TextColor->value] === 0xFF123456
        && (float) $inheritedText->properties()[PropKey::FontSize->value] === 17.0,
    'Inherited CSS must remain active inside a compiled child component.',
);
$assert(
    $conditionalRoot->properties()[PropKey::Visible->value] === false
        && $conditionalRoot->children() === [],
    'A false conditional root must render an inert zero-layout placeholder.',
);
$dashboard = App::make($dashboardClass);
App::run($dashboard);
$sfcElement = $dashboard->toElement();
$sfcEncoded = (new TreeEncoder())->encode($sfcElement);
$pressKey = null;
$toggleKey = null;
$inputKey = null;

foreach (array_keys($sfcEncoded['callbacks']) as $callbackKey) {
    [, $kind] = array_map('intval', explode(':', $callbackKey));
    if ($kind === EventKind::Press->value) {
        $pressKey = $callbackKey;
    } elseif ($kind === EventKind::Toggle->value) {
        $toggleKey = $callbackKey;
    } elseif ($kind === EventKind::Change->value) {
        $inputKey = $callbackKey;
    }
}

$assert($pressKey !== null, '.pam.php @press event was not compiled.');
$assert($toggleKey !== null, '.pam.php bind:checked event was not compiled.');
$assert($inputKey !== null, '.pam.php bind:value event was not compiled.');
$assert(
    count($sfcElement->children()) === 12,
    '.pam.php p-if, iterable/integer p-for and slots did not compose correctly.',
);
$assert(
    $sfcElement->children()[0]->properties()[PropKey::FontFamily->value]
        === 'asset://assets/fonts/Brand-Bold.ttf'
        && (float) $sfcElement->children()[0]
            ->properties()[PropKey::FontSize->value] === 16.0
        && (float) $sfcElement->children()[0]
            ->properties()[PropKey::LineHeight->value] === 18.0
        && $sfcElement->children()[0]->properties()[PropKey::TextColor->value]
            === 0xFF1B7A4E,
    '.pam.php scoped CSS must cascade tag, dynamic class and inline properties.',
);
$assert(
    array_map(
        static fn (\Pam\Native\Element $element): mixed =>
            $element->properties()[PropKey::Text->value] ?? null,
        array_slice($sfcElement->children(), 4, 3),
    ) === ['Repeat 1', 'Repeat 2', 'Repeat 3'],
    '.pam.php integer p-for must expose a one-based loop value.',
);
$assert(
    $counterClass::$lifecycle === ['boot', 'mount', 'attached', 'resumed'],
    '.pam.php component lifecycle did not mount on the committed render.',
);
// Transient system UI (permission prompt, picker, share sheet) reports Inactive:
// the component stays resumed and only observes inactive()/activated().
Runtime::dispatchEvent(0, EventKind::AppState->value, (string) AppState::Inactive->value);
Runtime::dispatchEvent(0, EventKind::AppState->value, (string) AppState::Inactive->value);
Runtime::dispatchEvent(0, EventKind::AppState->value, (string) AppState::Active->value);
$assert(
    array_slice($counterClass::$lifecycle, -3) === ['resumed', 'inactive', 'activated'],
    'Inactive app state must not pause a component; it must bracket the interruption with inactive()/activated().',
);
// Leaving the foreground pauses once, whether or not Inactive was reported first.
Runtime::dispatchEvent(0, EventKind::AppState->value, (string) AppState::Inactive->value);
Runtime::dispatchEvent(0, EventKind::AppState->value, (string) AppState::Background->value);
Runtime::dispatchEvent(0, EventKind::AppState->value, (string) AppState::Active->value);
$assert(
    array_slice($counterClass::$lifecycle, -3) === ['inactive', 'paused', 'resumed'],
    'Background app state must pause the component exactly once and Active must resume it.',
);
Runtime::dispatchEvent(0, EventKind::AppState->value, (string) AppState::Background->value);
Runtime::dispatchEvent(0, EventKind::AppState->value, (string) AppState::Inactive->value);
$assert(
    array_slice($counterClass::$lifecycle, -2) === ['paused', 'resumed'],
    'Returning from Background through Inactive (iOS foreground transition) must resume the component.',
);
Runtime::dispatchEvent(0, EventKind::AppState->value, (string) AppState::Active->value);
$assert(
    end($counterClass::$lifecycle) === 'resumed',
    'Active after a Background→Inactive resume must not report a spurious activated() hook.',
);

if ($pressKey === null) {
    throw new RuntimeException('.pam.php press callback is missing.');
}
[$pressNode, $pressKind] = array_map('intval', explode(':', $pressKey));
Runtime::dispatchEvent($pressNode, $pressKind, '');
$afterPress = $dashboard->toElement();
$assert(
    $afterPress->children()[0]->properties()[PropKey::Text->value] === 'Changed',
    'Component emit() did not reach the parent @event handler.',
);
$assert(
    in_array('updated:title', $counterClass::$lifecycle, true),
    'Constructor prop changes must update a stable nested component.',
);

$rerendered = $dashboard->toElement();
$rerenderedEncoded = (new TreeEncoder())->encode($rerendered);
$newToggleKey = null;
foreach (array_keys($rerenderedEncoded['callbacks']) as $callbackKey) {
    [, $kind] = array_map('intval', explode(':', $callbackKey));
    if ($kind === EventKind::Toggle->value) {
        $newToggleKey = $callbackKey;
        break;
    }
}
if ($newToggleKey === null) {
    throw new RuntimeException('Rerendered .pam.php toggle callback is missing.');
}
[$toggleNode, $toggleKind] = array_map('intval', explode(':', $newToggleKey));
Runtime::dispatchEvent($toggleNode, $toggleKind, '1');
$assert(
    $dashboard->toElement()->children()[8]
        ->properties()[PropKey::Checked->value] === true,
    'bind:checked must update component state and rerender the native toggle.',
);
$assert(
    in_array('updated:enabled', $counterClass::$lifecycle, true),
    'bind:checked must invoke the component updated lifecycle hook.',
);

if ($inputKey === null) {
    throw new RuntimeException('.pam.php input callback is missing.');
}
[$inputNode, $inputKind] = array_map('intval', explode(':', $inputKey));
Runtime::dispatchEvent($inputNode, $inputKind, 'Offline draft');
$afterInput = $dashboard->toElement();
$assert(
    $afterInput->children()[9]->properties()[PropKey::Value->value] === 'Offline draft',
    'bind:value must update component state and rerender the native input.',
);
$assert(
    in_array('updated:draft', $counterClass::$lifecycle, true),
    'bind:value must invoke the component updated lifecycle hook.',
);
$assert(
    $counterClass::$changedDrafts === ['Offline draft|Offline draft'],
    'bind:value must update state before composing the explicit change handler.',
);

Runtime::shutdown();
$assert(
    array_slice($counterClass::$lifecycle, -2) === ['paused', 'unmount'],
    '.pam.php component lifecycle did not clean up on runtime shutdown.',
);

$globalCallRejected = false;
try {
    TemplateRenderer::render(
        TemplateCompiler::compile('<Text>{{ system(\'id\') }}</Text>'),
        new class {
        },
        [],
    );
} catch (RuntimeException) {
    $globalCallRejected = true;
}
$assert(
    $globalCallRejected,
    '.pam.php expressions must never call global PHP functions.',
);

$navigator = new Navigator(
    initialRoute: TypedRouteTestName::Home,
    routes: [
        'home' => static fn () => Screen::make(Text::make('Home')),
        'product' => static fn () => Screen::make(Text::make('Product')),
    ],
    transition: NavigationTransition::Fade,
    transitionDurationMs: 300,
);
$assert($navigator->render()->toElement()->kind() === NodeKind::NavigationHost, 'Navigator must render a native host.');
$navigator->push(TypedRouteTestName::Product);
$pushed = $navigator->render()->toElement();
$assert(count($pushed->children()) === 2, 'Push must retain both screens for the native transition.');
$assert(
    $pushed->properties()[PropKey::NavigationOperation->value] === NavigationOperation::Push->value,
    'Push operation was not sent to the native host.',
);
$assert($navigator->pop(), 'Navigator must pop a secondary route.');
$popped = $navigator->render()->toElement();
$assert(count($popped->children()) === 2, 'Pop must retain its outgoing screen until native animation completes.');
$assert($navigator->currentRoute() === 'home', 'Pop must reveal the previous route.');
$transitionEnd = $popped->events()[EventKind::AnimationComplete->value] ?? null;
$assert($transitionEnd instanceof Closure, 'Navigator must expose native transition completion.');
$transitionEnd('');
$settledPop = $navigator->render()->toElement();
$assert(
    count($settledPop->children()) === 1,
    'Settled pop must release its outgoing route.',
);
$assert(
    $settledPop->properties()[PropKey::NavigationOperation->value] === NavigationOperation::Idle->value,
    'Settled pop must restore the native host operation to idle.',
);
$navigator->preload(TypedRouteTestName::Product);
$navigator->navigate(TypedRouteTestName::Product, ['id' => 7]);
$assert($navigator->currentRoute() === 'product', 'Navigator::navigate must accept string-backed route enums.');
$navigator->replace(TypedRouteTestName::Home);
$assert($navigator->currentRoute() === 'home', 'Navigator::replace must accept string-backed route enums.');
$navigator->reset(TypedRouteTestName::Product);
$assert($navigator->currentRoute() === 'product', 'Navigator::reset must accept string-backed route enums.');
$assert(
    NavigationAction::push(TypedRouteTestName::Home)->route === 'home'
        && NavigationAction::navigate(TypedRouteTestName::Product)->route === 'product'
        && NavigationAction::replace(TypedRouteTestName::Home)->route === 'home'
        && NavigationAction::reset(TypedRouteTestName::Product)->route === 'product'
        && NavigationAction::preload(TypedRouteTestName::Home)->route === 'home',
    'Imperative navigation actions must normalize string-backed route enums.',
);
$navigator->navigate(TypedRouteTestName::Home);
$navigator->push(TypedRouteTestName::Product);
$assert($navigator->popTo(TypedRouteTestName::Home), 'Navigator::popTo must accept string-backed route enums.');
$navigator->navigate(
    TypedRouteTestName::Product,
    transition: NavigationTransition::None,
    durationMs: 0,
);
$instantNavigation = $navigator->render()->toElement();
$assert(
    $instantNavigation->properties()[PropKey::NavigationTransition->value] === NavigationTransition::None->value
        && $instantNavigation->properties()[PropKey::NavigationDurationMs->value] === 0,
    'Navigator actions must override route transitions without mutating route configuration.',
);
$instantTransitionEnd = $instantNavigation->events()[EventKind::AnimationComplete->value] ?? null;
$assert($instantTransitionEnd instanceof Closure, 'Instant navigation must still settle its native operation.');
$instantTransitionEnd('');
$assert(
    $navigator->render()->toElement()->properties()[PropKey::NavigationTransition->value]
        === NavigationTransition::Fade->value,
    'Action transition overrides must clear after the navigation settles.',
);
$systemBackConsumed = false;
$navigator->interceptSystemBack(static function () use (&$systemBackConsumed): bool {
    $systemBackConsumed = true;

    return true;
});
$assert(
    $navigator->consumeSystemBack() && $systemBackConsumed,
    'Navigator system Back interceptor must consume transient UI before changing routes.',
);
$navigator->interceptSystemBack(static fn (): bool => false);
$assert(
    !$navigator->consumeSystemBack(),
    'Navigator system Back interceptor must allow route navigation when it returns false.',
);
$navigator->interceptSystemBack(null);
$assert(
    !$navigator->consumeSystemBack(),
    'Navigator system Back interceptor must be removable.',
);
$fluentNavigator = Router::stack('home')
    ->route('home', static fn () => Screen::make(Text::make('Home')))
    ->transitions(NavigationTransition::Scale, 180)
    ->build();
$assert($fluentNavigator->currentRoute() === 'home', 'Fluent Router must build its initial stack.');
$generatedRoutes = RouteCodeGenerator::generate([
    'namespace' => 'App\\Navigation\\Generated',
    'enum' => 'AppRoute',
    'helper' => 'Routes',
    'routes' => [
        ['name' => 'home'],
        [
            'name' => 'product.details',
            'case' => 'ProductDetails',
            'method' => 'productDetails',
            'params' => [
                ['name' => 'productId', 'type' => 'int'],
                ['name' => 'preview', 'type' => 'bool', 'required' => false, 'default' => false],
            ],
        ],
    ],
]);
$assert(
    str_contains($generatedRoutes['AppRoute.php'], "case ProductDetails = 'product.details';")
        && str_contains($generatedRoutes['Routes.php'], 'public static function productDetails(int $productId, bool $preview = false): RouteTarget')
        && str_contains($generatedRoutes['Routes.php'], 'Route::to(AppRoute::ProductDetails, productId: $productId, preview: $preview)'),
    'Route code generation must emit enum destinations and statically typed helper signatures.',
);

$editorPreset = Route::preset(ScreenOptionsPatch::from([
    'headerShown' => true,
    'gestureDirection' => NavigationGestureDirection::Vertical,
    'animation' => NavigationTransition::FadeFromBottom,
]));
$testRouteModule = new class implements \Pam\Native\Routing\RouteModule {
    public function register(): void
    {
        Route::screen('module-route', static fn () => Screen::make(Text::make('Module')))
            ->deepLink('/module');
    }
};
$namedRouteNavigator = Route::stack(
    name: 'named-routes-test',
    initial: TypedRouteTestName::Home,
    routes: static function () use ($editorPreset, $testRouteModule): void {
        Route::module($testRouteModule);
        Route::screen(TypedRouteTestName::Home, static fn () => Screen::make(Text::make('Home')))
            ->deepLink('/home')
            ->deepLink('/start');
        Route::group(
            $editorPreset,
            static function (): void {
                Route::screen(TypedRouteTestName::Product, TypedRouteTestScreen::class)
                    ->transition(NavigationTransition::Fade, 175)
                    ->gesture(fullScreen: true)
                    ->options(ScreenOptionsPatch::one('title', 'Product'));
            },
        );
        Route::modal('filters', static fn () => Screen::make(Text::make('Filters')))
            ->transition(NavigationTransition::SlideFromBottom, 260)
            ->sheet(detents: [0.4, 1.0], grabber: true, cornerRadius: 24.0);
        Route::screen('preset-copy', static fn () => Screen::make(Text::make('Preset')))
            ->preset($editorPreset);
    },
);
$assert(
    $namedRouteNavigator->open('pam://app/module')
        && $namedRouteNavigator->currentRoute() === 'module-route',
    'Route modules must register destinations in the active stack without bootstrap coupling.',
);
$assert(
    $namedRouteNavigator->open('pam://app/home')
        && $namedRouteNavigator->open('pam://app/start')
        && $namedRouteNavigator->currentRoute() === 'home',
    'Laravel-style named routes must preserve every chained deep-link alias.',
);
Route::to(TypedRouteTestName::Product, productId: 42, preview: true)->push();
$namedProduct = $namedRouteNavigator->render()->toElement()->children()[1];
$namedProductOptions = $namedRouteNavigator->currentOptions();
$assert(
    $namedRouteNavigator->currentRoute() === 'product'
        && $namedProduct->children()[0]->properties()[PropKey::Text->value] === 'Product 42 preview'
        && $namedProductOptions->headerShown
        && $namedProductOptions->title === 'Product'
        && $namedProductOptions->animation === NavigationTransition::Fade
        && $namedProductOptions->animationDurationMs === 175
        && $namedProductOptions->gestureDirection === NavigationGestureDirection::Horizontal
        && $namedProductOptions->fullScreenGestureEnabled,
    'Laravel-style named routes must compose group, transition, gesture and route option layers.',
);
$namedRouteNavigator->push('filters');
$assert(
    $namedRouteNavigator->currentOptions()->presentation === NavigationPresentation::FormSheet
        && $namedRouteNavigator->currentOptions()->animation === NavigationTransition::SlideFromBottom
        && $namedRouteNavigator->currentOptions()->animationDurationMs === 260
        && $namedRouteNavigator->currentOptions()->sheetAllowedDetents === [0.4, 1.0]
        && $namedRouteNavigator->currentOptions()->sheetGrabberVisible
        && $namedRouteNavigator->currentOptions()->sheetCornerRadius === 24.0,
    'Named modal routes must compose native presentation, animation and sheet options.',
);
$namedRouteNavigator->push('preset-copy');
$assert(
    $namedRouteNavigator->currentOptions()->headerShown
        && $namedRouteNavigator->currentOptions()->gestureDirection === NavigationGestureDirection::Vertical
        && $namedRouteNavigator->currentOptions()->animation === NavigationTransition::FadeFromBottom,
    'Reusable route presets must compose identically in groups and individual destinations.',
);
$sessionOpen = false;
$chatAllowed = false;
$threadAllowed = false;
$guardCalls = [];
$guardedRoutes = Route::stack('guarded-routes-test', 'home', static function () use (
    &$sessionOpen,
    &$chatAllowed,
    &$threadAllowed,
    &$guardCalls,
): void {
    Route::screen('home', static fn () => Screen::make(Text::make('Home')));
    Route::guard(
        static function (RouteContext $route) use (&$sessionOpen, &$guardCalls): bool {
            $guardCalls[] = 'session:'.$route->name;
            return $sessionOpen;
        },
        static function () use (&$chatAllowed, &$threadAllowed, &$guardCalls): void {
            Route::screen('inbox', static fn () => Screen::make(Text::make('Inbox')));
            Route::guard(
                static function (RouteContext $route) use (&$chatAllowed, &$guardCalls): bool {
                    $guardCalls[] = 'chat:'.$route->name;
                    return $chatAllowed;
                },
                static function () use (&$threadAllowed, &$guardCalls): void {
                    Route::screen('thread', static fn () => Screen::make(Text::make('Thread')))
                        ->guard(static function (RouteContext $route) use (&$threadAllowed, &$guardCalls): bool {
                            $guardCalls[] = 'thread:'.$route->name;
                            return $threadAllowed;
                        })
                        ->deepLink('/thread/{id}');
                },
            );
        },
    );
    Route::screen('about', static fn () => Screen::make(Text::make('About')));
});
$assert(
    !$guardedRoutes->dispatch(NavigationAction::push('thread'))
        && $guardCalls === ['session:thread']
        && $guardedRoutes->currentRoute() === 'home',
    'Grouped guards must short-circuit before nested and route guards.',
);
$sessionOpen = true;
$guardCalls = [];
$assert(
    !$guardedRoutes->open('pam://app/thread/42')
        && $guardCalls === ['session:thread', 'chat:thread'],
    'Grouped guards must protect deep links in declaration order.',
);
$chatAllowed = true;
$guardCalls = [];
$assert(
    !$guardedRoutes->dispatch(NavigationAction::push('thread'))
        && $guardCalls === ['session:thread', 'chat:thread', 'thread:thread'],
    'A route guard must add to its enclosing group guards.',
);
$threadAllowed = true;
$guardCalls = [];
$guardedRoutes->push('thread');
$assert(
    $guardCalls === ['session:thread', 'chat:thread', 'thread:thread']
        && $guardedRoutes->currentRoute() === 'thread',
    'A destination must open after all enclosing and route guards pass.',
);
$sessionOpen = false;
$guardCalls = [];
$assert(
    $guardedRoutes->dispatch(NavigationAction::push('about'))
        && $guardCalls === []
        && $guardedRoutes->currentRoute() === 'about',
    'Grouped guards must not leak onto later ungrouped routes.',
);
$namedTabs = Route::tabs('named-tabs-test', 'home', static function (): void {
    Route::tab('home', Screen::make(Text::make('Home')), label: 'Home');
    Route::tab('settings', Screen::make(Text::make('Settings')), label: 'Settings', badge: '2');
});
$assert(
    NamedNavigation::navigate('settings')
        && $namedTabs->selectedTab() === 'settings',
    'Laravel-style named tabs must select destinations through the shared navigation scope.',
);
$namedTopTabs = Route::topTabs(
    'named-top-tabs-test',
    'recent',
    static function (): void {
        Route::topTab('recent', Screen::make(Text::make('Recent')), label: 'Recent');
        Route::topTab('following', Screen::make(Text::make('Following')), label: 'Following');
    },
    static fn (\Pam\Native\Navigation\TopTabRouter $tabs): \Pam\Native\Navigation\TopTabRouter =>
        $tabs->behavior(swipeEnabled: true, scrollEnabled: true, lazy: false),
);
$assert(
    NamedNavigation::navigate('following')
        && $namedTopTabs->selectedTab() === 'following',
    'Laravel-style top tabs must expose typed registration and the complete router configurator.',
);
$namedDrawer = Route::drawer(
    'named-drawer-test',
    'inbox',
    static function (): void {
        Route::drawerScreen('inbox', Screen::make(Text::make('Inbox')), label: 'Inbox', badge: '3');
        Route::drawerScreen('archive', Screen::make(Text::make('Archive')), label: 'Archive', group: 'Library');
    },
    static fn (\Pam\Native\Navigation\DrawerRouter $drawer): \Pam\Native\Navigation\DrawerRouter =>
        $drawer->responsive(720.0)->gestures(edgeWidth: 40.0),
);
$assert(
    NamedNavigation::navigate('archive')
        && $namedDrawer->selectedRoute() === 'archive',
    'Laravel-style drawers must expose grouped destinations and the complete router configurator.',
);
$declarativeNested = Route::stack(
    name: 'declarative-root',
    initial: 'main',
    routes: static function (): void {
        Route::navigator(
            'main',
            Route::tabs('declarative-tabs', 'feed', static function (): void {
                Route::tab(
                    'feed',
                    Route::stack(
                        name: 'declarative-feed-stack',
                        initial: 'feed-index',
                        routes: static function (): void {
                            Route::screen('feed-index', static fn () => Screen::make(Text::make('Feed')));
                            Route::screen('feed-details', static fn () => Screen::make(Text::make('Details')))
                                ->deepLink('/feed/post/{postId}');
                        },
                    ),
                    label: 'Feed',
                );
                Route::tab(
                    'account',
                    Route::stack(
                        name: 'declarative-account-stack',
                        initial: 'account-index',
                        routes: static function (): void {
                            Route::screen('account-index', static fn () => Screen::make(Text::make('Account')));
                            Route::screen('account-settings', static fn () => Screen::make(Text::make('Settings')))
                                ->deepLink('/account/settings');
                        },
                    ),
                    label: 'Account',
                );
            }),
        );
        Route::modal('global-modal', static fn () => Screen::make(Text::make('Modal')));
    },
);
$declarativeNested->render();
NamedNavigation::push('feed-details');
$assert(
    $declarativeNested->canGoBack()
        && $declarativeNested->goBack()
        && !$declarativeNested->canGoBack(),
    'Declarative navigators must nest stacks inside tabs and bubble actions and Back through the focused child.',
);
$assert(
    $declarativeNested->open('pam://app/account/settings')
        && $declarativeNested->currentPath() === '/account/settings'
        && $declarativeNested->goBack()
        && $declarativeNested->open('pam://app/feed/post/42')
        && $declarativeNested->currentPath() === '/feed/post/42',
    'Nested linking must select an inactive navigator and preserve canonical child paths and Back history.',
);
$nestedSavedState = $declarativeNested->saveState();
$declarativeNested->goBack();
NamedNavigation::navigate('account');
$declarativeNested->restoreState($nestedSavedState);
$declarativeNested->render();
$assert(
    $declarativeNested->currentPath() === '/feed/post/42',
    'Declarative nested navigators must restore the selected tab and child stack atomically.',
);
$headerNavigator = Router::stack('home')
    ->route(
        'home',
        static fn () => Screen::make(Text::make('Header content')),
        new ScreenOptions(title: 'Native header', headerShown: true),
    )
    ->build();
$headerElement = $headerNavigator->render()->toElement();
$assert(
    $headerElement->children()[0]->kind() === NodeKind::Screen
        && $headerElement->properties()[PropKey::NavigationTitle->value] === 'Native header'
        && $headerElement->properties()[PropKey::NavigationHeaderShown->value] === true
        && $headerNavigator->currentOptions()->title === 'Native header',
    'Screen options must configure controller-owned native chrome with typed options.',
);
$sheetNavigator = Router::stack('home')
    ->route('home', static fn () => Screen::make(Text::make('Home')))
    ->route(
        'filters',
        static fn () => Column::make(Text::make('Filters')),
        new ScreenOptions(
            title: 'Filters',
            headerShown: true,
            presentation: NavigationPresentation::FormSheet,
            sheetAllowedDetents: [0.5, 1.0],
            sheetInitialDetentIndex: 1,
            sheetGrabberVisible: true,
        ),
    )
    ->build();
$sheetNavigator->push('filters');
$sheetElement = $sheetNavigator->render()->toElement();
$assert(
    $sheetElement->children()[1]->kind() === NodeKind::Column
        && $sheetElement->properties()[PropKey::NavigationPresentation->value]
            === NavigationPresentation::FormSheet->value
        && $sheetElement->properties()[PropKey::NavigationSheetDetents->value] === '0.5,1',
    'Form-sheet routes must be owned by native controllers with typed detents.',
);

$advancedNavigator = Router::stack('home')
    ->route('home', static fn () => Screen::make(Text::make('Home')))
    ->route(
        'profile',
        static fn (RouteContext $route) => Screen::make(
            Text::make('Profile '.$route->integer('id')),
        ),
    )
    ->route(
        'article',
        static fn (RouteContext $route) => Screen::make(
            Text::make($route->string('slug') ?? ''),
        ),
    )
    ->deepLink('/articles/{slug}', 'article')
    ->build();
$advancedNavigator->push('profile', ['id' => 42, 'preview' => true]);
$assert(
    $advancedNavigator->current()->integer('id') === 42
        && $advancedNavigator->current()->boolean('preview') === true
        && $advancedNavigator->render()->toElement()->children()[1]
            ->children()[0]->properties()[PropKey::Text->value] === 'Profile 42',
    'Route contexts must expose bounded typed parameters to screen factories.',
);
$identifiedNavigator = Router::stack('home')
    ->route('home', static fn () => Screen::make(Text::make('Home')))
    ->route(
        'profile',
        static fn (RouteContext $route) => Screen::make(Text::make('Profile '.$route->integer('id'))),
        static fn (RouteContext $route) => new ScreenOptions(title: 'Profile '.$route->integer('id')),
        static fn (RouteContext $route): int => $route->integer('id') ?? 0,
    )
    ->build();
$identifiedNavigator->push('profile', ['id' => 1]);
$firstProfileKey = $identifiedNavigator->current()->key;
$identifiedNavigator->push('profile', ['id' => 2]);
$secondProfileKey = $identifiedNavigator->current()->key;
$identifiedNavigator->navigate('profile', ['id' => 1]);
$assert(
    $identifiedNavigator->current()->integer('id') === 1
        && $identifiedNavigator->current()->key === $firstProfileKey
        && $firstProfileKey !== $secondProfileKey
        && $identifiedNavigator->currentOptions()->title === 'Profile 1'
        && ($identifiedNavigator->getState()['routes'][1]['id'] ?? null) === '1',
    'getId route identity must distinguish same-name entities, reuse the matching entry, and resolve options from route context.',
);
$identifiedState = $identifiedNavigator->saveState();
$assert(
    $identifiedState['version'] === 4
        && ($identifiedState['stack'][1]['id'] ?? null) === '1',
    'Versioned navigation state must persist semantic route identities.',
);
$layeredOptionsNavigator = Router::stack('home')
    ->screenOptions(new ScreenOptions(headerShown: true, headerTintColor: 0xFF102030))
    ->group(
        ['profile'],
        ScreenOptionsPatch::from(['headerTransparent' => true]),
    )
    ->route('home', static fn () => Screen::make(Text::make('Home')))
    ->route(
        'profile',
        static fn () => Screen::make(Text::make('Profile')),
        ScreenOptionsPatch::from(['title' => 'Layered profile']),
    )
    ->build();
$layeredOptionsNavigator->push('profile');
$layered = $layeredOptionsNavigator->currentOptions();
$assert(
    $layered->headerShown
        && $layered->headerTransparent
        && $layered->headerTintColor === 0xFF102030
        && $layered->title === 'Layered profile',
    'Screen options must resolve navigator defaults, groups and sparse route overrides in order.',
);
$layeredOptionsNavigator->setOptions(ScreenOptionsPatch::from([
    'headerShown' => false,
    'headerTintColor' => null,
]));
$assert(
    !$layeredOptionsNavigator->currentOptions()->headerShown
        && $layeredOptionsNavigator->currentOptions()->headerTintColor === null,
    'Runtime option patches must preserve explicit false and null values.',
);
$layeredOptionsNavigator->clearOptions();
$assert(
    $layeredOptionsNavigator->currentOptions()->headerShown
        && $layeredOptionsNavigator->currentOptions()->headerTintColor === 0xFF102030,
    'Clearing runtime options must reveal the inherited option chain again.',
);
$advancedNavigator->push('article', ['slug' => 'temporary']);
$assert(
    $advancedNavigator->popTo('profile')
        && $advancedNavigator->currentRoute() === 'profile',
    'popTo must remove intermediate routes and retain the target entry.',
);
$savedNavigation = $advancedNavigator->saveState();
$restoredNavigator = Router::stack('home')
    ->route('home', static fn () => Screen::make(Text::make('Home')))
    ->route('profile', static fn (RouteContext $route) => Screen::make(
        Text::make((string) $route->integer('id')),
    ))
    ->build();
$restoredNavigator->restoreState($savedNavigation);
$assert(
    $restoredNavigator->current()->integer('id') === 42,
    'Navigator persistence must preserve route parameters.',
);
$tamperedNavigation = $savedNavigation;
$tamperedNavigation['stack'][1]['params']['id'] = 999;
$checksumProtectedNavigator = Router::stack('home')
    ->route('home', static fn () => Screen::make(Text::make('Home')))
    ->route('profile', static fn () => Screen::make(Text::make('Profile')))
    ->build();
$checksumProtectedNavigator->restoreState($tamperedNavigation);
$assert(
    $checksumProtectedNavigator->currentRoute() === 'home',
    'Navigation persistence must reject a modified state checksum atomically.',
);
$ephemeralNavigator = Router::stack('home')
    ->restoreState(false)
    ->route('home', static fn () => Screen::make(Text::make('Home')))
    ->route('profile', static fn () => Screen::make(Text::make('Profile')))
    ->build();
$ephemeralNavigator->restoreState($savedNavigation);
$assert(
    $ephemeralNavigator->currentRoute() === 'home',
    'Navigator state restoration must be explicitly disableable for deterministic cold starts.',
);
$assert(
    $advancedNavigator->open('pam://docs/articles/native%20grid?source=notification')
        && $advancedNavigator->currentRoute() === 'article'
        && $advancedNavigator->current()->string('slug') === 'native grid'
        && $advancedNavigator->current()->string('source') === 'notification',
    'Deep links must resolve encoded path and scalar query parameters.',
);
$hostNavigator = Router::stack('home')
    ->route('home', static fn () => Screen::make(Text::make('Home')))
    ->route('profile', static fn () => Screen::make(Text::make('Profile')))
    ->deepLink('/profile/{username}', 'profile')
    ->build();
$assert(
    $hostNavigator->open('pushin://profile/david?source=share')
        && $hostNavigator->currentRoute() === 'profile'
        && $hostNavigator->current()->string('username') === 'david'
        && $hostNavigator->current()->string('source') === 'share',
    'Custom-scheme deep links must also match host-plus-path route patterns.',
);
$optionalLinkNavigator = Router::stack('home')
    ->route('home', static fn () => Screen::make(Text::make('Home')))
    ->route('catalog', static fn () => Screen::make(Text::make('Catalog')))
    ->route('document', static fn () => Screen::make(Text::make('Document')))
    ->deepLink('/catalog/{category?}', 'catalog')
    ->deepLink('/documents/{path*}', 'document')
    ->linking(
        ['pam://app', 'https://native.example'],
        static fn (string $uri): bool => !str_contains($uri, '/blocked'),
    )
    ->build();
$assert(
    $optionalLinkNavigator->open('pam://app/catalog')
        && $optionalLinkNavigator->currentPath() === '/catalog'
        && $optionalLinkNavigator->open('pam://app/documents/guides/native/start')
        && $optionalLinkNavigator->current()->string('path') === 'guides/native/start'
        && $optionalLinkNavigator->currentPath() === '/documents/guides/native/start'
        && $optionalLinkNavigator->currentUrl() === 'pam://app/documents/guides/native/start'
        && !$optionalLinkNavigator->open('pam://application/documents/private')
        && !$optionalLinkNavigator->open('other://documents/private')
        && !$optionalLinkNavigator->open('pam://app/blocked'),
    'Deep links must support optional/wildcard parameters and enforce URI prefix boundaries.',
);
$pathPriorityNavigator = Router::stack('home')
    ->route('home', static fn () => Screen::make(Text::make('Home')))
    ->route('profile', static fn () => Screen::make(Text::make('Profile')))
    ->deepLink('/profile/{id}', 'profile')
    ->build();
$assert(
    $pathPriorityNavigator->open('pam://app/profile/42?id=99')
        && $pathPriorityNavigator->current()->string('id') === '42',
    'A query string must not override an identity captured from the path.',
);
$authenticated = false;
$authNavigator = Router::stack('login')
    ->route('login', static fn () => Screen::make(Text::make('Login')))
    ->route('account', static fn () => Screen::make(Text::make('Account')))
    ->guard('account', static function () use (&$authenticated): bool {
        return $authenticated;
    })
    ->guardFallback('login')
    ->deepLink('/account', 'account')
    ->build();
$assert(
    !$authNavigator->dispatch(NavigationAction::navigate('account'))
        && !$authNavigator->open('pam://app/account')
        && $authNavigator->currentRoute() === 'login',
    'Guards must reject actions and deep links before protected route content is instantiated.',
);
$authenticated = true;
$assert(
    $authNavigator->dispatch(NavigationAction::navigate('account'))
        && $authNavigator->currentRoute() === 'account',
    'Conditional routes must become reachable immediately after their guard state changes.',
);
$authenticatedState = $authNavigator->saveState();
$authenticated = false;
$assert(
    $authNavigator->refreshConditions()
        && $authNavigator->currentRoute() === 'login'
        && !$authNavigator->canGoBack(),
    'Logout must atomically remove protected history and retain the registered public fallback.',
);
$authNavigator->restoreState($authenticatedState);
$assert(
    $authNavigator->currentRoute() === 'login' && !$authNavigator->canGoBack(),
    'Cold restoration must never reopen a route whose auth guard is no longer satisfied.',
);
$assert(
    $advancedNavigator->popToTop()
        && $advancedNavigator->currentRoute() === 'home',
    'popToTop must restore the first stack entry.',
);
$navigationEvents = [];
$eventSubscription = $advancedNavigator->addListener(
    NavigationEventType::State,
    static function (NavigationEvent $event) use (&$navigationEvents): void {
        $navigationEvents[] = $event->data['state'];
    },
);
$assert(
    $advancedNavigator->dispatch(NavigationAction::push('profile', ['id' => 7]))
        && $advancedNavigator->current()->key !== null
        && $advancedNavigator->getState()['type'] === 1
        && $navigationEvents !== [],
    'Navigation actions must update observable, keyed stack state.',
);
$advancedNavigator->setParams(['preview' => true]);
$assert(
    $advancedNavigator->current()->integer('id') === 7
        && $advancedNavigator->current()->boolean('preview') === true,
    'setParams must merge validated parameters into the focused route.',
);
$advancedNavigator->replaceParams(['id' => 8]);
$assert(
    $advancedNavigator->current()->integer('id') === 8
        && !$advancedNavigator->current()->has('preview'),
    'replaceParams must replace the focused route parameter set.',
);
$blocked = $advancedNavigator->addListener(
    NavigationEventType::BeforeRemove,
    static function (NavigationEvent $event): void {
        $event->preventDefault();
    },
);
$assert(!$advancedNavigator->pop(), 'beforeRemove must cancel every stack removal path.');
$blocked->unsubscribe();
$assert($advancedNavigator->pop(), 'Removing a beforeRemove listener must release navigation.');
$containerStateChanges = 0;
$unhandledActions = 0;
$container = NavigationContainer::make($advancedNavigator)
    ->onStateChange(static function () use (&$containerStateChanges): void {
        $containerStateChanges++;
    })
    ->onUnhandledAction(static function (NavigationAction $action) use (&$unhandledActions): void {
        if ($action->type === NavigationActionType::Navigate) $unhandledActions++;
    });
$assert(
    !$container->dispatch(NavigationAction::navigate('missing'))
        && $unhandledActions === 1,
    'NavigationContainer must report unhandled actions without mutating state.',
);
$assert(
    $container->dispatch(NavigationAction::navigate('article', ['slug' => 'native core']))
        && $container->currentPath() === '/articles/native%20core'
        && $containerStateChanges === 1,
    'NavigationContainer must dispatch actions and build canonical paths from state.',
);
$container->unmount();
$advancedNavigator->navigate('profile', ['id' => 91]);
$detachedStateChanges = $containerStateChanges;
$container->mount();
$advancedNavigator->navigate('article', ['slug' => 'remounted']);
$assert(
    $detachedStateChanges === 1 && $containerStateChanges === 2,
    'NavigationContainer must release root listeners on unmount and restore exactly one subscription on remount.',
);
$navigationRef = new NavigationRef();
$refNavigator = Router::stack('home')
    ->route('home', static fn () => Screen::make(Text::make('Home')))
    ->route('profile', static fn () => Screen::make(Text::make('Profile')))
    ->build();
$assert(
    $navigationRef->navigate('profile') && !$navigationRef->isReady(),
    'Navigation refs must safely queue actions before the root container mounts.',
);
$refContainer = NavigationContainer::make($refNavigator, $navigationRef);
$refContainer->mount();
$assert(
    $navigationRef->isReady()
        && $navigationRef->currentRoute()?->name === 'profile'
        && ($navigationRef->rootState()['index'] ?? null) === 1,
    'Navigation refs must replay queued actions in order and expose the mounted root state.',
);
$refContainer->unmount();
$assert(!$navigationRef->isReady(), 'Unmounting must detach navigation refs without retaining the container.');
$navigationDevTools = new NavigationDevTools($container, capacity: 16);
$container->dispatch(NavigationAction::navigate('article', ['slug' => 'observed']));
$navigationTimeline = $navigationDevTools->timeline();
$navigationExport = json_decode($navigationDevTools->exportJson(), true, flags: JSON_THROW_ON_ERROR);
$navigationMetrics = $navigationDevTools->metrics();
$assert(
    $navigationTimeline !== []
        && $navigationTimeline[0]['kind'] === NavigationTraceKind::Action->value
        && ($navigationDevTools->tree()['routes'][0]['name'] ?? null) === 'home'
        && ($navigationExport['schemaVersion'] ?? null) === 1
        && ($navigationExport['surfaceCode'] ?? null) === 2
        && is_int($navigationExport['capturedAtUnixMs'] ?? null)
        && ($navigationExport['version'] ?? null) === 2
        && ($navigationExport['metrics']['events'] ?? 0) === count($navigationTimeline)
        && ($navigationMetrics['currentRoute'] ?? null) === 'article',
    'Navigation DevTools must expose bounded traces, metrics and recursive tree snapshots.',
);
$navigationDevTools->detach();
$preloadFactories = 0;
$preloadNavigator = Router::stack('home')
    ->route('home', static fn () => Screen::make(Text::make('Home')))
    ->route('detail', static function (RouteContext $route) use (&$preloadFactories): Screen {
        $preloadFactories++;
        return Screen::make(Text::make((string) $route->integer('id')));
    })
    ->build();
$assert(
    $preloadNavigator->preload('detail', ['id' => 42])
        && $preloadFactories === 1,
    'preload must instantiate a bounded route exactly once ahead of navigation.',
);
$preloadNavigator->push('detail', ['id' => 42]);
$preloadNavigator->render();
$preloadNavigator->render();
$assert(
    $preloadFactories === 1,
    'An exact preloaded route must be consumed and retained without rerunning its factory.',
);
$boundedPreloadFactories = 0;
$boundedPreloads = Router::stack('home')
    ->route('home', static fn () => Screen::make(Text::make('Home')))
    ->route('detail', static function () use (&$boundedPreloadFactories): Screen {
        $boundedPreloadFactories++;
        return Screen::make(Text::make('Detail'));
    })
    ->build();
for ($id = 1; $id <= 17; $id++) $boundedPreloads->preload('detail', ['id' => $id]);
$boundedPreloads->push('detail', ['id' => 1]);
$boundedPreloads->render();
$boundedPreloads->preload('detail', ['id' => 99]);
$boundedPreloads->trimMemory();
$boundedPreloads->push('detail', ['id' => 99]);
$boundedPreloads->render();
$assert(
    $boundedPreloadFactories === 20,
    'Speculative routes must use a 16-entry LRU bound and be releasable under memory pressure.',
);
$lifecycleScreen = new class extends Component implements NavigationLifecycleAware {
    use InteractsWithNavigationLifecycle;

    public int $focused = 0;
    public int $blurred = 0;
    public int $removed = 0;

    public function render(): \Pam\Native\Renderable
    {
        return Screen::make(Text::make('Lifecycle'));
    }

    public function navigationFocused(RouteContext $route): void
    {
        $this->focused++;
    }

    public function navigationBlurred(RouteContext $route): void
    {
        $this->blurred++;
    }

    public function navigationRemoved(RouteContext $route): void
    {
        $this->removed++;
    }
};
$lifecycleNavigator = Router::stack('lifecycle')
    ->route('lifecycle', static fn () => $lifecycleScreen)
    ->route('next', static fn () => Screen::make(Text::make('Next')))
    ->build();
$lifecycleNavigator->render();
$lifecycleNavigator->push('next');
$transitionHost = $lifecycleNavigator->render()->toElement();
$assert(
    $lifecycleScreen->focused === 1 && $lifecycleScreen->blurred === 1,
    'Navigation-aware components must receive focus and blur independently of mount state.',
);
($transitionHost->events()[EventKind::AnimationComplete->value])('');
$lifecycleNavigator->pop();
$lifecycleNavigator->render();
$assert(
    $lifecycleScreen->focused === 2,
    'Returning to a retained route must deliver focus without recreating the component.',
);
$eventSubscription->unsubscribe();

$tabNavigator = Router::tabs('home')
    ->tab('home', 'Home', Screen::make(Text::make('Home tab')))
    ->tab(
        'orders',
        'Orders',
        Router::stack('orders.index')
            ->route(
                'orders.index',
                static fn () => Screen::make(Text::make('Orders tab')),
            )
            ->build(),
    )
    ->presentation(TabPresentation::Bottom)
    ->persistence('test-main-tabs')
    ->build();
$assert(
    $tabNavigator instanceof TabNavigator
        && $tabNavigator->selectedTab() === 'home'
        && $tabNavigator->resolvedPresentation() === TabPresentation::Bottom,
    'Tab router must build a typed native tab navigator.',
);
$assert(
    $tabNavigator->select('orders')
        && $tabNavigator->selectedTab() === 'orders'
        && $tabNavigator->toElement()->kind() === NodeKind::TabHost,
    'Tab navigator must retain independent content in a platform-native tab host.',
);
$restoredTabs = Router::tabs('home')
    ->tab('home', 'Home', Screen::make(Text::make('Home tab')))
    ->tab('orders', 'Orders', Screen::make(Text::make('Orders tab')))
    ->persistence('test-main-tabs')
    ->build();
$assert(
    $restoredTabs->selectedTab() === 'orders',
    'Tab navigator must restore the selected destination.',
);
$topTabs = Router::topTabs('feed')
    ->tab('feed', 'Feed', Screen::make(Text::make('Feed')))
    ->tab('following', 'Following', Screen::make(Text::make('Following')))
    ->behavior(swipeEnabled: true, scrollEnabled: true, lazy: true)
    ->persistence('test-top-tabs')
    ->build();
$assert(
    $topTabs->selectedTab() === 'feed'
        && $topTabs->jumpTo('following')
        && $topTabs->toElement()->kind() === NodeKind::TabHost,
    'Top tabs must support lazy retained scenes, jumpTo and native swipe recognition.',
);

$homeTabRenders = 0;
$ordersTabRenders = 0;
$lazyTabs = Router::tabs('home')
    ->tab('home', 'Home', static function () use (&$homeTabRenders): Screen {
        $homeTabRenders++;
        return Screen::make(Text::make('Lazy home'));
    })
    ->tab('orders', 'Orders', static function () use (&$ordersTabRenders): Screen {
        $ordersTabRenders++;
        return Screen::make(Text::make('Lazy orders'));
    })
    ->appearance(0xFF0F172A, 0xFF60A5FA, 0xFF94A3B8, 0xFF1E293B)
    ->persistence('test-lazy-tabs')
    ->build();
$lazyTabs->toElement();
$assert(
    $homeTabRenders === 1 && $ordersTabRenders === 0,
    'Tab navigation must mount only the selected destination during cold start.',
);
$lazyTabs->select('orders');
$lazyTabs->toElement();
$assert(
    $homeTabRenders === 1 && $ordersTabRenders === 1,
    'Selecting a tab must lazily mount only the next destination.',
);
$lazyTabs->select('home');
$lazyTabs->toElement();
$assert(
    $homeTabRenders === 1 && $ordersTabRenders === 1,
    'Previously visited tab scenes must be retained instead of invoking route factories again.',
);
$nestedStack = Router::stack('nested.index')
    ->route('nested.index', static fn () => Screen::make(Text::make('Nested')))
    ->build();
$nestedTabs = Router::tabs('nested')
    ->tab('nested', 'Nested', $nestedStack)
    ->tab('other', 'Other', Screen::make(Text::make('Other')))
    ->persistence('test-recursive-tabs')
    ->build();
$nestedTabs->toElement();
$assert(
    $nestedTabs->getState()['routes'][0]['state']['type'] === 1,
    'Navigation state must recursively expose mounted child navigators.',
);
$nestedStack->push('nested.index');
$outerNavigator = Router::stack('app')
    ->route('app', static fn () => $nestedTabs)
    ->build();
$outerNavigator->render();
$nestedStateEvents = 0;
$nestedStateSubscription = $outerNavigator->addListener(
    NavigationEventType::State,
    static function () use (&$nestedStateEvents): void {
        $nestedStateEvents++;
    },
);
$nestedStack->push('nested.index');
$assert(
    $nestedStateEvents === 1
        && $outerNavigator->getState()['routes'][0]['state']['routes'][0]['state']['index'] === 2,
    'Nested state changes must bubble to the root without polling or remounting scenes.',
);
$assert(
    $outerNavigator->canGoBack()
        && $outerNavigator->goBack()
        && $nestedStack->canGoBack()
        && $outerNavigator->goBack()
        && !$nestedStack->canGoBack(),
    'Back must recurse into the focused child navigator before changing the parent stack.',
);
$assert(
    $outerNavigator->dispatch(
        NavigationAction::push('nested.index')->target($nestedStack->key()),
    )
        && $nestedStack->getState()['index'] === 1
        && $outerNavigator->dispatch(NavigationAction::goBack()->target($nestedStack->key()))
        && $nestedStack->getState()['index'] === 0,
    'Targeted actions must traverse stack, tabs and the focused nested stack without being consumed by an ancestor.',
);
$nestedStack->push('nested.index', ['generation' => 2]);
$savedNestedTree = $outerNavigator->saveState();
$freshNestedStack = Router::stack('nested.index')
    ->route('nested.index', static fn () => Screen::make(Text::make('Restored nested')))
    ->build();
$freshNestedTabs = Router::tabs('nested')
    ->tab('nested', 'Nested', $freshNestedStack)
    ->tab('other', 'Other', Screen::make(Text::make('Other')))
    ->persistence('test-restored-recursive-tabs')
    ->build();
$freshOuter = Router::stack('app')
    ->route('app', static fn () => $freshNestedTabs)
    ->build();
$freshOuter->restoreState($savedNestedTree);
$freshOuter->render();
$freshNestedTabs->toElement();
$assert(
    $freshNestedStack->getState()['index'] === 1
        && $freshNestedStack->current()->integer('generation') === 2,
    'Cold restoration must recursively rehydrate focused child stacks without eagerly mounting inactive tabs.',
);
$nestedStateSubscription->unsubscribe();
$groupedDrawer = Router::drawer('overview')
    ->route('overview', 'Overview', Screen::make(Text::make('Overview')))
    ->route(
        'button',
        'Button',
        Screen::make(Text::make('Button')),
        group: 'Actions',
    )
    ->route(
        'field',
        'Text field',
        Screen::make(Text::make('Text field')),
        group: 'Forms',
    )
    ->persistence('test-grouped-drawer')
    ->build();
$assert(
    !$groupedDrawer->isGroupExpanded('Actions')
        && $groupedDrawer->toggleGroup('Actions')
        && $groupedDrawer->isGroupExpanded('Actions')
        && $groupedDrawer->navigate('field')
        && $groupedDrawer->isGroupExpanded('Forms'),
    'Grouped drawer routes must collapse cleanly and keep every destination navigable.',
);
$restoredGroupedDrawer = Router::drawer('overview')
    ->route('overview', 'Overview', Screen::make(Text::make('Overview')))
    ->route(
        'button',
        'Button',
        Screen::make(Text::make('Button')),
        group: 'Actions',
    )
    ->route(
        'field',
        'Text field',
        Screen::make(Text::make('Text field')),
        group: 'Forms',
    )
    ->persistence('test-grouped-drawer')
    ->build();
$assert(
    $restoredGroupedDrawer->selectedRoute() === 'field'
        && $restoredGroupedDrawer->isGroupExpanded('Actions')
        && $restoredGroupedDrawer->isGroupExpanded('Forms'),
    'Grouped drawer state must restore selection and expanded sections.',
);

$responsiveMetricsReader = new class extends Component {
    public int $renders = 0;

    protected function initialState(): array
    {
        return ['revision' => 0];
    }

    public function render(): Renderable
    {
        $this->renders++;
        $this->state->revision;
        App::windowMetrics();

        return Text::make('Nested responsive navigator metrics');
    }
};
App::run($responsiveMetricsReader);
Runtime::dispatchEvent(0, EventKind::Dimensions->value, Wire::map([
    'width' => 1_000.0,
    'height' => 600.0,
    'density' => 2.0,
]));
$nestedResponsiveDrawer = Router::drawer('overview')
    ->route('overview', 'Overview', Screen::make(Text::make('Overview')))
    ->route('field', 'Text field', Screen::make(Text::make('Text field')))
    ->responsive(840.0)
    ->persistence('test-nested-responsive-drawer-presentation')
    ->build();
$assert(
    $responsiveMetricsReader->renders === 2
        && $nestedResponsiveDrawer->resolvedType()
        === \Pam\Native\Navigation\DrawerType::Permanent,
    'Window-metric readers and nested responsive drawers must update without being the App root.',
);
Runtime::shutdown();

$responsiveDrawer = Router::drawer('overview')
    ->route('overview', 'Overview', Screen::make(Text::make('Overview')))
    ->route('field', 'Text field', Screen::make(Text::make('Text field')))
    ->responsive(840.0)
    ->persistence('test-responsive-drawer-presentation')
    ->build();
$responsiveDrawer->dimensions(new WindowMetrics(1_000.0, 600.0, 2.0));
$permanentDrawerElement = $responsiveDrawer->toElement();
$permanentOpen = $permanentDrawerElement->events()[EventKind::DrawerOpen->value] ?? null;
$permanentOpen?->__invoke();
$responsiveDrawer->dimensions(new WindowMetrics(412.0, 915.0, 2.0));
$compactDrawerElement = $responsiveDrawer->toElement();
$assert(
    $responsiveDrawer->resolvedType() === \Pam\Native\Navigation\DrawerType::Front
        && $responsiveDrawer->getState()['open'] === false
        && $compactDrawerElement->properties()[PropKey::DrawerOpen->value] === false,
    'Permanent drawer callbacks must not leak an open modal drawer into the compact layout after rotation.',
);
$assert(
    \Pam\Native\Protocol::SDK_VERSION === '1.1.0',
    'The runtime SDK contract must match the 1.1.0 release candidate.',
);
$protocolReport = \Pam\Native\Protocol::negotiate(new \Pam\Native\ProtocolHandshake(
    abiVersion: 1,
    minimumProtocolVersion: 1,
    maximumProtocolVersion: 2,
    capabilities: ['wire.binary.v1', 'renderer.incremental.v1', 'peer.future.v1'],
));
$assert(
    $protocolReport->isCompatible()
        && $protocolReport->protocolVersion === 1
        && $protocolReport->capabilities === ['renderer.incremental.v1', 'wire.binary.v1']
        && $protocolReport->requireCapabilities(['wire.binary.v1'])->isCompatible()
        && $protocolReport->requireCapabilities(['renderer.gpu.v1'])->status
            === \Pam\Native\ProtocolCompatibilityStatus::MissingCapability
        && array_map(
            static fn (\Pam\Native\ProtocolCompatibilityStatus $status): int => $status->value,
            \Pam\Native\ProtocolCompatibilityStatus::cases(),
        ) === [1, 2, 3, 4],
    'Protocol negotiation must select the common ABI, version and capabilities deterministically.',
);
$assert(
    \Pam\Native\Protocol::negotiate(new \Pam\Native\ProtocolHandshake(2, 1, 1, []))->status
        === \Pam\Native\ProtocolCompatibilityStatus::AbiMismatch
        && \Pam\Native\Protocol::negotiate(new \Pam\Native\ProtocolHandshake(1, 2, 3, []))->status
            === \Pam\Native\ProtocolCompatibilityStatus::ProtocolMismatch,
    'Protocol negotiation must fail closed for incompatible ABI and protocol ranges.',
);
$updateBundle = sys_get_temp_dir().'/pam-native-update-'.getmypid().'.bin';
file_put_contents($updateBundle, 'signed-pam-native-bundle');
$updateManifest = new \Pam\Native\Update\SignedUpdateManifest(
    buildIdentifier: str_repeat('a', 64),
    bundleSha256: hash_file('sha256', $updateBundle),
    abiVersion: \Pam\Native\Protocol::ABI_VERSION,
    protocolVersion: \Pam\Native\Protocol::VERSION,
    channel: \Pam\Native\Update\UpdateChannel::Stable,
    rolloutBasisPoints: 2_500,
    capabilities: ['wire.binary.v1', 'renderer.incremental.v1'],
);
$updateJson = $updateManifest->canonicalJson();
$updateKeyPair = sodium_crypto_sign_keypair();
$updateSecretKey = sodium_crypto_sign_secretkey($updateKeyPair);
$updatePublicKey = sodium_crypto_sign_publickey($updateKeyPair);
$updateSignature = sodium_crypto_sign_detached($updateJson, $updateSecretKey);
$approvedUpdate = \Pam\Native\Update\UpdateVerifier::evaluate(
    $updateJson,
    base64_encode($updateSignature),
    base64_encode($updatePublicKey),
    str_repeat('b', 64),
    2_499,
);
$assert(
    $approvedUpdate->approved()
        && \Pam\Native\Update\UpdateVerifier::verifyBundle($updateBundle, $updateManifest)
        && \Pam\Native\Update\UpdateVerifier::evaluate(
            $updateJson,
            base64_encode(str_repeat("\0", SODIUM_CRYPTO_SIGN_BYTES)),
            base64_encode($updatePublicKey),
            str_repeat('b', 64),
            0,
        )->status === \Pam\Native\Update\UpdateDecisionStatus::InvalidSignature
        && \Pam\Native\Update\UpdateVerifier::evaluate(
            $updateJson,
            base64_encode($updateSignature),
            base64_encode($updatePublicKey),
            str_repeat('b', 64),
            2_500,
        )->status === \Pam\Native\Update\UpdateDecisionStatus::OutsideRollout
        && array_map(
            static fn (\Pam\Native\Update\UpdateDecisionStatus $status): int => $status->value,
            \Pam\Native\Update\UpdateDecisionStatus::cases(),
        ) === [1, 2, 3, 4, 5, 6],
    'Signed OTA manifests must verify Ed25519, ABI, capabilities, rollout, and exact bundle bytes.',
);
$updateSlotsPath = sys_get_temp_dir().'/pam-native-update-slots-'.getmypid();
if (is_dir($updateSlotsPath)) {
    foreach (glob($updateSlotsPath.'/*') ?: [] as $updateSlotFile) {
        if (is_file($updateSlotFile)) {
            unlink($updateSlotFile);
        }
    }
    rmdir($updateSlotsPath);
}
$updateSlots = new \Pam\Native\Update\UpdateSlotManager($updateSlotsPath);
$runtimeStatePath = sys_get_temp_dir().'/pam-native-runtime-state-'.getmypid().'/pam/state';
mkdir($runtimeStatePath, 0o700, true);
$previousRuntimeState = getenv('PAM_NATIVE_STATE_DIR');
putenv('PAM_NATIVE_STATE_DIR='.$runtimeStatePath);
$runtimeUpdateSlots = \Pam\Native\Update\UpdateSlotManager::forRuntime();
$assert(
    is_dir(dirname($runtimeStatePath).'/updates'),
    'Runtime OTA slots must use the private directory shared with Android and iOS hosts.',
);
putenv($previousRuntimeState === false ? 'PAM_NATIVE_STATE_DIR' : 'PAM_NATIVE_STATE_DIR='.$previousRuntimeState);
$assert(
    $updateSlots->stage($updateBundle, $updateManifest) === \Pam\Native\Update\UpdateActivationStatus::Staged
        && $updateSlots->activate() === \Pam\Native\Update\UpdateActivationStatus::Activated
        && file_get_contents((string) $updateSlots->activeBundle()) === 'signed-pam-native-bundle',
    'The first verified OTA bundle must activate atomically.',
);
file_put_contents($updateBundle, 'second-signed-pam-native-bundle');
$secondUpdateManifest = new \Pam\Native\Update\SignedUpdateManifest(
    buildIdentifier: str_repeat('c', 64),
    bundleSha256: (string) hash_file('sha256', $updateBundle),
    abiVersion: \Pam\Native\Protocol::ABI_VERSION,
    protocolVersion: \Pam\Native\Protocol::VERSION,
    channel: \Pam\Native\Update\UpdateChannel::Stable,
    rolloutBasisPoints: 10_000,
    capabilities: ['wire.binary.v1'],
);
$assert(
    $updateSlots->stage($updateBundle, $secondUpdateManifest) === \Pam\Native\Update\UpdateActivationStatus::Staged
        && $updateSlots->activate() === \Pam\Native\Update\UpdateActivationStatus::Activated
        && file_get_contents((string) $updateSlots->activeBundle()) === 'second-signed-pam-native-bundle'
        && $updateSlots->rollback() === \Pam\Native\Update\UpdateActivationStatus::RolledBack
        && file_get_contents((string) $updateSlots->activeBundle()) === 'signed-pam-native-bundle'
        && array_map(
            static fn (\Pam\Native\Update\UpdateActivationStatus $status): int => $status->value,
            \Pam\Native\Update\UpdateActivationStatus::cases(),
        ) === [1, 2, 3],
    'OTA slots must preserve one previous verified bundle and roll back atomically.',
);
sodium_memzero($updateSecretKey);
unlink($updateBundle);
foreach (glob($updateSlotsPath.'/*') ?: [] as $updateSlotFile) {
    if (is_file($updateSlotFile)) {
        unlink($updateSlotFile);
    }
}
rmdir($updateSlotsPath);
foreach (glob(dirname($runtimeStatePath).'/updates/*') ?: [] as $runtimeUpdateFile) {
    if (is_file($runtimeUpdateFile)) {
        unlink($runtimeUpdateFile);
    }
}
rmdir(dirname($runtimeStatePath).'/updates');
rmdir($runtimeStatePath);
rmdir(dirname($runtimeStatePath));
rmdir(dirname(dirname($runtimeStatePath)));
$imageEditorParameters = (new ReflectionMethod(
    \Pam\Native\System\ImageEditor::class,
    'render',
))->getParameters();
$assert(
    array_map(
        static fn (\Pam\Native\ImageCropRatio $case): int => $case->value,
        \Pam\Native\ImageCropRatio::cases(),
    ) === [1, 2, 3, 4, 5]
        && array_map(
            static fn (\Pam\Native\ImageFilterType $case): int => $case->value,
            \Pam\Native\ImageFilterType::cases(),
        ) === [1, 2, 3, 4, 5]
        && array_map(
            static fn (ReflectionParameter $parameter): string => $parameter->getName(),
            array_slice($imageEditorParameters, -5),
        ) === ['maxWidth', 'maxHeight', 'outputQuality', 'drawing', 'textLayers']
        && $imageEditorParameters[count($imageEditorParameters) - 3]->getDefaultValue() === 94
        && $imageEditorParameters[count($imageEditorParameters) - 2]->getDefaultValue() === ''
        && $imageEditorParameters[array_key_last($imageEditorParameters)]->getDefaultValue() === [],
    'The image editor contract must expose typed transforms, bounded output, drawing and text layers.',
);
$textLayersMethod = new ReflectionMethod(\Pam\Native\System\ImageEditor::class, 'textLayers');
$normalizedTextLayers = json_decode($textLayersMethod->invoke(null, [[
    'color' => 'invalid',
    'rotation' => 99,
    'scale' => 9,
    'style_type' => 2,
    'text' => ' Resposta ',
    'x' => -1,
    'y' => 2,
]]), true, 64, JSON_THROW_ON_ERROR);
$normalizedTextLayer = $normalizedTextLayers[0] ?? [];
$assert(
    array_map(
        static fn (\Pam\Native\ImageTextLayerStyle $case): int => $case->value,
        \Pam\Native\ImageTextLayerStyle::cases(),
    ) === [1, 2, 3]
        && ($normalizedTextLayer['color'] ?? '') === '#FFFFFF'
        && abs((float) ($normalizedTextLayer['rotation'] ?? 0) - M_PI * 2) < 0.000001
        && (float) ($normalizedTextLayer['scale'] ?? 0) === 4.0
        && ($normalizedTextLayer['styleType'] ?? 0) === 2
        && ($normalizedTextLayer['text'] ?? '') === 'Resposta'
        && (float) ($normalizedTextLayer['x'] ?? -1) === 0.0
        && (float) ($normalizedTextLayer['y'] ?? -1) === 1.0,
    'Image editor text layers must normalize bounds, color and integer presentation style.',
);

$bottomSheet = BottomSheet::make(
    Text::make('Sheet content'),
    [0.25, 0.6, 1.0],
    1,
)
    ->dismissible(false)
    ->backdropDismiss(false)
    ->handleVisible(false)
    ->dragEnabled(false)
    ->cornerRadius(28)
    ->keyboardBehavior(BottomSheetKeyboardBehavior::FillParent);
$bottomSheetProperties = $bottomSheet->properties();
$assert(
    $bottomSheet->kind() === NodeKind::Modal
        && $bottomSheetProperties[PropKey::BottomSheetIndex->value] === 1
        && $bottomSheetProperties[PropKey::BottomSheetDismissible->value] === false
        && $bottomSheetProperties[PropKey::BottomSheetKeyboardBehavior->value]
            === BottomSheetKeyboardBehavior::FillParent->value,
    'BottomSheet must compile its complete native configuration.',
);
$templateBottomSheet = TemplateRenderer::render(
    TemplateCompiler::compile(
        '<BottomSheet index="1" keyboardBehavior="extend">'
        .'<Text>Template sheet</Text></BottomSheet>',
    ),
    new class {
    },
    [],
);
$assert(
    $templateBottomSheet->properties()[PropKey::BottomSheetIndex->value] === 1
        && $templateBottomSheet->properties()[
            PropKey::BottomSheetKeyboardBehavior->value
        ] === BottomSheetKeyboardBehavior::Extend->value,
    'BottomSheet must be available from declarative templates.',
);

$animated = Animated::make(
    Text::make('Animated'),
    [
        new AnimationKeyframe(0.0, opacity: 0.0, translationY: 12.0),
        new AnimationKeyframe(1.0, opacity: 1.0, translationY: 0.0),
    ],
    420,
)->iterations(2)->autoReverse();
$assert(
    $animated->properties()[PropKey::AnimationIterations->value] === 2
        && $animated->properties()[PropKey::AnimationAutoReverse->value] === true,
    'Animated must encode declarative native keyframes.',
);

$interaction = InteractionRegion::make(Text::make('Card'))
    ->draggable('card:42')
    ->acceptsDrop()
    ->contextMenu([
        new NativeMenuItem('inspect', 'Inspect'),
        new NativeMenuItem('delete', 'Delete', destructive: true),
    ]);
$assert(
    $interaction->properties()[PropKey::Draggable->value] === true
        && $interaction->properties()[PropKey::DropEnabled->value] === true
        && isset($interaction->properties()[PropKey::ContextMenuItems->value]),
    'InteractionRegion must encode drag, drop and native menu behavior.',
);

$webView = WebView::make('https://example.com')->javaScriptEnabled(false);
$media = MediaPlayer::make('https://example.com/video.mp4', MediaType::Video)
    ->autoPlay()
    ->loop()
    ->fit(ImageFit::Cover)
    ->volume(0.5);
$assert(
    $webView->kind() === NodeKind::WebView
        && $webView->properties()[PropKey::WebViewJavaScriptEnabled->value] === false
        && $media->kind() === NodeKind::Media
        && $media->properties()[PropKey::MediaLoop->value] === true
        && $media->properties()[PropKey::ImageFit->value] === ImageFit::Cover->value,
    'WebView and MediaPlayer must compile into dedicated native node kinds.',
);

$cachedImage = Image::make('https://example.com/hero.webp')
    ->cache(MediaCachePolicy::StaleWhileRevalidate)
    ->cacheKey('hero:v3')
    ->maxAge(2_592_000_000)
    ->cacheTags(['feed', 'hero'])
    ->pinOffline()
    ->priority(MediaPriority::Visible)
    ->maxCacheSize(64 * 1024 * 1024)
    ->resize(720, 1280)
    ->thumbnail('https://example.com/hero-thumb.webp')
    ->sharedTransition(
        'feed.hero.42',
        SharedTransitionStyle::spring(durationMs: 420, damping: 0.76)
            ->resize(SharedTransitionResizeMode::Clip)
            ->crossFade(),
    )
    ->checksum(str_repeat('a', 64));
$cachedImageProperties = $cachedImage->properties();
$sharedTransitionConfig = json_decode(
    $cachedImageProperties[PropKey::SharedTransitionConfig->value],
    true,
    flags: JSON_THROW_ON_ERROR,
);
$assert(
    $cachedImageProperties[PropKey::MediaCachePolicy->value]
        === MediaCachePolicy::StaleWhileRevalidate->value
        && $cachedImageProperties[PropKey::MediaCacheKey->value] === 'hero:v3'
        && $cachedImageProperties[PropKey::MediaCacheTags->value] === "feed\nhero"
        && $cachedImageProperties[PropKey::SharedTransitionTag->value] === 'feed.hero.42'
        && $sharedTransitionConfig['durationMs'] === 420
        && $sharedTransitionConfig['easing'] === 3
        && $sharedTransitionConfig['resizeMode'] === 2
        && $sharedTransitionConfig['crossFade'] === true
        && $sharedTransitionConfig['damping'] === 0.76
        && $cachedImageProperties[PropKey::MediaCachePinOffline->value] === true
        && $cachedImageProperties[PropKey::MediaResizeWidth->value] === 720
        && $cachedImageProperties[PropKey::MediaCacheChecksum->value] === str_repeat('a', 64),
    'Image media-cache helpers must encode the complete append-only native contract.',
);

$cachedMedia = MediaPlayer::make('https://example.com/movie.mp4')
    ->cache(MediaCachePolicy::Disk)
    ->cacheKey('movie:42')
    ->streamingCache()
    ->preloadSeconds(12)
    ->downloadWhilePlaying()
    ->pinOffline();
$assert(
    $cachedMedia->properties()[PropKey::MediaCacheStreaming->value] === true
        && $cachedMedia->properties()[PropKey::MediaCachePreloadSeconds->value] === 12
        && $cachedMedia->properties()[PropKey::MediaCacheDownloadWhilePlaying->value] === true,
    'MediaPlayer must expose streaming, preload and offline cache controls.',
);

$cachedTagImage = TemplateRenderer::render(
    TemplateCompiler::compile(
        '<Image source="https://example.com/tag.webp" cache="stale-while-revalidate" '.
        'cache-key="tag:v2" cache-max-age="30d" cache-tags="feed,avatar" pin-offline '.
        'priority="visible" cache-max-bytes="64mb" resize-width="512" resize-height="512" />',
    ),
    null,
    [],
);
$assert(
    $cachedTagImage->properties()[PropKey::MediaCachePolicy->value]
        === MediaCachePolicy::StaleWhileRevalidate->value
        && $cachedTagImage->properties()[PropKey::MediaCacheMaxAgeMs->value] === 2_592_000_000
        && $cachedTagImage->properties()[PropKey::MediaCacheMaxBytes->value] === 67_108_864
        && $cachedTagImage->properties()[PropKey::MediaResizeHeight->value] === 512,
    'Tag media-cache attributes must normalize kebab-case values and bounded units.',
);
$templateSharedStyle = SharedTransitionStyle::spring(durationMs: 360, damping: 0.8)
    ->resize(SharedTransitionResizeMode::Clip)
    ->crossFade();
$sharedTagImage = TemplateRenderer::render(
    TemplateCompiler::compile(
        '<Image source="post.webp" shared-transition="post:42" '.
        ':shared-transition-style="$sharedStyle" />',
    ),
    null,
    ['sharedStyle' => $templateSharedStyle],
);
$assert(
    $sharedTagImage->properties()[PropKey::SharedTransitionTag->value] === 'post:42'
        && $sharedTagImage->properties()[PropKey::SharedTransitionConfig->value]
            === $templateSharedStyle->toJson(),
    'PAM templates must expose typed shared-element tags and motion styles.',
);

$hardenedWebView = WebView::make('https://example.com/app')
    ->allowedHosts(['example.com', 'cdn.example.com']);
$assert(
    $hardenedWebView->properties()[PropKey::WebViewAllowedHosts->value]
        === "example.com\ncdn.example.com"
        && PropKey::WebViewAllowedHosts->value === 366,
    'WebView host allowlists must use the append-only native protocol.',
);

$permission = new PermissionDecision(
    PermissionKind::Photos,
    PermissionStatus::Limited,
    false,
);
$assert(
    $permission->granted()
        && PermissionKind::LocationWhenInUse->value === 5
        && PermissionKind::Contacts->value === 6
        && PermissionStatus::Limited->value === 4
        && PushEventType::Opened->value === 2
        && PushProvider::Apns->value === 2,
    'Production capability variants must remain sequential integer enums.',
);

Stores::resetRuntime();
$counterStore = Stores::get(new class extends Store {
    protected function state(): array
    {
        return ['count' => 1, 'label' => 'Counter', 'temporary' => false];
    }

    protected function persist(): array
    {
        return ['count'];
    }

    public function increment(int $amount = 1): void
    {
        $this->count += $amount;
    }

    public function failAfterMutation(): void
    {
        $this->count = 999;
        throw new RuntimeException('rollback');
    }

    #[StoreComputed]
    protected function doubled(): int
    {
        return $this->count * 2;
    }
}::class);
$observedChanges = [];
$counterStore->subscribe(static function ($change) use (&$observedChanges): void {
    $observedChanges[] = $change;
});
$counterStore->dispatch('increment', ['amount' => 2]);
$assert(
    $counterStore->count === 3
        && $counterStore->doubled === 6
        && count($observedChanges) === 1
        && $observedChanges[0]->diff['count'] === ['before' => 1, 'after' => 3],
    'Pam Store actions must batch mutations, invalidate computed values and publish diffs.',
);
$counterStore->undo();
$assert($counterStore->count === 1, 'Pam Store must support undo.');
$counterStore->redo();
$assert($counterStore->count === 3, 'Pam Store must support redo.');
try {
    $counterStore->dispatch('failAfterMutation');
    $assert(false, 'Failed store actions must throw.');
} catch (RuntimeException) {
    $assert($counterStore->count === 3, 'Failed store actions must roll state back atomically.');
}
try {
    $counterStore->optimistic(
        'optimistic-increment',
        static function () use ($counterStore): void {
            $counterStore->count = 10;
        },
        static fn () => throw new RuntimeException('network'),
    );
    $assert(false, 'Failed optimistic tasks must throw.');
} catch (RuntimeException) {
    $assert($counterStore->count === 3, 'Optimistic updates must roll back on failure.');
}
$changeId = $observedChanges[0]->id;
$counterStore->dispatch('increment', ['amount' => 5], ActionPolicy::Every);
$assert(
    Stores::timeTravel($changeId)
        && $counterStore->count === 3
        && StoreChangeKind::TimeTravel->value === 5,
    'Pam Store DevTools history must support time travel with integer change kinds.',
);
$middlewareCalls = 0;
Stores::middleware(new class($middlewareCalls) implements StoreMiddleware {
    public function __construct(private int &$calls)
    {
    }

    public function handle(Store $store, string $action, array $arguments, Closure $next): mixed
    {
        $this->calls++;

        return $next();
    }
});
$counterStore->dispatch('increment');
$assert($middlewareCalls === 1, 'Pam Store middleware must wrap actions.');

$componentLog = [];
$component = new class($componentLog) extends Component {
    public int $renders = 0;

    public function __construct(private array &$log)
    {
    }

    protected function initialState(): array
    {
        return ['count' => 1];
    }

    public function setup(): void
    {
        $this->log[] = 'setup';
    }

    public function mount(): void
    {
        $this->log[] = 'mount';
    }

    public function rendering(): void
    {
        $this->log[] = 'rendering';
    }

    public function render(): \Pam\Native\Renderable
    {
        $this->renders++;

        return Text::make((string) $this->doubled);
    }

    #[\Pam\Native\Attributes\Computed]
    protected function doubled(): int
    {
        return $this->state->count * 2;
    }

    protected function effects(): array
    {
        return [
            \Pam\Native\Effect::watch(
                fn (): int => $this->state->count,
                function (int $count): Closure {
                    $this->log[] = "effect:{$count}";

                    return function (): void {
                        $this->log[] = 'effect:cleanup';
                    };
                },
            ),
        ];
    }

    public function increment(): void
    {
        $this->state->count++;
    }

    public function shouldUpdate(\Pam\Native\ComponentChanges $changes): bool
    {
        return !$changes->changed('ignored');
    }

    public function cleanup(): void
    {
        $this->log[] = 'cleanup';
    }

    #[\Pam\Native\Attributes\Expose]
    public function exposedCount(): int
    {
        return $this->state->count;
    }

    public function bind(\Pam\Native\ComponentRef $ref): void
    {
        $this->exposeTo($ref);
    }
};
ComponentLifecycle::beginRender();
$component->toElement();
ComponentLifecycle::finishRender();
ComponentLifecycle::commit();
$assert(
    $componentLog === ['setup', 'mount', 'rendering', 'effect:1']
        && $component->renders === 1,
    'Component setup, render and effect hooks must run in deterministic order.',
);
$component->increment();
ComponentLifecycle::beginRender();
$component->toElement();
ComponentLifecycle::finishRender();
ComponentLifecycle::commit();
$assert(
    $component->renders === 2
        && array_slice($componentLog, -3) === ['rendering', 'effect:cleanup', 'effect:2'],
    'Local state must invalidate computed values, render and clean changed effects.',
);
ComponentLifecycle::beginRender();
$component->toElement();
ComponentLifecycle::finishRender();
ComponentLifecycle::commit();
$assert(
    $component->renders === 2,
    'Dependency tracking must skip clean component subtrees.',
);
$ref = new \Pam\Native\ComponentRef();
$component->bind($ref);
$assert($ref->call('exposedCount') === 2, 'Component refs may call only exposed methods.');

$boundary = new class extends Component {
    public function render(): \Pam\Native\Renderable
    {
        throw new RuntimeException('child failed');
    }

    public function failed(
        Throwable $error,
        \Pam\Native\ErrorContext $context,
    ): ?\Pam\Native\Renderable {
        return Text::make($context->phase.':'.$error->getMessage());
    }
};
ComponentLifecycle::beginRender();
$boundaryElement = $boundary->toElement();
ComponentLifecycle::finishRender();
ComponentLifecycle::commit();
$assert(
    $boundaryElement->kind() === NodeKind::Text,
    'Component error boundaries must recover a failed render with a fallback element.',
);

$context = new \stdClass();
$provider = new class($context) extends Component {
    public function __construct(private object $context)
    {
    }

    protected function provide(): array
    {
        return [\stdClass::class => $this->context];
    }

    public function render(): \Pam\Native\Renderable
    {
        return Text::make('provider');
    }
};
$consumer = new class extends Component {
    public function context(): object
    {
        return $this->inject(\stdClass::class);
    }

    protected function slots(): array
    {
        return ['content' => \Pam\Native\Slot::required()];
    }

    public function render(): \Pam\Native\Renderable
    {
        return Text::make('consumer');
    }
};
$provider->__pamConfigure([], []);
$consumer->__pamConfigure(['content' => [Text::make('slot')]], [], $provider);
$assert(
    $consumer->context() === $context,
    'Component provide/inject context and typed slot validation must follow ancestry.',
);

$nativeRef = new \Pam\Native\NativeRef();
$focused = false;
$nativeRef->attach([
    'focus' => static function () use (&$focused): void {
        $focused = true;
    },
    'blur' => static function (): void {},
    'measure' => static fn (): array => [
        'x' => 0.0,
        'y' => 0.0,
        'width' => 100.0,
        'height' => 40.0,
    ],
    'scrollIntoView' => static function (): void {},
]);
$nativeRef->focus();
$assert(
    $focused && $nativeRef->measure()['width'] === 100.0,
    'Native refs must expose lifecycle-safe focus and measurement operations.',
);
$nativeRef->detach();

$schedulerOrder = [];
\Pam\Native\Scheduling\Scheduler::reset();
\Pam\Native\Scheduling\Scheduler::schedule(
    static function () use (&$schedulerOrder): void {
        $schedulerOrder[] = 'background';
    },
    \Pam\Native\Scheduling\TaskPriority::Background,
);
\Pam\Native\Scheduling\Scheduler::schedule(
    static function () use (&$schedulerOrder): void {
        $schedulerOrder[] = 'input';
    },
    \Pam\Native\Scheduling\TaskPriority::UserBlocking,
);
$obsolete = \Pam\Native\Scheduling\Scheduler::schedule(
    static function () use (&$schedulerOrder): void {
        $schedulerOrder[] = 'obsolete';
    },
    coalesce: 'search',
);
\Pam\Native\Scheduling\Scheduler::schedule(
    static function () use (&$schedulerOrder): void {
        $schedulerOrder[] = 'latest';
    },
    coalesce: 'search',
);
\Pam\Native\Scheduling\Scheduler::drain(100);
$assert(
    $obsolete->token->cancelled()
        && $schedulerOrder === ['input', 'latest', 'background'],
    'Scheduler must prioritize user work and coalesce obsolete tasks.',
);
$resource = new AsyncResource(
    static fn (\Pam\Native\Scheduling\CancellationToken $token): array => ['ready'],
    'dashboard',
);
$resource->load(\Pam\Native\Scheduling\TaskPriority::UserBlocking);
\Pam\Native\Scheduling\Scheduler::drain(100);
$suspended = Suspense::make(
    $resource->value(),
    static fn (array $data): Text => Text::make($data[0]),
    Text::make('Loading'),
);
$assert(
    $resource->value()->status === AsyncStatus::Content
        && $suspended->toElement()->properties()[PropKey::Text->value] === 'ready',
    'Async resources must run through the priority scheduler and reveal Suspense content.',
);

$idl = IdlCompiler::compile(json_encode([
    'version' => 1,
    'namespace' => 'Dev.Pam.Generated',
    'modules' => [[
        'id' => 1,
        'name' => 'camera',
        'methods' => [[
            'id' => 1,
            'name' => 'capture',
            'parameters' => [[
                'id' => 1,
                'name' => 'quality',
                'type' => 3,
                'required' => false,
            ]],
        ]],
    ]],
], JSON_THROW_ON_ERROR));
$assert(
    str_contains($idl->php, 'final class CameraBridge')
        && str_contains($idl->kotlin, 'const val CAPTURE: Int = 1')
        && str_contains($idl->swift, 'static let capture: Int = 1')
        && str_contains($idl->rust, 'CAMERA_CAPTURE: u16 = 1')
        && strlen($idl->fingerprint) === 64,
    'Typed IDL must generate fingerprinted PHP, Kotlin, Swift, and Rust contracts.',
);
$worklet = Worklet::input()
    ->interpolate(0, 200, 1, 0)
    ->clamp(0, 1);
$assert(
    abs($worklet->evaluate(50) - 0.75) < 0.000001
        && str_starts_with($worklet->bytecode(), 'PNW1')
        && strlen($worklet->bytecode()) < 256,
    'Worklets must compile bounded data-only numeric programs deterministically.',
);
$nativeWorklet = Animated::worklet(
    Text::make('Native frame'),
    $worklet,
    WorkletTarget::Opacity,
    200,
)->iterations(3);
$nativeWorkletProperties = $nativeWorklet->properties();
$assert(
    $nativeWorkletProperties[PropKey::WorkletProgram->value] instanceof BinaryValue
        && $nativeWorkletProperties[PropKey::WorkletTarget->value] === 1
        && $nativeWorkletProperties[PropKey::WorkletDurationMs->value] === 200
        && $nativeWorkletProperties[PropKey::WorkletIterations->value] === 3,
    'Animated worklets must cross the render protocol as bounded native programs.',
);
$offline = new OfflineMutationQueue();
$queued = $offline->enqueue('message:local-1', 'messages.send', ['body' => 'Hello']);
$assert(
    $offline->enqueue('message:local-1', 'messages.send', ['body' => 'Duplicate'])->id === $queued->id,
    'Offline sync must deduplicate active mutations by idempotency key.',
);
$canvas = Canvas::make()
    ->roundedRectangle(8, 8, 120, 48, 12, 0xFF6750A4)
    ->circle(180, 32, 24, 0xFFFFD23F)
    ->line(8, 80, 220, 80, 4, 0xFF111111);
$assert(
    $canvas->kind() === NodeKind::Canvas
        && str_contains($canvas->properties()[PropKey::CanvasCommands->value], '"kind":2'),
    'Canvas must encode bounded vector commands for hardware-accelerated native renderers.',
);
$serverAction = false;
$serverTree = ServerDrivenUi::render(
    json_encode([
        'version' => 1,
        'root' => [
            'kind' => 2,
            'props' => ['style' => ['padding' => 16, 'gap' => 8]],
            'children' => [
                ['kind' => 4, 'props' => ['text' => 'Remote offer']],
                ['kind' => 5, 'props' => ['label' => 'Open', 'action' => 'offer.open']],
            ],
        ],
    ], JSON_THROW_ON_ERROR),
    static function (string $action) use (&$serverAction): ?Closure {
        return $action === 'offer.open'
            ? static function () use (&$serverAction): void { $serverAction = true; }
            : null;
    },
);
$serverElement = $serverTree->toElement();
$assert(
    $serverElement->kind() === NodeKind::Column
        && count($serverElement->children()) === 2,
    'Server-driven UI must render only allowlisted bounded native nodes and actions.',
);
$jobRan = false;
$jobs = new BackgroundJobs();
$jobs->register(
    'sync.messages',
    static function (array $payload, \Pam\Native\Scheduling\CancellationToken $token) use (&$jobRan): void {
        $token->throwIfCancelled();
        $jobRan = ($payload['conversationId'] ?? null) === 42;
    },
);
$jobs->dispatch('sync.messages', 'conversation:42', ['conversationId' => 42]);
$assert($jobs->runReady(1_000) === 1, 'Background jobs must schedule ready persisted work.');
\Pam\Native\Scheduling\Scheduler::drain(100);
$assert(
    $jobRan && str_contains($jobs->snapshot(), '"status":3'),
    'Background jobs must execute with cancellation and persist applied state.',
);
$offline->sending($queued->id);
$retry = $offline->retry($queued->id, 1_000, 'network');
$restoredOffline = OfflineMutationQueue::restore($offline->export());
$assert(
    $retry->status === MutationStatus::Retry
        && $restoredOffline->ready($retry->availableAtMs)[0]->key === 'message:local-1',
    'Offline sync must persist typed retry state and deterministic backoff.',
);

$firstLinkingSubscription = \Pam\Native\System\Linking::listen(static function (string $url): void {});
\Pam\Native\Internal\Runtime::shutdown();
$secondLinkingSubscription = \Pam\Native\System\Linking::listen(static function (string $url): void {});
$assert(
    $firstLinkingSubscription === 1 && $secondLinkingSubscription === 1,
    'Runtime shutdown must clear process-local listeners before hot reload.',
);
\Pam\Native\System\Linking::unsubscribe($secondLinkingSubscription);

ComponentLifecycle::shutdown();
$assert(
    in_array('effect:cleanup', $componentLog, true)
        && end($componentLog) === 'cleanup',
    'Component shutdown must guarantee effect and component cleanup.',
);

require __DIR__.'/language2.php';
require __DIR__.'/style_conformance.php';
require __DIR__.'/singularity.php';
require __DIR__.'/signals.php';
require __DIR__.'/visual_dom.php';
require __DIR__.'/appearance.php';
require __DIR__.'/native_capabilities.php';

echo "Pam Native PHP SDK tests passed.\n";
